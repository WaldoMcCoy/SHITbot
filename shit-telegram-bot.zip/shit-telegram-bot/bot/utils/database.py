#!/usr/bin/env python3
"""
# File location: /bot/utils/database.py
Database utilities for S.H.I.T. Bot
Supports both PostgreSQL and SQLite with automatic fallback
"""

import asyncio
import json
import logging
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any, Union

import aiosqlite
import asyncpg
from asyncpg.pool import Pool

logger = logging.getLogger(__name__)


class Database:
    """Unified database interface supporting PostgreSQL and SQLite"""
    
    def __init__(self, database_url: str = None, use_sqlite: bool = None):
        self.database_url = database_url or os.getenv('DATABASE_URL')
        self.use_sqlite = use_sqlite if use_sqlite is not None else os.getenv('USE_SQLITE', 'false').lower() == 'true'
        
        # Database connections
        self.pg_pool: Optional[Pool] = None
        self.sqlite_conn: Optional[aiosqlite.Connection] = None
        self.sqlite_path = Path('/app/data/db/shitbot.db')
        
        # Determine which database to use
        if not self.database_url or self.use_sqlite:
            self.use_sqlite = True
            logger.info("Using SQLite database")
        else:
            logger.info("Using PostgreSQL database")
    
    async def initialize(self):
        """Initialize database connection"""
        try:
            if self.use_sqlite:
                await self._init_sqlite()
            else:
                await self._init_postgres()
                # Test connection
                try:
                    async with self.pg_pool.acquire() as conn:
                        await conn.fetchval('SELECT 1')
                except Exception as e:
                    logger.error(f"PostgreSQL connection failed: {e}")
                    logger.info("Falling back to SQLite")
                    self.use_sqlite = True
                    await self._init_sqlite()
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
            raise
    
    async def _init_postgres(self):
        """Initialize PostgreSQL connection pool"""
        self.pg_pool = await asyncpg.create_pool(
            self.database_url,
            min_size=2,
            max_size=10,
            command_timeout=60,
            pool_recycle=3600
        )
        logger.info("PostgreSQL connection pool created")
    
    async def _init_sqlite(self):
        """Initialize SQLite connection"""
        # Ensure directory exists
        self.sqlite_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Create connection
        self.sqlite_conn = await aiosqlite.connect(self.sqlite_path)
        self.sqlite_conn.row_factory = aiosqlite.Row
        
        # Enable foreign keys
        await self.sqlite_conn.execute("PRAGMA foreign_keys = ON")
        
        # Create tables
        await self._create_sqlite_schema()
        
        logger.info(f"SQLite database initialized at {self.sqlite_path}")
    
    async def _create_sqlite_schema(self):
        """Create SQLite schema"""
        schema = """
        -- Users table
        CREATE TABLE IF NOT EXISTS users (
            user_id BIGINT PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            last_name TEXT,
            is_admin BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Game saves
        CREATE TABLE IF NOT EXISTS game_saves (
            user_id BIGINT PRIMARY KEY,
            game_state TEXT NOT NULL,
            saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        );
        
        -- Game scores
        CREATE TABLE IF NOT EXISTS game_scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id BIGINT NOT NULL,
            username TEXT,
            score INTEGER NOT NULL,
            days_survived INTEGER,
            ending_reason TEXT,
            played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        );
        
        -- Player stats
        CREATE TABLE IF NOT EXISTS player_stats (
            user_id BIGINT PRIMARY KEY,
            games_played INTEGER DEFAULT 0,
            high_score INTEGER DEFAULT 0,
            total_score BIGINT DEFAULT 0,
            total_profit BIGINT DEFAULT 0,
            total_days_survived INTEGER DEFAULT 0,
            highest_cash INTEGER DEFAULT 0,
            lowest_debt INTEGER DEFAULT 0,
            best_health INTEGER DEFAULT 0,
            most_guns INTEGER DEFAULT 0,
            stats_json TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        );
        
        -- Competitions
        CREATE TABLE IF NOT EXISTS competitions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            start_date TIMESTAMP NOT NULL,
            end_date TIMESTAMP NOT NULL,
            max_games INTEGER DEFAULT 10,
            created_by BIGINT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_active BOOLEAN DEFAULT TRUE
        );
        
        -- Competition scores
        CREATE TABLE IF NOT EXISTS competition_scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            competition_id INTEGER NOT NULL,
            user_id BIGINT NOT NULL,
            username TEXT,
            score INTEGER NOT NULL,
            games_played INTEGER DEFAULT 1,
            submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (competition_id) REFERENCES competitions(id),
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        );
        
        -- Chat sessions
        CREATE TABLE IF NOT EXISTS chat_sessions (
            user_id BIGINT PRIMARY KEY,
            session_data TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        );
        
        -- AI settings
        CREATE TABLE IF NOT EXISTS ai_settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            settings_json TEXT NOT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Scan history
        CREATE TABLE IF NOT EXISTS scan_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id BIGINT NOT NULL,
            wallet_address TEXT NOT NULL,
            start_date DATE NOT NULL,
            end_date DATE NOT NULL,
            results_summary TEXT,
            scan_completed BOOLEAN DEFAULT FALSE,
            scanned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        );
        
        -- Create indices
        CREATE INDEX IF NOT EXISTS idx_game_scores_user_id ON game_scores(user_id);
        CREATE INDEX IF NOT EXISTS idx_game_scores_played_at ON game_scores(played_at);
        CREATE INDEX IF NOT EXISTS idx_competition_scores_comp_id ON competition_scores(competition_id);
        CREATE INDEX IF NOT EXISTS idx_scan_history_user_id ON scan_history(user_id);
        CREATE INDEX IF NOT EXISTS idx_scan_history_wallet ON scan_history(wallet_address);
        """
        
        await self.sqlite_conn.executescript(schema)
        await self.sqlite_conn.commit()
    
    async def close(self):
        """Close database connections"""
        if self.pg_pool:
            await self.pg_pool.close()
        if self.sqlite_conn:
            await self.sqlite_conn.close()
    
    # User management
    
    async def get_or_create_user(self, user_id: int, username: str = None, 
                                first_name: str = None, last_name: str = None) -> Dict:
        """Get or create user record"""
        if self.use_sqlite:
            async with self.sqlite_conn.execute(
                "SELECT * FROM users WHERE user_id = ?", (user_id,)
            ) as cursor:
                row = await cursor.fetchone()
                
            if row:
                # Update last active
                await self.sqlite_conn.execute(
                    "UPDATE users SET last_active = CURRENT_TIMESTAMP WHERE user_id = ?",
                    (user_id,)
                )
                await self.sqlite_conn.commit()
                return dict(row)
            else:
                # Create new user
                await self.sqlite_conn.execute(
                    """INSERT INTO users (user_id, username, first_name, last_name)
                       VALUES (?, ?, ?, ?)""",
                    (user_id, username, first_name, last_name)
                )
                await self.sqlite_conn.commit()
                return {
                    'user_id': user_id,
                    'username': username,
                    'first_name': first_name,
                    'last_name': last_name,
                    'is_admin': False
                }
        else:
            async with self.pg_pool.acquire() as conn:
                # Insert or update user
                row = await conn.fetchrow(
                    """INSERT INTO users (user_id, username, first_name, last_name)
                       VALUES ($1, $2, $3, $4)
                       ON CONFLICT (user_id) DO UPDATE
                       SET username = EXCLUDED.username,
                           last_active = CURRENT_TIMESTAMP
                       RETURNING *""",
                    user_id, username, first_name, last_name
                )
                return dict(row)
    
    # Game saves
    
    async def save_game(self, user_id: int, game_state: Dict) -> None:
        """Save game state"""
        state_json = json.dumps(game_state)
        
        if self.use_sqlite:
            await self.sqlite_conn.execute(
                """INSERT OR REPLACE INTO game_saves (user_id, game_state, saved_at)
                   VALUES (?, ?, CURRENT_TIMESTAMP)""",
                (user_id, state_json)
            )
            await self.sqlite_conn.commit()
        else:
            async with self.pg_pool.acquire() as conn:
                await conn.execute(
                    """INSERT INTO game_saves (user_id, game_state)
                       VALUES ($1, $2)
                       ON CONFLICT (user_id) DO UPDATE
                       SET game_state = EXCLUDED.game_state,
                           saved_at = CURRENT_TIMESTAMP""",
                    user_id, state_json
                )
    
    async def get_saved_game(self, user_id: int) -> Optional[Dict]:
        """Get saved game state"""
        if self.use_sqlite:
            async with self.sqlite_conn.execute(
                "SELECT game_state FROM game_saves WHERE user_id = ?",
                (user_id,)
            ) as cursor:
                row = await cursor.fetchone()
                if row:
                    return json.loads(row['game_state'])
        else:
            async with self.pg_pool.acquire() as conn:
                row = await conn.fetchrow(
                    "SELECT game_state FROM game_saves WHERE user_id = $1",
                    user_id
                )
                if row:
                    return json.loads(row['game_state'])
        
        return None
    
    async def delete_saved_game(self, user_id: int) -> None:
        """Delete saved game"""
        if self.use_sqlite:
            await self.sqlite_conn.execute(
                "DELETE FROM game_saves WHERE user_id = ?",
                (user_id,)
            )
            await self.sqlite_conn.commit()
        else:
            async with self.pg_pool.acquire() as conn:
                await conn.execute(
                    "DELETE FROM game_saves WHERE user_id = $1",
                    user_id
                )
    
    # Game scores and stats
    
    async def add_game_score(self, user_id: int, username: str, score: int,
                           days_survived: int, ending_reason: str) -> None:
        """Add game score"""
        if self.use_sqlite:
            await self.sqlite_conn.execute(
                """INSERT INTO game_scores 
                   (user_id, username, score, days_survived, ending_reason)
                   VALUES (?, ?, ?, ?, ?)""",
                (user_id, username, score, days_survived, ending_reason)
            )
            await self.sqlite_conn.commit()
            
            # Update player stats
            await self._update_player_stats_sqlite(user_id, score)
        else:
            async with self.pg_pool.acquire() as conn:
                await conn.execute(
                    """INSERT INTO game_scores 
                       (user_id, username, score, days_survived, ending_reason)
                       VALUES ($1, $2, $3, $4, $5)""",
                    user_id, username, score, days_survived, ending_reason
                )
                
                # Update player stats
                await self._update_player_stats_postgres(conn, user_id, score)
    
    async def _update_player_stats_sqlite(self, user_id: int, score: int):
        """Update player statistics (SQLite)"""
        # Get current stats
        async with self.sqlite_conn.execute(
            "SELECT * FROM player_stats WHERE user_id = ?",
            (user_id,)
        ) as cursor:
            current = await cursor.fetchone()
        
        if current:
            games_played = current['games_played'] + 1
            high_score = max(current['high_score'], score)
            total_score = current['total_score'] + score
            
            await self.sqlite_conn.execute(
                """UPDATE player_stats 
                   SET games_played = ?,
                       high_score = ?,
                       total_score = ?,
                       updated_at = CURRENT_TIMESTAMP
                   WHERE user_id = ?""",
                (games_played, high_score, total_score, user_id)
            )
        else:
            await self.sqlite_conn.execute(
                """INSERT INTO player_stats 
                   (user_id, games_played, high_score, total_score)
                   VALUES (?, 1, ?, ?)""",
                (user_id, score, score)
            )
        
        await self.sqlite_conn.commit()
    
    async def _update_player_stats_postgres(self, conn: asyncpg.Connection, 
                                          user_id: int, score: int):
        """Update player statistics (PostgreSQL)"""
        await conn.execute(
            """INSERT INTO player_stats (user_id, games_played, high_score, total_score)
               VALUES ($1, 1, $2, $2)
               ON CONFLICT (user_id) DO UPDATE
               SET games_played = player_stats.games_played + 1,
                   high_score = GREATEST(player_stats.high_score, EXCLUDED.high_score),
                   total_score = player_stats.total_score + EXCLUDED.total_score,
                   updated_at = CURRENT_TIMESTAMP""",
            user_id, score
        )
    
    async def get_player_stats(self, user_id: int) -> Optional[Dict]:
        """Get player statistics"""
        if self.use_sqlite:
            async with self.sqlite_conn.execute(
                """SELECT ps.*, 
                          CAST(ps.total_score AS REAL) / NULLIF(ps.games_played, 0) as avg_score,
                          COUNT(CASE WHEN gs.days_survived >= 30 THEN 1 END) * 100.0 / 
                          NULLIF(COUNT(gs.id), 0) as completion_rate
                   FROM player_stats ps
                   LEFT JOIN game_scores gs ON ps.user_id = gs.user_id
                   WHERE ps.user_id = ?
                   GROUP BY ps.user_id""",
                (user_id,)
            ) as cursor:
                row = await cursor.fetchone()
                if row:
                    return dict(row)
        else:
            async with self.pg_pool.acquire() as conn:
                row = await conn.fetchrow(
                    """SELECT ps.*, 
                              ps.total_score::float / NULLIF(ps.games_played, 0) as avg_score,
                              COUNT(CASE WHEN gs.days_survived >= 30 THEN 1 END) * 100.0 / 
                              NULLIF(COUNT(gs.id), 0) as completion_rate
                       FROM player_stats ps
                       LEFT JOIN game_scores gs ON ps.user_id = gs.user_id
                       WHERE ps.user_id = $1
                       GROUP BY ps.user_id, ps.games_played, ps.high_score, 
                                ps.total_score, ps.total_profit, ps.total_days_survived,
                                ps.highest_cash, ps.lowest_debt, ps.best_health, 
                                ps.most_guns, ps.stats_json, ps.updated_at""",
                    user_id
                )
                if row:
                    return dict(row)
        
        return None
    
    async def get_leaderboard(self, limit: int = 10, 
                            time_filter: str = 'all') -> List[Dict]:
        """Get leaderboard"""
        time_clause = ""
        if time_filter == 'today':
            time_clause = "WHERE played_at >= date('now')"
        elif time_filter == 'week':
            time_clause = "WHERE played_at >= date('now', '-7 days')"
        elif time_filter == 'month':
            time_clause = "WHERE played_at >= date('now', '-30 days')"
        
        if self.use_sqlite:
            query = f"""
                SELECT user_id, username, MAX(score) as high_score,
                       COUNT(*) as games_played
                FROM game_scores
                {time_clause}
                GROUP BY user_id, username
                ORDER BY high_score DESC
                LIMIT ?
            """
            async with self.sqlite_conn.execute(query, (limit,)) as cursor:
                rows = await cursor.fetchall()
                return [dict(row) for row in rows]
        else:
            query = f"""
                SELECT user_id, username, MAX(score) as high_score,
                       COUNT(*) as games_played
                FROM game_scores
                {time_clause}
                GROUP BY user_id, username
                ORDER BY high_score DESC
                LIMIT $1
            """
            async with self.pg_pool.acquire() as conn:
                rows = await conn.fetch(query, limit)
                return [dict(row) for row in rows]
    
    # Chat sessions
    
    async def save_chat_session(self, user_id: int, session_data: Dict) -> None:
        """Save chat session"""
        data_json = json.dumps(session_data)
        
        if self.use_sqlite:
            await self.sqlite_conn.execute(
                """INSERT OR REPLACE INTO chat_sessions 
                   (user_id, session_data, updated_at)
                   VALUES (?, ?, CURRENT_TIMESTAMP)""",
                (user_id, data_json)
            )
            await self.sqlite_conn.commit()
        else:
            async with self.pg_pool.acquire() as conn:
                await conn.execute(
                    """INSERT INTO chat_sessions (user_id, session_data)
                       VALUES ($1, $2)
                       ON CONFLICT (user_id) DO UPDATE
                       SET session_data = EXCLUDED.session_data,
                           updated_at = CURRENT_TIMESTAMP""",
                    user_id, data_json
                )
    
    async def get_chat_session(self, user_id: int) -> Optional[Dict]:
        """Get chat session"""
        if self.use_sqlite:
            async with self.sqlite_conn.execute(
                "SELECT session_data FROM chat_sessions WHERE user_id = ?",
                (user_id,)
            ) as cursor:
                row = await cursor.fetchone()
                if row:
                    return json.loads(row['session_data'])
        else:
            async with self.pg_pool.acquire() as conn:
                row = await conn.fetchrow(
                    "SELECT session_data FROM chat_sessions WHERE user_id = $1",
                    user_id
                )
                if row:
                    return json.loads(row['session_data'])
        
        return None
    
    # AI Settings
    
    async def save_ai_settings(self, settings: Dict) -> None:
        """Save AI settings"""
        settings_json = json.dumps(settings)
        
        if self.use_sqlite:
            await self.sqlite_conn.execute(
                """INSERT OR REPLACE INTO ai_settings (id, settings_json)
                   VALUES (1, ?)""",
                (settings_json,)
            )
            await self.sqlite_conn.commit()
        else:
            async with self.pg_pool.acquire() as conn:
                await conn.execute(
                    """INSERT INTO ai_settings (id, settings_json)
                       VALUES (1, $1)
                       ON CONFLICT (id) DO UPDATE
                       SET settings_json = EXCLUDED.settings_json,
                           updated_at = CURRENT_TIMESTAMP""",
                    settings_json
                )
    
    async def get_ai_settings(self) -> Optional[Dict]:
        """Get AI settings"""
        if self.use_sqlite:
            async with self.sqlite_conn.execute(
                "SELECT settings_json FROM ai_settings WHERE id = 1"
            ) as cursor:
                row = await cursor.fetchone()
                if row:
                    return json.loads(row['settings_json'])
        else:
            async with self.pg_pool.acquire() as conn:
                row = await conn.fetchrow(
                    "SELECT settings_json FROM ai_settings WHERE id = 1"
                )
                if row:
                    return json.loads(row['settings_json'])
        
        return None
    
    # Scan history
    
    async def save_scan_history(self, user_id: int, wallet_address: str,
                              start_date: datetime, end_date: datetime,
                              results_summary: Dict = None) -> int:
        """Save scan history and return ID"""
        summary_json = json.dumps(results_summary) if results_summary else None
        
        if self.use_sqlite:
            cursor = await self.sqlite_conn.execute(
                """INSERT INTO scan_history 
                   (user_id, wallet_address, start_date, end_date, results_summary, scan_completed)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (user_id, wallet_address, start_date.date(), end_date.date(), 
                 summary_json, results_summary is not None)
            )
            await self.sqlite_conn.commit()
            return cursor.lastrowid
        else:
            async with self.pg_pool.acquire() as conn:
                row = await conn.fetchrow(
                    """INSERT INTO scan_history 
                       (user_id, wallet_address, start_date, end_date, results_summary, scan_completed)
                       VALUES ($1, $2, $3, $4, $5, $6)
                       RETURNING id""",
                    user_id, wallet_address, start_date.date(), end_date.date(),
                    summary_json, results_summary is not None
                )
                return row['id']
    
    async def get_scan_history(self, user_id: int, limit: int = 10) -> List[Dict]:
        """Get scan history for user"""
        if self.use_sqlite:
            async with self.sqlite_conn.execute(
                """SELECT * FROM scan_history 
                   WHERE user_id = ?
                   ORDER BY scanned_at DESC
                   LIMIT ?""",
                (user_id, limit)
            ) as cursor:
                rows = await cursor.fetchall()
                return [dict(row) for row in rows]
        else:
            async with self.pg_pool.acquire() as conn:
                rows = await conn.fetch(
                    """SELECT * FROM scan_history 
                       WHERE user_id = $1
                       ORDER BY scanned_at DESC
                       LIMIT $2""",
                    user_id, limit
                )
                return [dict(row) for row in rows]
    
    # Chat statistics
    
    async def get_chat_stats(self) -> Dict:
        """Get chat usage statistics"""
        if self.use_sqlite:
            # Total sessions
            async with self.sqlite_conn.execute(
                "SELECT COUNT(*) as count FROM chat_sessions"
            ) as cursor:
                total_sessions = (await cursor.fetchone())['count']
            
            # Active users today
            async with self.sqlite_conn.execute(
                """SELECT COUNT(DISTINCT user_id) as count 
                   FROM chat_sessions 
                   WHERE updated_at >= date('now')"""
            ) as cursor:
                active_today = (await cursor.fetchone())['count']
            
            return {
                'total_sessions': total_sessions,
                'active_users': active_today,
                'messages_today': 0,  # Would need message tracking
                'popular_model': 'llama2'  # Would need to track this
            }
        else:
            async with self.pg_pool.acquire() as conn:
                # Total sessions
                total_sessions = await conn.fetchval(
                    "SELECT COUNT(*) FROM chat_sessions"
                )
                
                # Active users today
                active_today = await conn.fetchval(
                    """SELECT COUNT(DISTINCT user_id) 
                       FROM chat_sessions 
                       WHERE updated_at >= CURRENT_DATE"""
                )
                
                return {
                    'total_sessions': total_sessions,
                    'active_users': active_today,
                    'messages_today': 0,
                    'popular_model': 'llama2'
                }