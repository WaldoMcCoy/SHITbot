"""
Date picker utility for Telegram bot
Provides calendar interface for date selection
"""

from telegram_bot_calendar import DetailedTelegramCalendar, LSTEP


class DatePicker(DetailedTelegramCalendar):
    """Custom date picker with Shibarium theme"""
    
    # Custom step names
    STEPS = {'y': 'year', 'm': 'month', 'd': 'day'}
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)