#!/usr/bin/env python3
"""
# File location: /bot/utils/helpers.py
Helper utilities for S.H.I.T. Bot
"""

import os
import sys
import logging
import colorlog
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
from pathlib import Path


def setup_logging() -> logging.Logger:
    """Setup colored logging with proper formatting"""
    # Create logs directory if it doesn't exist
    log_dir = Path("/app/logs")
    log_dir.mkdir(exist_ok=True)
    
    # Configure color logging
    log_colors = {
        'DEBUG': 'cyan',
        'INFO': 'green',
        'WARNING': 'yellow',
        'ERROR': 'red',
        'CRITICAL': 'red,bg_white',
    }
    
    # Create formatter
    formatter = colorlog.ColoredFormatter(
        '%(log_color)s%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        log_colors=log_colors
    )
    
    # File formatter (no colors)
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Get root logger
    logger = logging.getLogger()
    logger.setLevel(os.getenv('LOG_LEVEL', 'INFO'))
    
    # Remove existing handlers
    logger.handlers = []
    
    # Console handler with colors
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler
    log_file = log_dir / f"bot_{datetime.now().strftime('%Y%m%d')}.log"
    file_handler = logging.FileHandler(log_file)
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)
    
    # Reduce noise from libraries
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.WARNING)
    logging.getLogger("apscheduler").setLevel(logging.WARNING)
    
    return logger


def check_environment() -> bool:
    """Check if all required environment variables are set"""
    required_vars = [
        'BOT_TOKEN',
        'SHIBARIUM_API_KEY'
    ]
    
    missing_vars = []
    for var in required_vars:
        if not os.getenv(var):
            missing_vars.append(var)
    
    if missing_vars:
        logger = logging.getLogger(__name__)
        logger.error(f"Missing required environment variables: {', '.join(missing_vars)}")
        logger.error("Please check your .env file")
        return False
    
    return True


def is_admin_user(user_id: int) -> bool:
    """Check if user is an admin"""
    admin_users = os.getenv('ADMIN_USERS', '').split(',')
    admin_users = [uid.strip() for uid in admin_users if uid.strip()]
    return str(user_id) in admin_users


def format_duration(seconds: int) -> str:
    """Format duration in human-readable format"""
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"{minutes}m"
    elif seconds < 86400:
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        return f"{hours}h {minutes}m"
    else:
        days = seconds // 86400
        hours = (seconds % 86400) // 3600
        return f"{days}d {hours}h"


def format_number(num: float, decimals: int = 2) -> str:
    """Format number with proper decimals and commas"""
    if num >= 1_000_000_000:
        return f"{num/1_000_000_000:.{decimals}f}B"
    elif num >= 1_000_000:
        return f"{num/1_000_000:.{decimals}f}M"
    elif num >= 1_000:
        return f"{num/1_000:.{decimals}f}K"
    else:
        return f"{num:,.{decimals}f}"


def truncate_string(text: str, max_length: int, suffix: str = "...") -> str:
    """Truncate string to maximum length"""
    if len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix


def escape_markdown(text: str) -> str:
    """Escape special characters for Telegram markdown"""
    escape_chars = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!']
    for char in escape_chars:
        text = text.replace(char, f'\\{char}')
    return text


def parse_wallet_address(address: str) -> Optional[str]:
    """Validate and parse wallet address"""
    # Remove whitespace
    address = address.strip()
    
    # Check if it's a valid Ethereum address
    if not address.startswith('0x'):
        address = '0x' + address
    
    # Check length (42 characters including 0x)
    if len(address) != 42:
        return None
    
    # Check if all characters are hex
    try:
        int(address, 16)
    except ValueError:
        return None
    
    return address.lower()


def chunk_list(lst: List[Any], chunk_size: int) -> List[List[Any]]:
    """Split list into chunks"""
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]


def calculate_percentage_change(old_value: float, new_value: float) -> float:
    """Calculate percentage change between two values"""
    if old_value == 0:
        return 0 if new_value == 0 else 100
    return ((new_value - old_value) / old_value) * 100


def get_time_ago(timestamp: datetime) -> str:
    """Get human-readable time ago string"""
    now = datetime.now()
    diff = now - timestamp
    
    if diff < timedelta(minutes=1):
        return "just now"
    elif diff < timedelta(hours=1):
        minutes = int(diff.total_seconds() / 60)
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    elif diff < timedelta(days=1):
        hours = int(diff.total_seconds() / 3600)
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    elif diff < timedelta(days=30):
        days = diff.days
        return f"{days} day{'s' if days != 1 else ''} ago"
    else:
        return timestamp.strftime("%b %d, %Y")


def sanitize_filename(filename: str) -> str:
    """Sanitize filename for safe file operations"""
    # Remove or replace unsafe characters
    unsafe_chars = '<>:"/\\|?*'
    for char in unsafe_chars:
        filename = filename.replace(char, '_')
    
    # Limit length
    max_length = 200
    if len(filename) > max_length:
        name, ext = os.path.splitext(filename)
        filename = name[:max_length - len(ext)] + ext
    
    return filename


def generate_export_filename(prefix: str, wallet: str, extension: str) -> str:
    """Generate filename for exports"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    wallet_short = f"{wallet[:6]}_{wallet[-4:]}" if len(wallet) > 10 else wallet
    filename = f"{prefix}_{wallet_short}_{timestamp}.{extension}"
    return sanitize_filename(filename)


def parse_date_range(date_str: str) -> Optional[tuple[datetime, datetime]]:
    """Parse date range from string (e.g., 'last_week', 'last_month', '2024-01-01:2024-01-31')"""
    date_str = date_str.lower().strip()
    now = datetime.now()
    
    if date_str == 'today':
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = now
    elif date_str == 'yesterday':
        yesterday = now - timedelta(days=1)
        start = yesterday.replace(hour=0, minute=0, second=0, microsecond=0)
        end = yesterday.replace(hour=23, minute=59, second=59)
    elif date_str == 'last_week':
        start = now - timedelta(days=7)
        end = now
    elif date_str == 'last_month':
        start = now - timedelta(days=30)
        end = now
    elif date_str == 'last_year':
        start = now - timedelta(days=365)
        end = now
    elif ':' in date_str:
        # Custom range
        try:
            start_str, end_str = date_str.split(':')
            start = datetime.strptime(start_str.strip(), '%Y-%m-%d')
            end = datetime.strptime(end_str.strip(), '%Y-%m-%d')
            end = end.replace(hour=23, minute=59, second=59)
        except:
            return None
    else:
        return None
    
    return (start, end)


def create_progress_bar(current: int, total: int, width: int = 20) -> str:
    """Create text-based progress bar"""
    if total == 0:
        return "[" + "─" * width + "]"
    
    progress = int((current / total) * width)
    filled = "█" * progress
    empty = "─" * (width - progress)
    percentage = (current / total) * 100
    
    return f"[{filled}{empty}] {percentage:.1f}%"


def validate_api_response(response: Dict[str, Any]) -> bool:
    """Validate API response structure"""
    # Check for common error indicators
    if not response:
        return False
    
    if response.get('status') == '0':
        return False
    
    if 'error' in response or 'message' in response:
        if response.get('message', '').lower() != 'ok':
            return False
    
    return True


def merge_dicts(dict1: Dict, dict2: Dict) -> Dict:
    """Deep merge two dictionaries"""
    result = dict1.copy()
    
    for key, value in dict2.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_dicts(result[key], value)
        else:
            result[key] = value
    
    return result


# Rate limiting helper
class RateLimiter:
    """Simple rate limiter for API calls"""
    
    def __init__(self, max_calls: int = 5, period: int = 1):
        self.max_calls = max_calls
        self.period = period
        self.calls = []
    
    def can_call(self) -> bool:
        """Check if we can make a call"""
        now = datetime.now()
        
        # Remove old calls
        self.calls = [call_time for call_time in self.calls 
                     if now - call_time < timedelta(seconds=self.period)]
        
        # Check if we can make a new call
        return len(self.calls) < self.max_calls
    
    def add_call(self):
        """Record a new call"""
        self.calls.append(datetime.now())


# Singleton instances
rate_limiter = RateLimiter(max_calls=5, period=1)