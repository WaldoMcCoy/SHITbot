#!/usr/bin/env python3
"""
# File location: /bot/handlers/game_handler.py
Enhanced DopeWars Game Handler for Telegram Bot
Manages all game interactions with multi-player support
"""

import logging
import json
from datetime import datetime
from typing import Dict, Optional, Any

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, Message
from telegram.ext import (
    ContextTypes,
    ConversationHandler,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters
)
from telegram.constants import ParseMode, ChatAction

from apps.dope_wars.game import DopeWarsGame
from apps.dope_wars.models import GameState
from apps.dope_wars.leaderboard import Leaderboard
from bot.utils.helpers import is_admin_user

logger = logging.getLogger(__name__)

# Conversation states
(GAME_MENU, GAME_PLAYING, LOCATION_SELECT, BUY_MENU, SELL_MENU, 
 AMOUNT_INPUT, EVENT_RESPONSE, BANK_MENU, ADMIN_MENU, COMPETITION_MENU) = range(10)

# Input states
INPUT_TYPES = {
    'buy_amount': 'buy',
    'sell_amount': 'sell',
    'bank_deposit': 'deposit',
    'bank_withdraw': 'withdraw',
    'debt_payment': 'pay_debt'
}


class GameHandler:
    """Enhanced game handler with full feature support"""
    
    def __init__(self, db):
        self.db = db
        self.game = DopeWarsGame()
        self.leaderboard = Leaderboard(db)
        self.active_games: Dict[int, GameState] = {}
        self.pending_events: Dict[int, Dict] = {}
        self.dm_games: Dict[int, int] = {}  # user_id -> group_chat_id mapping
        
    @staticmethod
    def get_conversation_handler():
        """Get conversation handler for the game"""
        return ConversationHandler(
            entry_points=[
                CommandHandler('shit_game', lambda u, c: GameHandler._show_game_menu_command(u, c)),
                CommandHandler('shit_play', lambda u, c: GameHandler._start_new_game_command(u, c)),
                CommandHandler('shit_resume', lambda u, c: GameHandler._resume_game_command(u, c)),
                CallbackQueryHandler(lambda u, c: GameHandler._handle_callback(u, c), pattern="^shit_game$")
            ],
            states={
                GAME_MENU: [
                    CallbackQueryHandler(lambda u, c: GameHandler._handle_menu(u, c), pattern="^game_menu_")
                ],
                GAME_PLAYING: [
                    CallbackQueryHandler(lambda u, c: GameHandler._handle_game_action(u, c), pattern="^game_")
                ],
                LOCATION_SELECT: [
                    CallbackQueryHandler(lambda u, c: GameHandler._handle_location(u, c), pattern="^location_")
                ],
                BUY_MENU: [
                    CallbackQueryHandler(lambda u, c: GameHandler._handle_buy_select(u, c), pattern="^buy_"),
                    MessageHandler(filters.TEXT & ~filters.COMMAND, lambda u, c: GameHandler._handle_amount_input(u, c))
                ],
                SELL_MENU: [
                    CallbackQueryHandler(lambda u, c: GameHandler._handle_sell_select(u, c), pattern="^sell_"),
                    MessageHandler(filters.TEXT & ~filters.COMMAND, lambda u, c: GameHandler._handle_amount_input(u, c))
                ],
                AMOUNT_INPUT: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, lambda u, c: GameHandler._handle_amount_input(u, c)),
                    CallbackQueryHandler(lambda u, c: GameHandler._handle_quick_amount(u, c), pattern="^amount_")
                ],
                EVENT_RESPONSE: [
                    CallbackQueryHandler(lambda u, c: GameHandler._handle_event_response(u, c), pattern="^event_")
                ],
                BANK_MENU: [
                    CallbackQueryHandler(lambda u, c: GameHandler._handle_bank_action(u, c), pattern="^bank_"),
                    MessageHandler(filters.TEXT & ~filters.COMMAND, lambda u, c: GameHandler._handle_amount_input(u, c))
                ],
                ADMIN_MENU: [
                    CallbackQueryHandler(lambda u, c: GameHandler._handle_admin_action(u, c), pattern="^admin_game_"),
                    MessageHandler(filters.TEXT & ~filters.COMMAND, lambda u, c: GameHandler._handle_admin_input(u, c))
                ],
                COMPETITION_MENU: [
                    CallbackQueryHandler(lambda u, c: GameHandler._handle_competition(u, c), pattern="^comp_")
                ]
            },
            fallbacks=[
                CommandHandler('shit_cancel', lambda u, c: ConversationHandler.END),
                CallbackQueryHandler(lambda u, c: GameHandler._quit_game(u, c), pattern="^quit_confirm$")
            ],
            per_user=True,
            per_chat=False,
            allow_reentry=True,
            name="dopewars_game"
        )
    
    async def show_game_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Show main game menu"""
        user = update.effective_user
        
        # Check for saved game
        saved_game = await self.db.get_saved_game(user.id)
        
        keyboard = [
            [InlineKeyboardButton("🎮 New Game", callback_data="game_menu_new")],
        ]
        
        if saved_game:
            keyboard.append([
                InlineKeyboardButton("💾 Continue Game", callback_data="game_menu_continue")
            ])
        
        keyboard.extend([
            [
                InlineKeyboardButton("🏆 Leaderboard", callback_data="game_menu_leaderboard"),
                InlineKeyboardButton("📊 My Stats", callback_data="game_menu_stats")
            ],
            [
                InlineKeyboardButton("🏅 Competitions", callback_data="game_menu_competitions"),
                InlineKeyboardButton("📖 How to Play", callback_data="game_menu_help")
            ]
        ])
        
        if is_admin_user(user.id):
            keyboard.append([
                InlineKeyboardButton("⚙️ Admin Settings", callback_data="game_menu_admin")
            ])
        
        keyboard.append([
            InlineKeyboardButton("🔙 Back to Main", callback_data="back_to_main")
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = (
            "🎮 **DopeWars - Crypto Edition**\n\n"
            "Buy low, sell high, and become the crypto kingpin!\n\n"
            "Start with $2,000 cash and $5,500 in debt.\n"
            "You have 30 days to make your fortune!"
        )
        
        if update.callback_query:
            await update.callback_query.edit_message_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        else:
            await update.message.reply_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        
        return GAME_MENU
    
    async def start_new_game(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Start a new game"""
        user = update.effective_user
        
        # Check if user has a game in progress
        if user.id in self.active_games:
            keyboard = [[
                InlineKeyboardButton("✅ Yes, start new", callback_data="game_confirm_new"),
                InlineKeyboardButton("❌ No, continue", callback_data="game_playing")
            ]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.callback_query.edit_message_text(
                "⚠️ You have a game in progress. Start a new one?",
                reply_markup=reply_markup
            )
            return GAME_PLAYING
        
        # Create new game
        game_state = self.game.create_new_game(user.id, user.username or f"Player{user.id}")
        self.active_games[user.id] = game_state
        
        # Save to database
        await self.db.save_game_state(user.id, game_state)
        
        # Check if this should be a DM game
        if update.effective_chat.type != 'private':
            self.dm_games[user.id] = update.effective_chat.id
            
            # Send game to DM
            try:
                await context.bot.send_message(
                    chat_id=user.id,
                    text="🎮 Your DopeWars game has started! Continue playing here.",
                    parse_mode=ParseMode.MARKDOWN
                )
                
                # Notify in group
                await update.callback_query.edit_message_text(
                    f"🎮 {user.first_name} started a new DopeWars game!\n"
                    f"The game has been sent to their DM."
                )
            except:
                # Can't send DM, play in group
                del self.dm_games[user.id]
        
        return await self.show_game_interface(update, context)
    
    async def show_game_interface(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Show main game interface"""
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        if not game_state:
            await update.callback_query.answer("No active game! Starting new one...")
            return await self.start_new_game(update, context)
        
        # Check for game over
        if game_state.is_game_over_flag:
            return await self.handle_game_over(update, context)
        
        # Build interface
        status_text = self.game.format_game_status(game_state)
        
        # Check for pending events
        if user.id in self.pending_events:
            event = self.pending_events[user.id]
            return await self.show_event_prompt(update, context, event)
        
        # Main game buttons
        keyboard = []
        
        # Location-specific options
        if game_state.current_location == self.game.locations[0]:  # Bronx (home)
            keyboard.append([
                InlineKeyboardButton("🏦 Bank", callback_data="game_bank"),
                InlineKeyboardButton("🦈 Loan Shark", callback_data="game_loan_shark")
            ])
        
        keyboard.extend([
            [
                InlineKeyboardButton("💰 Buy", callback_data="game_buy"),
                InlineKeyboardButton("💸 Sell", callback_data="game_sell"),
                InlineKeyboardButton("✈️ Travel", callback_data="game_travel")
            ],
            [
                InlineKeyboardButton("📊 Prices", callback_data="game_prices"),
                InlineKeyboardButton("🎒 Inventory", callback_data="game_inventory"),
                InlineKeyboardButton("📈 Stats", callback_data="game_stats")
            ],
            [
                InlineKeyboardButton("💾 Save & Quit", callback_data="game_save_quit"),
                InlineKeyboardButton("🚪 Quit", callback_data="game_quit")
            ]
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Update message
        try:
            if update.callback_query:
                await update.callback_query.edit_message_text(
                    status_text, 
                    reply_markup=reply_markup, 
                    parse_mode=ParseMode.MARKDOWN
                )
            else:
                await update.message.reply_text(
                    status_text, 
                    reply_markup=reply_markup, 
                    parse_mode=ParseMode.MARKDOWN
                )
        except:
            # Message not modified error - send new message
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=status_text,
                reply_markup=reply_markup,
                parse_mode=ParseMode.MARKDOWN
            )
        
        return GAME_PLAYING
    
    async def handle_game_action(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle game actions"""
        query = update.callback_query
        await query.answer()
        
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        if not game_state:
            await query.answer("No active game!", show_alert=True)
            return await self.show_game_menu(update, context)
        
        action = query.data.replace('game_', '')
        
        if action == 'buy':
            return await self.show_buy_menu(update, context)
        elif action == 'sell':
            return await self.show_sell_menu(update, context)
        elif action == 'travel':
            return await self.show_travel_menu(update, context)
        elif action == 'bank':
            return await self.show_bank_menu(update, context)
        elif action == 'loan_shark':
            return await self.show_loan_shark_menu(update, context)
        elif action == 'prices':
            return await self.show_prices(update, context)
        elif action == 'inventory':
            return await self.show_inventory(update, context)
        elif action == 'stats':
            return await self.show_game_stats(update, context)
        elif action == 'save_quit':
            return await self.save_and_quit(update, context)
        elif action == 'quit':
            return await self.confirm_quit(update, context)
        
        return GAME_PLAYING
    
    async def show_buy_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Show buy menu with current prices"""
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        prices_text = self.game.format_prices(game_state)
        used, max_space = self.game.get_inventory_space(game_state)
        
        text = (
            f"{prices_text}\n\n"
            f"💰 Cash: ${game_state.cash:,}\n"
            f"🎒 Space: {used}/{max_space}\n\n"
            f"What would you like to buy?"
        )
        
        # Create drug selection buttons
        keyboard = []
        row = []
        for i, (drug_id, drug_info) in enumerate(self.game.drugs.items()):
            price = game_state.current_prices[drug_id]
            max_amount = min(game_state.cash // price, max_space - used)
            
            if max_amount > 0:
                button_text = f"{drug_info['emoji']} {drug_info['name']}"
                row.append(InlineKeyboardButton(button_text, callback_data=f"buy_{drug_id}"))
                
                if len(row) == 2:
                    keyboard.append(row)
                    row = []
        
        if row:
            keyboard.append(row)
        
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="game_playing")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        return BUY_MENU
    
    async def handle_buy_select(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle drug selection for buying"""
        query = update.callback_query
        await query.answer()
        
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        drug_id = query.data.replace('buy_', '')
        
        if drug_id == 'playing':  # Back button
            return await self.show_game_interface(update, context)
        
        # Store selected drug
        context.user_data['selected_drug'] = drug_id
        context.user_data['transaction_type'] = 'buy'
        
        # Calculate max amount
        price = game_state.current_prices[drug_id]
        used, max_space = self.game.get_inventory_space(game_state)
        max_amount = min(game_state.cash // price, max_space - used)
        
        drug_info = self.game.drugs[drug_id]
        
        # Show amount input interface
        keyboard = [
            [
                InlineKeyboardButton("1", callback_data="amount_1"),
                InlineKeyboardButton("5", callback_data="amount_5"),
                InlineKeyboardButton("10", callback_data="amount_10"),
                InlineKeyboardButton("25", callback_data="amount_25")
            ],
            [
                InlineKeyboardButton("25%", callback_data="amount_25p"),
                InlineKeyboardButton("50%", callback_data="amount_50p"),
                InlineKeyboardButton("75%", callback_data="amount_75p"),
                InlineKeyboardButton("MAX", callback_data="amount_100p")
            ],
            [InlineKeyboardButton("🔙 Back", callback_data="buy_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = (
            f"💰 **Buying {drug_info['emoji']} {drug_info['name']}**\n\n"
            f"Price: ${price:,} each\n"
            f"Max you can buy: {max_amount}\n"
            f"Total cost for max: ${price * max_amount:,}\n\n"
            f"Enter amount or use quick buttons:"
        )
        
        await query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        return AMOUNT_INPUT
    
    async def show_sell_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Show sell menu with inventory"""
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        if not game_state.inventory:
            await update.callback_query.answer("You have nothing to sell!", show_alert=True)
            return await self.show_game_interface(update, context)
        
        inventory_text = self.game.format_inventory(game_state)
        
        text = (
            f"{inventory_text}\n\n"
            f"What would you like to sell?"
        )
        
        # Create drug selection buttons
        keyboard = []
        row = []
        for i, (drug_id, amount) in enumerate(game_state.inventory.items()):
            drug_info = self.game.drugs[drug_id]
            button_text = f"{drug_info['emoji']} {drug_info['name']} ({amount})"
            row.append(InlineKeyboardButton(button_text, callback_data=f"sell_{drug_id}"))
            
            if len(row) == 2:
                keyboard.append(row)
                row = []
        
        if row:
            keyboard.append(row)
        
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="game_playing")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        return SELL_MENU
    
    async def handle_sell_select(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle drug selection for selling"""
        query = update.callback_query
        await query.answer()
        
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        drug_id = query.data.replace('sell_', '')
        
        if drug_id == 'playing':  # Back button
            return await self.show_game_interface(update, context)
        
        # Store selected drug
        context.user_data['selected_drug'] = drug_id
        context.user_data['transaction_type'] = 'sell'
        
        # Get drug info
        drug_info = self.game.drugs[drug_id]
        amount_owned = game_state.inventory.get(drug_id, 0)
        current_price = game_state.current_prices[drug_id]
        
        # Calculate profit/loss
        profit_text = ""
        if drug_id in game_state.inventory_costs:
            avg_cost = game_state.inventory_costs[drug_id]
            profit_per_unit = current_price - avg_cost
            total_profit = profit_per_unit * amount_owned
            
            if profit_per_unit > 0:
                profit_text = f"📈 Profit: ${profit_per_unit:,} per unit (${total_profit:,} total)"
            else:
                profit_text = f"📉 Loss: ${abs(profit_per_unit):,} per unit (${abs(total_profit):,} total)"
        
        # Show amount input interface
        keyboard = [
            [
                InlineKeyboardButton("1", callback_data="amount_1"),
                InlineKeyboardButton("5", callback_data="amount_5"),
                InlineKeyboardButton("10", callback_data="amount_10"),
                InlineKeyboardButton("25", callback_data="amount_25")
            ],
            [
                InlineKeyboardButton("25%", callback_data="amount_25p"),
                InlineKeyboardButton("50%", callback_data="amount_50p"),
                InlineKeyboardButton("75%", callback_data="amount_75p"),
                InlineKeyboardButton("ALL", callback_data="amount_100p")
            ],
            [InlineKeyboardButton("🔙 Back", callback_data="sell_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = (
            f"💸 **Selling {drug_info['emoji']} {drug_info['name']}**\n\n"
            f"You have: {amount_owned}\n"
            f"Current price: ${current_price:,} each\n"
            f"Total value: ${current_price * amount_owned:,}\n"
            f"{profit_text}\n\n"
            f"Enter amount or use quick buttons:"
        )
        
        await query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        return AMOUNT_INPUT
    
    async def handle_amount_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle amount input (text or buttons)"""
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        if not game_state:
            return ConversationHandler.END
        
        # Get stored transaction info
        drug_id = context.user_data.get('selected_drug')
        transaction_type = context.user_data.get('transaction_type')
        
        if not drug_id or not transaction_type:
            await update.message.reply_text("❌ Transaction expired. Please try again.")
            return await self.show_game_interface(update, context)
        
        # Parse amount
        try:
            amount = int(update.message.text.strip())
            if amount <= 0:
                raise ValueError()
        except:
            await update.message.reply_text("❌ Please enter a valid number!")
            return AMOUNT_INPUT
        
        # Process transaction
        if transaction_type == 'buy':
            result = self.game.buy_drug(game_state, drug_id, amount)
        elif transaction_type == 'sell':
            result = self.game.sell_drug(game_state, drug_id, amount)
        else:
            result = {'success': False, 'message': 'Invalid transaction type'}
        
        # Show result
        if result['success']:
            await update.message.reply_text(f"✅ {result['message']}")
            
            # Save game state
            await self.db.save_game_state(user.id, game_state)
            
            # Return to game interface
            return await self.show_game_interface(update, context)
        else:
            await update.message.reply_text(f"❌ {result['message']}")
            return AMOUNT_INPUT
    
    async def handle_quick_amount(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle quick amount button presses"""
        query = update.callback_query
        await query.answer()
        
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        if not game_state:
            return ConversationHandler.END
        
        # Get stored transaction info
        drug_id = context.user_data.get('selected_drug')
        transaction_type = context.user_data.get('transaction_type')
        
        if not drug_id or not transaction_type:
            await query.answer("Transaction expired!", show_alert=True)
            return await self.show_game_interface(update, context)
        
        # Parse amount from callback data
        amount_str = query.data.replace('amount_', '')
        
        if amount_str == 'menu':  # Back button
            if transaction_type == 'buy':
                return await self.show_buy_menu(update, context)
            else:
                return await self.show_sell_menu(update, context)
        
        # Calculate amount
        if amount_str.endswith('p'):  # Percentage
            percentage = int(amount_str[:-1]) / 100
            
            if transaction_type == 'buy':
                price = game_state.current_prices[drug_id]
                used, max_space = self.game.get_inventory_space(game_state)
                max_amount = min(game_state.cash // price, max_space - used)
                amount = int(max_amount * percentage)
            else:  # sell
                amount = int(game_state.inventory[drug_id] * percentage)
        else:  # Fixed amount
            amount = int(amount_str)
        
        if amount <= 0:
            await query.answer("Invalid amount!", show_alert=True)
            return AMOUNT_INPUT
        
        # Process transaction
        if transaction_type == 'buy':
            result = self.game.buy_drug(game_state, drug_id, amount)
        else:  # sell
            result = self.game.sell_drug(game_state, drug_id, amount)
        
        # Show result
        await query.answer(result['message'], show_alert=True)
        
        if result['success']:
            # Save game state
            await self.db.save_game_state(user.id, game_state)
            
            # Return to game interface
            return await self.show_game_interface(update, context)
        else:
            return AMOUNT_INPUT
    
    async def show_travel_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Show travel destinations"""
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        text = (
            f"✈️ **Travel to a new location**\n\n"
            f"Current location: {game_state.current_location}\n"
            f"Day: {game_state.day}/{game_state.max_days}\n\n"
            f"⚠️ Traveling advances one day and changes prices!\n\n"
            f"Where would you like to go?"
        )
        
        # Create location buttons
        keyboard = []
        row = []
        for i, location in enumerate(self.game.locations):
            if location != game_state.current_location:
                row.append(InlineKeyboardButton(location, callback_data=f"location_{i}"))
                
                if len(row) == 2:
                    keyboard.append(row)
                    row = []
        
        if row:
            keyboard.append(row)
        
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="game_playing")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        return LOCATION_SELECT
    
    async def handle_location_select(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle location selection"""
        query = update.callback_query
        await query.answer()
        
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        if query.data == 'game_playing':  # Back button
            return await self.show_game_interface(update, context)
        
        location_index = int(query.data.replace('location_', ''))
        location = self.game.locations[location_index]
        
        # Travel to new location
        result = self.game.travel(game_state, location)
        
        if not result['success']:
            await query.answer(result['message'], show_alert=True)
            return LOCATION_SELECT
        
        # Show events
        event_messages = []
        
        # Market events
        for event in result.get('market_events', []):
            event_messages.append(event['message'])
        
        # Random events
        for event in result.get('events', []):
            # Check if this is an interactive event
            if '|' in event:
                parts = event.split('|')
                event_type = parts[0]
                
                if event_type in ['coat_upgrade', 'gun_offer', 'whale_offer']:
                    # Store event for later handling
                    self.pending_events[user.id] = {
                        'type': event_type,
                        'data': parts,
                        'message': parts[-1]
                    }
                else:
                    event_messages.append(event)
            else:
                event_messages.append(event)
        
        # Show all events at once
        if event_messages:
            events_text = '\n\n'.join(event_messages)
            await query.answer(events_text[:200], show_alert=True)  # Telegram limit
            
            # Send full events as message if too long
            if len(events_text) > 200:
                await context.bot.send_message(
                    chat_id=update.effective_chat.id,
                    text=f"📰 **Events:**\n\n{events_text}",
                    parse_mode=ParseMode.MARKDOWN
                )
        
        # Save game state
        await self.db.save_game_state(user.id, game_state)
        
        # Show game interface or event prompt
        return await self.show_game_interface(update, context)
    
    async def show_event_prompt(self, update: Update, context: ContextTypes.DEFAULT_TYPE, event: Dict) -> int:
        """Show interactive event prompt"""
        event_type = event['type']
        data = event['data']
        message = event['message']
        
        keyboard = [
            [
                InlineKeyboardButton("✅ Accept", callback_data=f"event_accept_{event_type}"),
                InlineKeyboardButton("❌ Decline", callback_data=f"event_decline_{event_type}")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = f"🎲 **Random Event!**\n\n{message}"
        
        if update.callback_query:
            await update.callback_query.edit_message_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        else:
            await update.message.reply_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        
        return EVENT_RESPONSE
    
    async def handle_event_response(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle response to random events"""
        query = update.callback_query
        await query.answer()
        
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        if user.id not in self.pending_events:
            await query.answer("Event expired!", show_alert=True)
            return await self.show_game_interface(update, context)
        
        event = self.pending_events[user.id]
        parts = query.data.split('_')
        response = parts[1]  # accept or decline
        
        event_data = {}
        if event['type'] == 'coat_upgrade':
            event_data['price'] = int(event['data'][1])
        elif event['type'] == 'gun_offer':
            event_data['price'] = int(event['data'][1])
        elif event['type'] == 'whale_offer':
            event_data['drug'] = event['data'][1]
            event_data['amount'] = int(event['data'][2])
            event_data['price'] = int(event['data'][3])
        
        # Handle event
        result = self.game.handle_event_response(
            game_state, 
            event['type'], 
            response == 'accept',
            event_data
        )
        
        # Clear pending event
        del self.pending_events[user.id]
        
        # Show result
        await query.answer(result['message'], show_alert=True)
        
        # Save game state
        await self.db.save_game_state(user.id, game_state)
        
        # Back to game
        return await self.show_game_interface(update, context)
    
    async def show_bank_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Show bank menu"""
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        text = (
            f"🏦 **Bank of Shibarium**\n\n"
            f"💰 Cash: ${game_state.cash:,}\n"
            f"🏦 Bank Balance: ${game_state.bank_balance:,}\n"
            f"📈 Daily Interest: {self.game.bank_interest * 100:.0f}%\n\n"
            f"What would you like to do?"
        )
        
        keyboard = [
            [
                InlineKeyboardButton("💵 Deposit", callback_data="bank_deposit"),
                InlineKeyboardButton("💸 Withdraw", callback_data="bank_withdraw")
            ],
            [InlineKeyboardButton("🔙 Back", callback_data="game_playing")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        return BANK_MENU
    
    async def handle_bank_action(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle bank actions"""
        query = update.callback_query
        await query.answer()
        
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        action = query.data.replace('bank_', '')
        
        if action == 'playing':  # Back button
            return await self.show_game_interface(update, context)
        
        # Store transaction type
        context.user_data['bank_action'] = action
        context.user_data['transaction_type'] = f'bank_{action}'
        
        if action == 'deposit':
            max_amount = game_state.cash
            text = (
                f"💵 **Bank Deposit**\n\n"
                f"Cash available: ${game_state.cash:,}\n"
                f"Current balance: ${game_state.bank_balance:,}\n\n"
                f"How much would you like to deposit?"
            )
        else:  # withdraw
            max_amount = game_state.bank_balance
            text = (
                f"💸 **Bank Withdrawal**\n\n"
                f"Bank balance: ${game_state.bank_balance:,}\n"
                f"Current cash: ${game_state.cash:,}\n\n"
                f"How much would you like to withdraw?"
            )
        
        # Quick amount buttons
        keyboard = []
        if max_amount > 0:
            keyboard = [
                [
                    InlineKeyboardButton("$100", callback_data="amount_100"),
                    InlineKeyboardButton("$500", callback_data="amount_500"),
                    InlineKeyboardButton("$1000", callback_data="amount_1000")
                ],
                [
                    InlineKeyboardButton("25%", callback_data="amount_25p"),
                    InlineKeyboardButton("50%", callback_data="amount_50p"),
                    InlineKeyboardButton("ALL", callback_data="amount_100p")
                ]
            ]
        
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="bank_menu")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        return AMOUNT_INPUT
    
    async def show_loan_shark_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Show loan shark menu"""
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        text = (
            f"🦈 **Loan Shark**\n\n"
            f"💸 Your Debt: ${game_state.debt:,}\n"
            f"💰 Your Cash: ${game_state.cash:,}\n"
            f"📈 Daily Interest: {self.game.debt_interest * 100:.0f}%\n\n"
        )
        
        if game_state.debt == 0:
            text += "✅ You've paid off your debt! Well done!"
            keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="game_playing")]]
        else:
            text += "How much would you like to pay?"
            
            # Payment buttons
            keyboard = []
            if game_state.cash > 0:
                keyboard = [
                    [
                        InlineKeyboardButton("$100", callback_data="debt_100"),
                        InlineKeyboardButton("$500", callback_data="debt_500"),
                        InlineKeyboardButton("$1000", callback_data="debt_1000")
                    ],
                    [
                        InlineKeyboardButton("25%", callback_data="debt_25p"),
                        InlineKeyboardButton("50%", callback_data="debt_50p"),
                        InlineKeyboardButton("Pay All", callback_data="debt_all")
                    ]
                ]
            
            keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="game_playing")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        # Set context for debt payment
        context.user_data['transaction_type'] = 'pay_debt'
        
        return BANK_MENU
    
    async def show_prices(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Show current drug prices"""
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        prices_text = self.game.format_prices(game_state)
        
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="game_playing")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            prices_text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        return GAME_PLAYING
    
    async def show_inventory(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Show current inventory"""
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        inventory_text = self.game.format_inventory(game_state)
        
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="game_playing")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            inventory_text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        return GAME_PLAYING
    
    async def show_game_stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Show detailed game statistics"""
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        inventory_value = self.game.get_inventory_value(game_state)
        net_worth = game_state.cash + game_state.bank_balance + inventory_value - game_state.debt
        
        text = (
            f"📊 **Game Statistics**\n\n"
            f"**Financial:**\n"
            f"💎 Net Worth: ${net_worth:,}\n"
            f"💰 Cash: ${game_state.cash:,}\n"
            f"🏦 Bank: ${game_state.bank_balance:,}\n"
            f"🎒 Inventory Value: ${inventory_value:,}\n"
            f"💸 Debt: ${game_state.debt:,}\n\n"
            f"**Trading:**\n"
            f"📈 Total Purchases: {game_state.total_purchases}\n"
            f"📉 Total Sales: {game_state.total_sales}\n"
            f"💹 Total Profit: ${game_state.total_profit:,}\n\n"
            f"**Progress:**\n"
            f"📅 Day: {game_state.day}/{game_state.max_days}\n"
            f"❤️ Health: {game_state.health}/{game_state.max_health}\n"
            f"🔫 Guns: {game_state.guns}\n"
            f"🎒 Inventory: {sum(game_state.inventory.values())}/{game_state.max_inventory}\n"
            f"📍 Locations Visited: {len(game_state.locations_visited)}\n"
            f"🎲 Events Encountered: {len(game_state.events_encountered)}"
        )
        
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="game_playing")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        return GAME_PLAYING
    
    async def save_and_quit(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Save game and quit"""
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        if game_state:
            # Save to database
            await self.db.save_game_state(user.id, game_state)
            
            # Remove from active games
            del self.active_games[user.id]
            if user.id in self.pending_events:
                del self.pending_events[user.id]
            if user.id in self.dm_games:
                del self.dm_games[user.id]
        
        await update.callback_query.answer("Game saved!", show_alert=True)
        
        # Back to menu
        return await self.show_game_menu(update, context)
    
    async def confirm_quit(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Confirm quit without saving"""
        keyboard = [[
            InlineKeyboardButton("⚠️ Yes, quit", callback_data="quit_confirm"),
            InlineKeyboardButton("🔙 No, continue", callback_data="game_playing")
        ]]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            "⚠️ **Are you sure?**\n\nQuitting without saving will lose all progress!",
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
        
        return GAME_PLAYING
    
    async def handle_game_over(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle game over state"""
        user = update.effective_user
        game_state = self.active_games.get(user.id)
        
        # Calculate final score
        score = self.game.calculate_score(game_state)
        
        # Save to leaderboard
        await self.leaderboard.add_score(user.id, user.username, score, game_state)
        
        # Update player stats
        await self.db.update_player_stats(user.id, game_state, score)
        
        # Remove from active games
        del self.active_games[user.id]
        if user.id in self.pending_events:
            del self.pending_events[user.id]
        if user.id in self.dm_games:
            del self.dm_games[user.id]
        
        # Clear saved game
        await self.db.delete_saved_game(user.id)
        
        # Show game over screen
        text = (
            f"🎮 **GAME OVER**\n\n"
            f"{game_state.game_over_reason}\n\n"
            f"**Final Stats:**\n"
            f"📊 Score: ${score:,}\n"
            f"📅 Days Survived: {game_state.days_survived}\n"
            f"💰 Final Cash: ${game_state.cash:,}\n"
            f"🏦 Bank Balance: ${game_state.bank_balance:,}\n"
            f"💸 Final Debt: ${game_state.debt:,}\n"
            f"❤️ Final Health: {game_state.health}/{game_state.max_health}\n\n"
        )
        
        # Check for achievements
        if game_state.debt == 0:
            text += "🏆 **Achievement:** Debt Free!\n"
        if score > 1000000:
            text += "🏆 **Achievement:** Millionaire!\n"
        if game_state.days_survived >= game_state.max_days:
            text += "🏆 **Achievement:** Survivor!\n"
        
        # Show position on leaderboard
        position = await self.leaderboard.get_player_position(user.id)
        if position:
            text += f"\n🏅 Leaderboard Position: #{position}"
        
        keyboard = [
            [
                InlineKeyboardButton("🎮 Play Again", callback_data="game_menu_new"),
                InlineKeyboardButton("🏆 Leaderboard", callback_data="game_menu_leaderboard")
            ],
            [InlineKeyboardButton("🔙 Main Menu", callback_data="game_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        if update.callback_query:
            await update.callback_query.edit_message_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        else:
            await update.message.reply_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        
        return GAME_MENU
    
    # ... (Additional handler methods for leaderboard, stats, competitions, admin menu continue...)
    
    # Static method wrappers continue with the same pattern as shown above...