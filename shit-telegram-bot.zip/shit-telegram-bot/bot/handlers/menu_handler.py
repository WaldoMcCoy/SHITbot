#!/usr/bin/env python3
"""
# File location: /bot/handlers/menu_handler.py
Enhanced Main Menu Handler for S.H.I.T. Bot
Handles main navigation between the three apps with improved UX
"""

import logging
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, CallbackQueryHandler
from telegram.constants import ParseMode
from bot.utils.helpers import is_admin_user

logger = logging.getLogger(__name__)


class MenuHandler:
    """Enhanced main menu navigation handler"""
    
    def __init__(self, db):
        self.db = db
    
    @staticmethod
    async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle menu callbacks"""
        query = update.callback_query
        handler = context.bot_data.get('menu_handler')
        
        if not handler:
            await query.answer("Bot is initializing...", show_alert=True)
            return
        
        # Route to appropriate handler
        data = query.data
        
        if data == "back_to_main":
            await handler.show_main_menu(update, context)
        elif data == "shit_help":
            await handler.show_help_menu(update, context)
        elif data == "shit_status":
            await handler.show_status(update, context)
        elif data == "shit_settings":
            await handler.show_settings(update, context)
        elif data == "shit_ai":
            # Delegate to AI handler
            chat_handler = context.bot_data.get('chat_handler')
            if chat_handler:
                await chat_handler.start_chat(update, context)
        elif data == "shit_tracker":
            # Delegate to tracker handler
            tracker_handler = context.bot_data.get('tracker_handler')
            if tracker_handler:
                await tracker_handler.start_tracking(update, context)
        elif data == "shit_game":
            # Delegate to game handler
            game_handler = context.bot_data.get('game_handler')
            if game_handler:
                await game_handler.show_game_menu(update, context)
        
        await query.answer()
    
    async def show_main_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Display enhanced main menu"""
        user = update.effective_user
        
        # Get user stats for personalization
        user_stats = await self.db.get_user_activity(user.id)
        
        # Build keyboard
        keyboard = [
            [
                InlineKeyboardButton("🤖 ShitAI Chat", callback_data="shit_ai"),
                InlineKeyboardButton("📊 SHIT Tracker", callback_data="shit_tracker")
            ],
            [
                InlineKeyboardButton("🎮 DopeWars Game", callback_data="shit_game"),
                InlineKeyboardButton("❓ Help", callback_data="shit_help")
            ],
            [
                InlineKeyboardButton("ℹ️ Bot Status", callback_data="shit_status"),
                InlineKeyboardButton("⚙️ Settings", callback_data="shit_settings")
            ]
        ]
        
        # Add admin button if user is admin
        if is_admin_user(user.id):
            keyboard.append([
                InlineKeyboardButton("👮 Admin Panel", callback_data="shit_admin")
            ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Create personalized greeting
        greeting = self._get_greeting()
        username = user.first_name or user.username or "Trader"
        
        # Build status indicators
        status_text = self._build_status_text(user_stats)
        
        text = (
            f"{greeting} {username}! 👋\n\n"
            f"📋 **S.H.I.T. Bot Main Menu**\n"
            f"_Shibarium Historical Income Tracker_\n\n"
            f"{status_text}\n"
            f"What would you like to do today?"
        )
        
        if update.callback_query:
            await update.callback_query.edit_message_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        else:
            await update.message.reply_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
    
    async def show_help_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show detailed help menu"""
        keyboard = [
            [
                InlineKeyboardButton("🤖 AI Help", callback_data="help_ai"),
                InlineKeyboardButton("📊 Tracker Help", callback_data="help_tracker")
            ],
            [
                InlineKeyboardButton("🎮 Game Help", callback_data="help_game"),
                InlineKeyboardButton("⚙️ Settings Help", callback_data="help_settings")
            ],
            [
                InlineKeyboardButton("📚 All Commands", callback_data="help_commands"),
                InlineKeyboardButton("💬 Support", url="https://t.me/YourSupportGroup")
            ],
            [InlineKeyboardButton("🔙 Back", callback_data="back_to_main")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = (
            "❓ **S.H.I.T. Bot Help Center**\n\n"
            "Choose a topic to learn more:\n\n"
            "**🤖 ShitAI** - AI-powered chat assistant\n"
            "**📊 SHIT Tracker** - Blockchain transaction tracking\n"
            "**🎮 DopeWars** - Crypto trading game\n\n"
            "Need help? Join our support group!"
        )
        
        await update.callback_query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
    
    async def show_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show bot status and statistics"""
        # Get system stats
        stats = await self.db.get_bot_statistics()
        
        # Check service status
        ollama_status = "✅ Online" if await self._check_ollama() else "❌ Offline"
        api_status = "✅ Active" if self._check_api_keys() else "⚠️ Not configured"
        
        # Get user's personal stats
        user = update.effective_user
        user_stats = await self.db.get_user_statistics(user.id)
        
        text = (
            "ℹ️ **Bot Status & Statistics**\n\n"
            f"**System Status:**\n"
            f"• Bot Version: `1.0.0`\n"
            f"• Uptime: {self._format_uptime(stats.get('uptime', 0))}\n"
            f"• Database: ✅ Connected\n"
            f"• Ollama AI: {ollama_status}\n"
            f"• Shibarium API: {api_status}\n\n"
            f"**Global Statistics:**\n"
            f"• Total Users: {stats.get('total_users', 0):,}\n"
            f"• Active Today: {stats.get('active_today', 0):,}\n"
            f"• Total Games: {stats.get('total_games', 0):,}\n"
            f"• Total Scans: {stats.get('total_scans', 0):,}\n"
            f"• AI Chats: {stats.get('total_chats', 0):,}\n\n"
            f"**Your Statistics:**\n"
            f"• Member Since: {user_stats.get('joined_date', 'Unknown')}\n"
            f"• Games Played: {user_stats.get('games_played', 0)}\n"
            f"• Scans Run: {user_stats.get('scans_run', 0)}\n"
            f"• AI Messages: {user_stats.get('ai_messages', 0)}\n"
        )
        
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="back_to_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
    
    async def show_settings(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show user settings menu"""
        user = update.effective_user
        settings = await self.db.get_user_settings(user.id)
        
        # Format current settings
        ai_mode = "🚀 Unlimited" if settings.get('ai_unlimited_mode', True) else "⚡ Limited"
        bold_mode = "On" if settings.get('ai_bold_mode', False) else "Off"
        auto_delete = "On" if settings.get('tracker_auto_delete', True) else "Off"
        notifications = "On" if settings.get('notifications_enabled', True) else "Off"
        
        keyboard = [
            [
                InlineKeyboardButton(f"AI Mode: {ai_mode}", callback_data="settings_ai_mode"),
                InlineKeyboardButton(f"Bold Text: {bold_mode}", callback_data="settings_bold")
            ],
            [
                InlineKeyboardButton(f"Auto-delete Files: {auto_delete}", callback_data="settings_auto_delete"),
                InlineKeyboardButton(f"Notifications: {notifications}", callback_data="settings_notifications")
            ],
            [
                InlineKeyboardButton("🗑️ Clear Data", callback_data="settings_clear_data"),
                InlineKeyboardButton("📤 Export Data", callback_data="settings_export")
            ],
            [InlineKeyboardButton("🔙 Back", callback_data="back_to_main")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = (
            "⚙️ **User Settings**\n\n"
            "Configure your bot preferences:\n\n"
            f"**AI Chat:**\n"
            f"• Response Mode: {ai_mode}\n"
            f"• Bold Responses: {bold_mode}\n\n"
            f"**Tracker:**\n"
            f"• Auto-delete Files: {auto_delete}\n\n"
            f"**General:**\n"
            f"• Notifications: {notifications}\n\n"
            "Click buttons to toggle settings."
        )
        
        await update.callback_query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
    
    def _get_greeting(self) -> str:
        """Get time-based greeting"""
        hour = datetime.now().hour
        if hour < 12:
            return "Good morning"
        elif hour < 17:
            return "Good afternoon"
        else:
            return "Good evening"
    
    def _build_status_text(self, user_stats: dict) -> str:
        """Build personalized status text"""
        indicators = []
        
        # Check for active game
        if user_stats.get('active_game'):
            game_day = user_stats['active_game']['day']
            indicators.append(f"🎮 Game in progress (Day {game_day}/30)")
        
        # Check recent scans
        if user_stats.get('recent_scan'):
            scan_time = user_stats['recent_scan']['time_ago']
            indicators.append(f"📊 Last scan: {scan_time}")
        
        # Check AI chat
        if user_stats.get('active_chat'):
            model = user_stats['active_chat']['model']
            indicators.append(f"🤖 Chatting with {model}")
        
        if indicators:
            return '\n'.join(indicators) + '\n'
        else:
            return "✨ Ready to start!\n"
    
    async def _check_ollama(self) -> bool:
        """Check if Ollama is available"""
        try:
            import httpx
            ollama_host = os.getenv('OLLAMA_HOST', 'localhost')
            ollama_port = os.getenv('OLLAMA_PORT', '11434')
            
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"http://{ollama_host}:{ollama_port}/api/tags",
                    timeout=5.0
                )
                return response.status_code == 200
        except:
            return False
    
    def _check_api_keys(self) -> bool:
        """Check if API keys are configured"""
        import os
        return bool(os.getenv('SHIBARIUM_API_KEY'))
    
    def _format_uptime(self, seconds: int) -> str:
        """Format uptime in human-readable format"""
        days = seconds // 86400
        hours = (seconds % 86400) // 3600
        minutes = (seconds % 3600) // 60
        
        parts = []
        if days > 0:
            parts.append(f"{days}d")
        if hours > 0:
            parts.append(f"{hours}h")
        if minutes > 0:
            parts.append(f"{minutes}m")
        
        return ' '.join(parts) or "Just started"