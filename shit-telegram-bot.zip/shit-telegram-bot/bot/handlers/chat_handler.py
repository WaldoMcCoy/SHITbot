#!/usr/bin/env python3
"""
# File location: /bot/handlers/chat_handler.py
Enhanced AI Chat Handler for S.H.I.T. Bot
Manages conversation flow with Ollama AI models
"""

import asyncio
import logging
from typing import List, Dict, Any

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, Message
from telegram.ext import (
    ContextTypes,
    ConversationHandler,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters
)
from telegram.constants import ParseMode, ChatAction

from apps.shit_ai.chat_bot import ShitAIChatBot
from bot.utils.helpers import is_admin_user

logger = logging.getLogger(__name__)

# Conversation states
CHATTING, MODEL_SELECT, ADMIN_MENU, ADMIN_INPUT = range(4)


class ChatHandler:
    """Enhanced AI Chat handler with full Ollama integration"""
    
    def __init__(self, db):
        self.db = db
        self.chat_bot = ShitAIChatBot(db)
        self.active_chats = {}  # user_id -> message_id for streaming responses
        
    @staticmethod
    def get_conversation_handler():
        """Get conversation handler for AI chat"""
        return ConversationHandler(
            entry_points=[
                CommandHandler('shit_ai', lambda u, c: ChatHandler._start_chat_command(u, c)),
                CallbackQueryHandler(lambda u, c: ChatHandler._start_chat_callback(u, c), pattern="^shit_ai$")
            ],
            states={
                CHATTING: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, lambda u, c: ChatHandler._handle_message(u, c)),
                    CommandHandler('shit_models', lambda u, c: ChatHandler._show_models(u, c)),
                    CommandHandler('shit_model', lambda u, c: ChatHandler._change_model_command(u, c)),
                    CommandHandler('shit_mode', lambda u, c: ChatHandler._toggle_mode(u, c)),
                    CommandHandler('shit_clear', lambda u, c: ChatHandler._clear_chat(u, c)),
                    CallbackQueryHandler(lambda u, c: ChatHandler._handle_callback(u, c), pattern="^chat_")
                ],
                MODEL_SELECT: [
                    CallbackQueryHandler(lambda u, c: ChatHandler._handle_model_select(u, c), pattern="^model_"),
                    CallbackQueryHandler(lambda u, c: ChatHandler._back_to_chat(u, c), pattern="^back_chat$")
                ],
                ADMIN_MENU: [
                    CallbackQueryHandler(lambda u, c: ChatHandler._handle_admin_action(u, c), pattern="^admin_"),
                    CallbackQueryHandler(lambda u, c: ChatHandler._back_to_chat(u, c), pattern="^back_chat$")
                ],
                ADMIN_INPUT: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, lambda u, c: ChatHandler._handle_admin_input(u, c)),
                    CommandHandler('shit_cancel', lambda u, c: ChatHandler._cancel_admin_input(u, c))
                ]
            },
            fallbacks=[
                CommandHandler('shit_cancel', lambda u, c: ChatHandler._cancel_chat(u, c)),
            ],
            per_user=True,
            per_chat=False,
            allow_reentry=True,
            name="shit_ai_chat"
        )
    
    # Static method wrappers
    @staticmethod
    async def _start_chat_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.start_chat(update, context)
        return ConversationHandler.END
    
    @staticmethod
    async def _start_chat_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.start_chat(update, context)
        return ConversationHandler.END
    
    @staticmethod
    async def _handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.handle_message(update, context)
        return ConversationHandler.END
    
    @staticmethod
    async def _show_models(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.show_models(update, context)
        return ConversationHandler.END
    
    @staticmethod
    async def _change_model_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.show_model_selection(update, context)
        return ConversationHandler.END
    
    @staticmethod
    async def _toggle_mode(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.toggle_mode(update, context)
        return ConversationHandler.END
    
    @staticmethod
    async def _clear_chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.clear_chat(update, context)
        return ConversationHandler.END
    
    @staticmethod
    async def _handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.handle_callback(update, context)
        return ConversationHandler.END
    
    @staticmethod
    async def _handle_model_select(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.handle_model_select(update, context)
        return ConversationHandler.END
    
    @staticmethod
    async def _handle_admin_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.handle_admin_action(update, context)
        return ConversationHandler.END
    
    @staticmethod
    async def _handle_admin_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.handle_admin_input(update, context)
        return ConversationHandler.END
    
    @staticmethod
    async def _back_to_chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.back_to_chat(update, context)
        return ConversationHandler.END
    
    @staticmethod
    async def _cancel_chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.cancel_chat(update, context)
        return ConversationHandler.END
    
    @staticmethod
    async def _cancel_admin_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('chat_handler')
        if handler:
            return await handler.cancel_admin_input(update, context)
        return ConversationHandler.END
    
    async def start_chat(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Start AI chat session"""
        user = update.effective_user
        
        # Load or create session
        session = await self.chat_bot.load_session(user.id)
        if not session:
            session = self.chat_bot.get_or_create_session(user.id, user.username)
        
        # Check if Ollama is available
        models = await self.chat_bot.get_available_models()
        if not models:
            text = (
                "⚠️ **AI Service Unavailable**\n\n"
                "The Ollama AI service is not responding.\n"
                "Please ensure:\n"
                "• Ollama is installed and running\n"
                "• Models are downloaded (ollama pull llama2)\n"
                "• The service is accessible\n\n"
                "Contact an administrator if this persists."
            )
            
            if update.callback_query:
                await update.callback_query.answer()
                await update.callback_query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN)
            else:
                await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)
            
            return ConversationHandler.END
        
        # Build chat interface
        keyboard = []
        
        # Show current model and mode
        mode_text = "Limited" if session.limited_mode else "Unlimited"
        keyboard.append([
            InlineKeyboardButton(f"Model: {session.model}", callback_data="chat_model"),
            InlineKeyboardButton(f"Mode: {mode_text}", callback_data="chat_mode")
        ])
        
        # Admin options
        if is_admin_user(user.id):
            keyboard.append([
                InlineKeyboardButton("⚙️ Admin Settings", callback_data="chat_admin"),
                InlineKeyboardButton("🗑️ Clear History", callback_data="chat_clear")
            ])
        else:
            keyboard.append([
                InlineKeyboardButton("🗑️ Clear History", callback_data="chat_clear")
            ])
        
        keyboard.append([InlineKeyboardButton("❌ End Chat", callback_data="chat_end")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = (
            f"🤖 **ShitAI Chat**\n\n"
            f"Model: `{session.model}`\n"
            f"Mode: {mode_text} {'(' + str(self.chat_bot.character_limit) + ' chars)' if session.limited_mode else ''}\n\n"
            f"Send me a message to start chatting!\n"
            f"Use /shit_help for commands."
        )
        
        if update.callback_query:
            await update.callback_query.answer()
            await update.callback_query.edit_message_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        else:
            await update.message.reply_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        
        return CHATTING
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle user messages in chat"""
        user = update.effective_user
        message = update.message.text
        
        # Show typing indicator
        await context.bot.send_chat_action(
            chat_id=update.effective_chat.id,
            action=ChatAction.TYPING
        )
        
        # Start streaming response
        response_msg = await update.message.reply_text(
            "🤔 Thinking...",
            parse_mode=ParseMode.MARKDOWN
        )
        
        try:
            # Stream response from AI
            full_response = ""
            last_update_len = 0
            update_counter = 0
            
            async for chunk in self.chat_bot.process_message(
                user_id=user.id,
                message=message,
                username=user.username
            ):
                full_response += chunk
                update_counter += 1
                
                # Update message every few chunks to avoid rate limits
                if update_counter % 5 == 0 or len(full_response) - last_update_len > 100:
                    try:
                        # Format response
                        display_text = full_response
                        if self.chat_bot.bold_mode:
                            display_text = f"**{display_text}**"
                        
                        # Add typing indicator if still generating
                        if not chunk.endswith(('.', '!', '?', '\n')):
                            display_text += " ▌"
                        
                        await response_msg.edit_text(
                            display_text,
                            parse_mode=ParseMode.MARKDOWN
                        )
                        last_update_len = len(full_response)
                    except Exception as e:
                        logger.error(f"Error updating message: {e}")
            
            # Final update without cursor
            final_text = full_response
            if self.chat_bot.bold_mode:
                final_text = f"**{final_text}**"
            
            await response_msg.edit_text(
                final_text,
                parse_mode=ParseMode.MARKDOWN
            )
            
        except Exception as e:
            logger.error(f"Error processing message: {e}")
            await response_msg.edit_text(
                "❌ An error occurred while processing your message. Please try again.",
                parse_mode=ParseMode.MARKDOWN
            )
        
        return CHATTING
    
    async def show_models(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Show available models"""
        models = await self.chat_bot.get_available_models()
        
        if not models:
            await update.message.reply_text(
                "❌ No models available. Please check Ollama installation.",
                parse_mode=ParseMode.MARKDOWN
            )
            return CHATTING
        
        text = "🤖 **Available Models:**\n\n"
        for model in models:
            name = model.get('name', 'Unknown')
            size = model.get('size', 0) / (1024**3)  # Convert to GB
            modified = model.get('modified_at', 'Unknown')
            
            text += f"• `{name}` ({size:.1f}GB)\n"
        
        text += "\nUse /shit_model to change models."
        
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)
        return CHATTING
    
    async def show_model_selection(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Show model selection menu"""
        user = update.effective_user
        models = await self.chat_bot.get_available_models()
        
        if not models:
            await update.message.reply_text(
                "❌ No models available.",
                parse_mode=ParseMode.MARKDOWN
            )
            return CHATTING
        
        # Get current session
        session = self.chat_bot.get_or_create_session(user.id)
        
        keyboard = []
        for model in models:
            name = model.get('name', 'Unknown')
            # Mark current model
            display_name = f"✓ {name}" if name == session.model else name
            keyboard.append([
                InlineKeyboardButton(display_name, callback_data=f"model_{name}")
            ])
        
        keyboard.append([InlineKeyboardButton("« Cancel", callback_data="back_chat")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            "Select an AI model:",
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
        
        return MODEL_SELECT
    
    async def handle_model_select(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle model selection"""
        query = update.callback_query
        user = query.from_user
        
        await query.answer()
        
        model_name = query.data.replace('model_', '')
        
        # Change model
        success = await self.chat_bot.change_model(user.id, model_name)
        
        if success:
            await query.edit_message_text(
                f"✅ Model changed to: `{model_name}`\n\n"
                f"Chat history has been cleared.",
                parse_mode=ParseMode.MARKDOWN
            )
        else:
            await query.edit_message_text(
                f"❌ Failed to change model.",
                parse_mode=ParseMode.MARKDOWN
            )
        
        # Return to chat after delay
        await asyncio.sleep(2)
        return await self.start_chat(update, context)
    
    async def toggle_mode(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Toggle response mode"""
        user = update.effective_user
        
        mode_text = await self.chat_bot.toggle_mode(user.id)
        
        await update.message.reply_text(
            f"✅ {mode_text}",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return CHATTING
    
    async def clear_chat(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Clear chat history"""
        user = update.effective_user
        
        await self.chat_bot.clear_history(user.id)
        
        await update.message.reply_text(
            "✅ Chat history cleared!",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return CHATTING
    
    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle inline keyboard callbacks"""
        query = update.callback_query
        user = query.from_user
        
        await query.answer()
        
        if query.data == "chat_model":
            # Convert to command format and show model selection
            update._effective_message = query.message
            return await self.show_model_selection(update, context)
        
        elif query.data == "chat_mode":
            # Toggle mode
            mode_text = await self.chat_bot.toggle_mode(user.id)
            await query.answer(mode_text, show_alert=True)
            return await self.start_chat(update, context)
        
        elif query.data == "chat_clear":
            await self.chat_bot.clear_history(user.id)
            await query.answer("Chat history cleared!", show_alert=True)
            return await self.start_chat(update, context)
        
        elif query.data == "chat_admin":
            if is_admin_user(user.id):
                return await self.show_admin_menu(update, context)
            else:
                await query.answer("Admin access denied!", show_alert=True)
                return CHATTING
        
        elif query.data == "chat_end":
            await query.edit_message_text(
                "👋 Chat ended. Use /shit_ai to start again!",
                parse_mode=ParseMode.MARKDOWN
            )
            return ConversationHandler.END
        
        return CHATTING
    
    async def show_admin_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Show admin settings menu"""
        keyboard = [
            [
                InlineKeyboardButton("🤖 Default Model", callback_data="admin_default_model"),
                InlineKeyboardButton("🔢 Char Limit", callback_data="admin_char_limit")
            ],
            [
                InlineKeyboardButton("📝 Toggle Format", callback_data="admin_toggle_format"),
                InlineKeyboardButton("🅱️ Toggle Bold", callback_data="admin_toggle_bold")
            ],
            [
                InlineKeyboardButton("👁️ Hidden Models", callback_data="admin_hidden_models"),
                InlineKeyboardButton("📊 Stats", callback_data="admin_stats")
            ],
            [InlineKeyboardButton("« Back", callback_data="back_chat")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Get current settings
        format_status = "ON" if self.chat_bot.enable_formatting else "OFF"
        bold_status = "ON" if self.chat_bot.bold_mode else "OFF"
        
        text = (
            f"⚙️ **Admin Settings**\n\n"
            f"Default Model: `{self.chat_bot.default_model}`\n"
            f"Character Limit: {self.chat_bot.character_limit}\n"
            f"Formatting: {format_status}\n"
            f"Bold Mode: {bold_status}\n"
            f"Hidden Models: {len(self.chat_bot.hidden_models)}"
        )
        
        await update.callback_query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        return ADMIN_MENU
    
    async def handle_admin_action(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle admin actions"""
        query = update.callback_query
        await query.answer()
        
        action = query.data
        
        if action == "admin_default_model":
            # Show model selection for default
            models = await self.chat_bot.get_available_models(include_hidden=True)
            
            keyboard = []
            for model in models:
                name = model.get('name', 'Unknown')
                is_default = "✓ " if name == self.chat_bot.default_model else ""
                keyboard.append([
                    InlineKeyboardButton(f"{is_default}{name}", callback_data=f"admin_set_model_{name}")
                ])
            
            keyboard.append([InlineKeyboardButton("« Cancel", callback_data="back_admin")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                "Select default model:",
                reply_markup=reply_markup
            )
            
            return ADMIN_MENU
        
        elif action.startswith("admin_set_model_"):
            model_name = action.replace("admin_set_model_", "")
            success = await self.chat_bot.set_default_model(model_name)
            
            if success:
                await query.answer(f"Default model set to: {model_name}", show_alert=True)
            else:
                await query.answer("Failed to set model", show_alert=True)
            
            return await self.show_admin_menu(update, context)
        
        elif action == "admin_char_limit":
            await query.edit_message_text(
                f"Current character limit: {self.chat_bot.character_limit}\n\n"
                f"Send the new limit (50-4000):",
                parse_mode=ParseMode.MARKDOWN
            )
            context.user_data['admin_action'] = 'set_char_limit'
            return ADMIN_INPUT
        
        elif action == "admin_toggle_format":
            enabled = await self.chat_bot.toggle_formatting()
            status = "enabled" if enabled else "disabled"
            await query.answer(f"Formatting {status}", show_alert=True)
            return await self.show_admin_menu(update, context)
        
        elif action == "admin_toggle_bold":
            enabled = await self.chat_bot.toggle_bold_mode()
            status = "enabled" if enabled else "disabled"
            await query.answer(f"Bold mode {status}", show_alert=True)
            return await self.show_admin_menu(update, context)
        
        elif action == "admin_hidden_models":
            # Show hidden models management
            models = await self.chat_bot.get_available_models(include_hidden=True)
            
            keyboard = []
            for model in models:
                name = model.get('name', 'Unknown')
                if name in self.chat_bot.hidden_models:
                    keyboard.append([
                        InlineKeyboardButton(f"🚫 {name} (hidden)", callback_data=f"admin_unhide_{name}")
                    ])
                else:
                    keyboard.append([
                        InlineKeyboardButton(f"✅ {name}", callback_data=f"admin_hide_{name}")
                    ])
            
            keyboard.append([InlineKeyboardButton("« Back", callback_data="back_admin")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                "Click to hide/unhide models:",
                reply_markup=reply_markup
            )
            
            return ADMIN_MENU
        
        elif action.startswith("admin_hide_"):
            model_name = action.replace("admin_hide_", "")
            success = await self.chat_bot.hide_model(model_name)
            await query.answer(f"Model hidden: {model_name}", show_alert=True)
            return await self.handle_admin_action(update, context)  # Refresh menu
        
        elif action.startswith("admin_unhide_"):
            model_name = action.replace("admin_unhide_", "")
            success = await self.chat_bot.unhide_model(model_name)
            await query.answer(f"Model unhidden: {model_name}", show_alert=True)
            
            # Refresh the hidden models menu
            update.callback_query.data = "admin_hidden_models"
            return await self.handle_admin_action(update, context)
        
        elif action == "admin_stats":
            # Show usage statistics
            stats = await self.db.get_chat_stats()
            
            text = (
                f"📊 **Chat Statistics**\n\n"
                f"Total Sessions: {stats.get('total_sessions', 0)}\n"
                f"Active Users: {stats.get('active_users', 0)}\n"
                f"Messages Today: {stats.get('messages_today', 0)}\n"
                f"Popular Model: {stats.get('popular_model', 'N/A')}"
            )
            
            await query.answer()
            await query.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)
            
            return await self.show_admin_menu(update, context)
        
        elif action == "back_admin":
            return await self.show_admin_menu(update, context)
        
        return ADMIN_MENU
    
    async def handle_admin_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Handle admin text input"""
        action = context.user_data.get('admin_action')
        
        if action == 'set_char_limit':
            try:
                limit = int(update.message.text)
                await self.chat_bot.set_character_limit(limit)
                await update.message.reply_text(
                    f"✅ Character limit set to: {self.chat_bot.character_limit}",
                    parse_mode=ParseMode.MARKDOWN
                )
            except ValueError:
                await update.message.reply_text(
                    "❌ Invalid number. Please try again.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return ADMIN_INPUT
        
        # Clear admin action
        context.user_data.pop('admin_action', None)
        
        # Return to admin menu
        await asyncio.sleep(1)
        # Create a fake callback query to show admin menu
        update.callback_query = type('obj', (object,), {
            'answer': lambda: None,
            'edit_message_text': update.message.reply_text,
            'message': update.message,
            'from_user': update.effective_user
        })
        return await self.show_admin_menu(update, context)
    
    async def back_to_chat(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Return to chat interface"""
        return await self.start_chat(update, context)
    
    async def cancel_chat(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Cancel chat session"""
        await update.message.reply_text(
            "👋 Chat cancelled. Use /shit_ai to start again!",
            parse_mode=ParseMode.MARKDOWN
        )
        return ConversationHandler.END
    
    async def cancel_admin_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Cancel admin input"""
        context.user_data.pop('admin_action', None)
        await update.message.reply_text("Admin input cancelled.")
        
        # Return to admin menu
        update.callback_query = type('obj', (object,), {
            'answer': lambda: None,
            'edit_message_text': update.message.reply_text,
            'message': update.message,
            'from_user': update.effective_user
        })
        return await self.show_admin_menu(update, context)