#!/usr/bin/env python3
"""
Enhanced Tracker Handler for S.H.I.T. functionality
Advanced transaction tracking with date selection, export options, and progress tracking
"""

import asyncio
import logging
import re
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes,
    ConversationHandler,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters
)
from telegram.constants import ParseMode, ChatAction
from telegram_bot_calendar import DetailedTelegramCalendar, LSTEP

from apps.shit_tracker.tracker import ShibariumTracker
from bot.utils.helpers import validate_wallet_address, format_currency, format_duration

logger = logging.getLogger(__name__)

# Conversation states
WALLET_INPUT, DATE_SELECTION, EXPORT_OPTIONS, SCANNING, SETTINGS_MENU = range(5)


class TrackerHandler:
    """Enhanced tracker handler with comprehensive scanning and export features"""
    
    def __init__(self, db):
        self.db = db
        self.active_scans = {}  # Track active scans per user
        self.scan_progress = {}  # Track scan progress
        
    @staticmethod
    def get_conversation_handler():
        """Get conversation handler for tracker"""
        return ConversationHandler(
            entry_points=[
                CallbackQueryHandler(TrackerHandler._handle_tracker_callback, pattern="^tracker_"),
                CommandHandler('shit_track', TrackerHandler._start_tracking_command)
            ],
            states={
                WALLET_INPUT: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, TrackerHandler._process_wallet_input)
                ],
                DATE_SELECTION: [
                    CallbackQueryHandler(TrackerHandler._handle_date_callback, pattern="^date_"),
                    CallbackQueryHandler(TrackerHandler._handle_calendar, pattern=DetailedTelegramCalendar.func())
                ],
                EXPORT_OPTIONS: [
                    CallbackQueryHandler(TrackerHandler._handle_export_callback, pattern="^export_")
                ],
                SCANNING: [
                    CallbackQueryHandler(TrackerHandler._handle_scan_callback, pattern="^scan_")
                ],
                SETTINGS_MENU: [
                    CallbackQueryHandler(TrackerHandler._handle_settings_callback, pattern="^settings_")
                ]
            },
            fallbacks=[
                CommandHandler("shit_cancel", TrackerHandler._cancel_scan),
                CommandHandler("shit_track", TrackerHandler._restart_tracking)
            ],
            allow_reentry=True,
            per_message=False,
            name="shit_tracker"
        )

    # Static methods for conversation handler
    @staticmethod
    async def _handle_tracker_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('tracker')
        if handler:
            return await handler.handle_tracker_callback(update, context)
        return ConversationHandler.END

    @staticmethod
    async def _start_tracking_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('tracker')
        if handler:
            return await handler.start_tracking(update, context)
        return ConversationHandler.END

    @staticmethod
    async def _process_wallet_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('tracker')
        if handler:
            return await handler.process_wallet_input(update, context)
        return ConversationHandler.END

    @staticmethod
    async def _handle_date_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('tracker')
        if handler:
            return await handler.handle_date_callback(update, context)
        return ConversationHandler.END

    @staticmethod
    async def _handle_calendar(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('tracker')
        if handler:
            return await handler.handle_calendar(update, context)
        return ConversationHandler.END

    @staticmethod
    async def _handle_export_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('tracker')
        if handler:
            return await handler.handle_export_callback(update, context)
        return ConversationHandler.END

    @staticmethod
    async def _handle_scan_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('tracker')
        if handler:
            return await handler.handle_scan_callback(update, context)
        return ConversationHandler.END

    @staticmethod
    async def _handle_settings_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('tracker')
        if handler:
            return await handler.handle_settings_callback(update, context)
        return ConversationHandler.END

    @staticmethod
    async def _cancel_scan(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('tracker')
        if handler:
            return await handler.cancel_scan(update, context)
        return ConversationHandler.END

    @staticmethod
    async def _restart_tracking(update: Update, context: ContextTypes.DEFAULT_TYPE):
        handler = context.bot_data.get('tracker')
        if handler:
            return await handler.start_tracking(update, context)
        return ConversationHandler.END

    # Instance methods
    async def handle_tracker_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle tracker menu callbacks"""
        query = update.callback_query
        await query.answer()
        
        if query.data == "tracker_scan":
            return await self.start_tracking(update, context)
        elif query.data == "tracker_quick":
            return await self.quick_scan_menu(update, context)
        elif query.data == "tracker_dates":
            return await self.show_date_selection(update, context)
        elif query.data == "tracker_export":
            return await self.show_export_options(update, context)
        elif query.data == "tracker_history":
            return await self.show_scan_history(update, context)
        elif query.data == "tracker_settings":
            return await self.show_tracker_settings(update, context)
        
        return ConversationHandler.END

    async def start_tracking(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start the tracking workflow"""
        user_id = update.effective_user.id
        
        # Check if user has an active scan
        if user_id in self.active_scans:
            keyboard = [
                [
                    InlineKeyboardButton("📊 View Progress", callback_data="scan_progress"),
                    InlineKeyboardButton("❌ Cancel Scan", callback_data="scan_cancel")
                ],
                [InlineKeyboardButton("🔙 Back to Menu", callback_data="menu_tracker")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            text = (
                "⚠️ *Active Scan Found*\n\n"
                "You already have a scan in progress.\n"
                "Please wait for it to complete or cancel it first."
            )
            
            if update.callback_query:
                await update.callback_query.edit_message_text(
                    text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
                )
            else:
                await update.message.reply_text(
                    text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
                )
            return SCANNING
        
        # Show wallet input prompt
        keyboard = [
            [InlineKeyboardButton("📋 Recent Wallets", callback_data="tracker_recent")],
            [InlineKeyboardButton("🔙 Back to Menu", callback_data="menu_tracker")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = (
            "📊 *S.H.I.T. Tracker - Wallet Scan*\n\n"
            "Enter the wallet address you want to scan:\n\n"
            "*Supported formats:*\n"
            "• Full address: `0x1234...5678`\n"
            "• ENS domain: `example.eth`\n\n"
            "*Example:*\n"
            "`0x742EB5F51292A17C97e0bFe447F5c0A79eC9BE27`"
        )
        
        if update.callback_query:
            await update.callback_query.edit_message_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        else:
            await update.message.reply_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        
        return WALLET_INPUT

    async def process_wallet_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Process wallet address input"""
        wallet_input = update.message.text.strip()
        
        # Validate wallet address
        if not validate_wallet_address(wallet_input):
            await update.message.reply_text(
                "❌ *Invalid Wallet Address*\n\n"
                "Please enter a valid Ethereum wallet address starting with '0x' followed by 40 hexadecimal characters.\n\n"
                "*Example:* `0x742EB5F51292A17C97e0bFe447F5c0A79eC9BE27`",
                parse_mode=ParseMode.MARKDOWN
            )
            return WALLET_INPUT
        
        # Store wallet address
        context.user_data['scan_wallet'] = wallet_input.lower()
        
        # Add to recent wallets
        await self._add_recent_wallet(update.effective_user.id, wallet_input)
        
        # Proceed to date selection
        return await self.show_date_selection(update, context)

    async def show_date_selection(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show date range selection"""
        wallet = context.user_data.get('scan_wallet', 'Selected wallet')
        
        keyboard = [
            [
                InlineKeyboardButton("📅 Last 7 days", callback_data="date_7d"),
                InlineKeyboardButton("📅 Last 30 days", callback_data="date_30d")
            ],
            [
                InlineKeyboardButton("📅 Last 90 days", callback_data="date_90d"),
                InlineKeyboardButton("📅 This month", callback_data="date_month")
            ],
            [
                InlineKeyboardButton("📅 This year", callback_data="date_year"),
                InlineKeyboardButton("📅 All time", callback_data="date_all")
            ],
            [
                InlineKeyboardButton("🗓️ Custom Range", callback_data="date_custom"),
                InlineKeyboardButton("⚡ Quick Scan (Recent)", callback_data="date_quick")
            ],
            [
                InlineKeyboardButton("🔙 Change Wallet", callback_data="tracker_scan")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = (
            f"📅 *Select Date Range*\n\n"
            f"Wallet: `{wallet[:6]}...{wallet[-4:]}`\n\n"
            f"Choose the time period to scan:\n\n"
            f"*Presets:*\n"
            f"• **Quick Scan**: Last 7 days (fastest)\n"
            f"• **Last 30 days**: Recommended for monthly reports\n"
            f"• **All time**: Complete history (slower)\n\n"
            f"⚠️ *Note:* Longer periods take more time and API calls"
        )
        
        if update.callback_query:
            await update.callback_query.edit_message_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        else:
            await update.message.reply_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        
        return DATE_SELECTION

    async def handle_date_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle date selection callbacks"""
        query = update.callback_query
        await query.answer()
        
        now = datetime.now()
        date_ranges = {
            "date_7d": (now - timedelta(days=7), now),
            "date_30d": (now - timedelta(days=30), now),
            "date_90d": (now - timedelta(days=90), now),
            "date_month": (now.replace(day=1), now),
            "date_year": (now.replace(month=1, day=1), now),
            "date_all": (datetime(2021, 1, 1), now),  # Shibarium launch
            "date_quick": (now - timedelta(days=3), now)
        }
        
        if query.data in date_ranges:
            start_date, end_date = date_ranges[query.data]
            context.user_data['scan_start_date'] = start_date
            context.user_data['scan_end_date'] = end_date
            
            return await self.show_export_options(update, context)
        
        elif query.data == "date_custom":
            return await self.show_custom_date_picker(update, context)
        
        return DATE_SELECTION

    async def show_custom_date_picker(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show custom date picker"""
        calendar, step = DetailedTelegramCalendar().build()
        
        text = "📅 *Select Start Date*\n\nChoose the beginning of your scan period:"
        
        await update.callback_query.edit_message_text(
            text, reply_markup=calendar, parse_mode=ParseMode.MARKDOWN
        )
        
        context.user_data['date_step'] = 'start'
        return DATE_SELECTION

    async def handle_calendar(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle calendar selection"""
        result, key, step = DetailedTelegramCalendar().process(update.callback_query.data)
        
        if not result and key:
            await update.callback_query.edit_message_text(
                f"📅 *Select {'Start' if context.user_data.get('date_step') == 'start' else 'End'} Date*",
                reply_markup=key,
                parse_mode=ParseMode.MARKDOWN
            )
        elif result:
            date_step = context.user_data.get('date_step', 'start')
            
            if date_step == 'start':
                context.user_data['scan_start_date'] = result
                context.user_data['date_step'] = 'end'
                
                # Show end date picker
                calendar, step = DetailedTelegramCalendar(min_date=result).build()
                await update.callback_query.edit_message_text(
                    "📅 *Select End Date*\n\nChoose the end of your scan period:",
                    reply_markup=calendar,
                    parse_mode=ParseMode.MARKDOWN
                )
            else:
                context.user_data['scan_end_date'] = result
                return await self.show_export_options(update, context)
        
        return DATE_SELECTION

    async def show_export_options(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show export format options"""
        wallet = context.user_data.get('scan_wallet', 'Unknown')
        start_date = context.user_data.get('scan_start_date')
        end_date = context.user_data.get('scan_end_date')
        
        # Calculate estimated scan time and cost
        days = (end_date - start_date).days
        estimated_time = min(max(days * 2, 30), 300)  # 2 seconds per day, min 30s, max 5min
        
        keyboard = [
            [
                InlineKeyboardButton("📊 Excel Report", callback_data="export_excel"),
                InlineKeyboardButton("📋 Koinly CSV", callback_data="export_koinly")
            ],
            [
                InlineKeyboardButton("📄 Summary Report", callback_data="export_summary"),
                InlineKeyboardButton("📦 All Formats", callback_data="export_all")
            ],
            [
                InlineKeyboardButton("⚙️ Advanced Options", callback_data="export_advanced"),
                InlineKeyboardButton("🚀 Start Scan", callback_data="export_start")
            ],
            [
                InlineKeyboardButton("🔙 Change Dates", callback_data="tracker_dates")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = (
            f"📊 *Export Options*\n\n"
            f"📍 Wallet: `{wallet[:6]}...{wallet[-4:]}`\n"
            f"📅 Period: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}\n"
            f"⏱️ Duration: {days} days\n"
            f"⏳ Est. time: ~{format_duration(estimated_time)}\n\n"
            f"*Available Formats:*\n\n"
            f"📊 **Excel Report**\n"
            f"• Detailed transaction data\n"
            f"• Token transfers and NFTs\n"
            f"• Transaction links\n"
            f"• Formatted for analysis\n\n"
            f"📋 **Koinly CSV**\n"
            f"• Tax-ready format\n"
            f"• Compatible with tax software\n"
            f"• Calculated P&L\n"
            f"• NULL token handling\n\n"
            f"📄 **Summary Report**\n"
            f"• P&L calculations\n"
            f"• Transaction categorization\n"
            f"• Bridge/swap/staking summary\n"
            f"• Text format\n\n"
            f"📦 **All Formats** (Recommended)\n"
            f"• Excel + Koinly + Summary\n"
            f"• Complete documentation"
        )
        
        if update.callback_query:
            await update.callback_query.edit_message_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        else:
            await update.message.reply_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        
        return EXPORT_OPTIONS

    async def handle_export_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle export option selection"""
        query = update.callback_query
        await query.answer()
        
        export_formats = {
            "export_excel": ["excel"],
            "export_koinly": ["koinly"],
            "export_summary": ["summary"],
            "export_all": ["excel", "koinly", "summary"]
        }
        
        if query.data in export_formats:
            context.user_data['scan_formats'] = export_formats[query.data]
            return await self.start_scan(update, context)
        
        elif query.data == "export_advanced":
            return await self.show_advanced_options(update, context)
        
        elif query.data == "export_start":
            # Use default format if none selected
            if 'scan_formats' not in context.user_data:
                context.user_data['scan_formats'] = ["excel", "koinly", "summary"]
            return await self.start_scan(update, context)
        
        return EXPORT_OPTIONS

    async def show_advanced_options(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show advanced scanning options"""
        user_settings = await self.db.get_user_settings(update.effective_user.id)
        
        deep_scan = user_settings.get('tracker_deep_scan', False)
        include_usd = user_settings.get('tracker_include_usd', True)
        auto_delete = user_settings.get('tracker_auto_delete', True)
        
        keyboard = [
            [
                InlineKeyboardButton(
                    f"🔍 Deep Scan: {'✅' if deep_scan else '❌'}", 
                    callback_data="settings_deep_scan"
                )
            ],
            [
                InlineKeyboardButton(
                    f"💰 USD Values: {'✅' if include_usd else '❌'}", 
                    callback_data="settings_usd_values"
                )
            ],
            [
                InlineKeyboardButton(
                    f"🗑️ Auto-delete: {'✅' if auto_delete else '❌'}", 
                    callback_data="settings_auto_delete"
                )
            ],
            [
                InlineKeyboardButton("💾 Save & Continue", callback_data="export_start"),
                InlineKeyboardButton("🔙 Back", callback_data="tracker_export")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = (
            f"⚙️ *Advanced Options*\n\n"
            f"🔍 **Deep Scan**: {'Enabled' if deep_scan else 'Disabled'}\n"
            f"• Scans internal transactions\n"
            f"• More thorough but slower\n"
            f"• Recommended for DeFi users\n\n"
            f"💰 **USD Values**: {'Enabled' if include_usd else 'Disabled'}\n"
            f"• Include USD value calculations\n"
            f"• Uses historical price data\n"
            f"• Required for tax reporting\n\n"
            f"🗑️ **Auto-delete**: {'Enabled' if auto_delete else 'Disabled'}\n"
            f"• Files deleted after 10 minutes\n"
            f"• Saves storage space\n"
            f"• Downloads immediately"
        )
        
        await update.callback_query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        return EXPORT_OPTIONS

    async def start_scan(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start the actual scanning process"""
        user_id = update.effective_user.id
        wallet = context.user_data.get('scan_wallet')
        start_date = context.user_data.get('scan_start_date')
        end_date = context.user_data.get('scan_end_date')
        formats = context.user_data.get('scan_formats', ['excel'])
        
        # Create scan entry
        scan_id = await self._create_scan_entry(user_id, wallet, start_date, end_date, formats)
        
        # Show scanning progress
        keyboard = [
            [
                InlineKeyboardButton("📊 View Progress", callback_data="scan_progress"),
                InlineKeyboardButton("❌ Cancel Scan", callback_data="scan_cancel")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = (
            f"🚀 *Scan Started*\n\n"
            f"📍 Wallet: `{wallet[:6]}...{wallet[-4:]}`\n"
            f"📅 Period: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}\n"
            f"📊 Formats: {', '.join(formats).title()}\n\n"
            f"⏳ *Initializing scan...*\n"
            f"Progress: ░░░░░░░░░░ 0%\n\n"
            f"This may take a few minutes depending on transaction volume.\n"
            f"You'll be notified when complete!"
        )
        
        await update.callback_query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        # Start background scan
        context.user_data['scan_id'] = scan_id
        self.active_scans[user_id] = scan_id
        
        # Start scan in background
        asyncio.create_task(self._run_background_scan(update, context, scan_id))
        
        return SCANNING

    async def _run_background_scan(self, update: Update, context: ContextTypes.DEFAULT_TYPE, scan_id: str):
        """Run scan in background and update progress"""
        try:
            user_id = update.effective_user.id
            wallet = context.user_data.get('scan_wallet')
            start_date = context.user_data.get('scan_start_date')
            end_date = context.user_data.get('scan_end_date')
            formats = context.user_data.get('scan_formats', ['excel'])
            
            # Initialize tracker
            tracker = ShibariumTracker()
            
            # Progress callback
            async def progress_callback(stage: str, progress: float, message: str):
                await self._update_scan_progress(update, scan_id, stage, progress, message)
            
            # Run scan
            results = await tracker.scan_wallet_transactions(
                wallet, 
                start_date, 
                end_date,
                export_formats=formats,
                progress_callback=progress_callback
            )
            
            # Send results
            if results and results.get('files'):
                await self._send_scan_results(update, context, results)
            else:
                await self._send_scan_error(update, "No transactions found or scan failed")
                
        except Exception as e:
            logger.error(f"Background scan error: {e}")
            await self._send_scan_error(update, str(e))
        finally:
            # Cleanup
            if user_id in self.active_scans:
                del self.active_scans[user_id]
            if scan_id in self.scan_progress:
                del self.scan_progress[scan_id]

    async def _update_scan_progress(self, update: Update, scan_id: str, stage: str, progress: float, message: str):
        """Update scan progress display"""
        try:
            self.scan_progress[scan_id] = {
                'stage': stage,
                'progress': progress,
                'message': message,
                'updated': datetime.now()
            }
            
            # Create progress bar
            progress_bar = "█" * int(progress * 10) + "░" * (10 - int(progress * 10))
            
            text = (
                f"🚀 *Scan in Progress*\n\n"
                f"📊 Stage: {stage}\n"
                f"Progress: {progress_bar} {progress:.0%}\n\n"
                f"💬 {message}\n\n"
                f"⏱️ Updated: {datetime.now().strftime('%H:%M:%S')}"
            )
            
            keyboard = [
                [
                    InlineKeyboardButton("🔄 Refresh", callback_data="scan_progress"),
                    InlineKeyboardButton("❌ Cancel", callback_data="scan_cancel")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # Update message if it's the active scan view
            if hasattr(update, 'callback_query') and update.callback_query:
                try:
                    await update.callback_query.edit_message_text(
                        text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
                    )
                except:
                    pass  # Message might not be editable
                    
        except Exception as e:
            logger.error(f"Error updating scan progress: {e}")

    async def _send_scan_results(self, update: Update, context: ContextTypes.DEFAULT_TYPE, results: Dict):
        """Send scan results to user"""
        try:
            user_id = update.effective_user.id
            files = results.get('files', {})
            stats = results.get('stats', {})
            
            # Send summary message
            text = (
                f"✅ *Scan Complete!*\n\n"
                f"📊 **Results Summary:**\n"
                f"• Total transactions: {stats.get('total_transactions', 0):,}\n"
                f"• Token transfers: {stats.get('token_transfers', 0):,}\n"
                f"• NFT transfers: {stats.get('nft_transfers', 0):,}\n"
                f"• Unique tokens: {stats.get('unique_tokens', 0):,}\n"
                f"• Date range: {stats.get('date_range', 'N/A')}\n\n"
                f"📁 **Files generated:**"
            )
            
            await context.bot.send_message(
                chat_id=user_id,
                text=text,
                parse_mode=ParseMode.MARKDOWN
            )
            
            # Send files
            for format_name, file_path in files.items():
                if Path(file_path).exists():
                    caption = f"📊 {format_name.title()} Report"
                    
                    with open(file_path, 'rb') as file:
                        await context.bot.send_document(
                            chat_id=user_id,
                            document=file,
                            caption=caption,
                            filename=Path(file_path).name
                        )
                    
                    # Delete file after sending (if auto-delete enabled)
                    user_settings = await self.db.get_user_settings(user_id)
                    if user_settings.get('tracker_auto_delete', True):
                        try:
                            os.unlink(file_path)
                        except:
                            pass
            
            # Send completion message
            final_text = (
                f"🎉 **Scan completed successfully!**\n\n"
                f"Files have been sent above. Use /shit_track to start a new scan."
            )
            
            await context.bot.send_message(
                chat_id=user_id,
                text=final_text,
                parse_mode=ParseMode.MARKDOWN
            )
            
        except Exception as e:
            logger.error(f"Error sending scan results: {e}")
            await self._send_scan_error(update, "Error sending results")

    async def _send_scan_error(self, update: Update, error_message: str):
        """Send scan error message"""
        text = (
            f"❌ *Scan Failed*\n\n"
            f"Error: {error_message}\n\n"
            f"Please try again or contact support if the problem persists.\n"
            f"Use /shit_track to start a new scan."
        )
        
        try:
            if hasattr(update, 'callback_query') and update.callback_query:
                await update.callback_query.edit_message_text(
                    text, parse_mode=ParseMode.MARKDOWN
                )
            else:
                await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)
        except:
            pass

    async def handle_scan_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle scanning progress callbacks"""
        query = update.callback_query
        await query.answer()
        
        if query.data == "scan_progress":
            return await self.show_scan_progress(update, context)
        elif query.data == "scan_cancel":
            return await self.cancel_scan(update, context)
        
        return SCANNING

    async def show_scan_progress(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show current scan progress"""
        scan_id = context.user_data.get('scan_id')
        
        if scan_id not in self.scan_progress:
            text = "No active scan found."
            keyboard = [[InlineKeyboardButton("🔙 Back to Menu", callback_data="menu_tracker")]]
        else:
            progress_data = self.scan_progress[scan_id]
            progress = progress_data['progress']
            stage = progress_data['stage']
            message = progress_data['message']
            
            progress_bar = "█" * int(progress * 10) + "░" * (10 - int(progress * 10))
            
            text = (
                f"🚀 *Scan in Progress*\n\n"
                f"📊 Stage: {stage}\n"
                f"Progress: {progress_bar} {progress:.0%}\n\n"
                f"💬 {message}\n\n"
                f"⏱️ Updated: {progress_data['updated'].strftime('%H:%M:%S')}"
            )
            
            keyboard = [
                [
                    InlineKeyboardButton("🔄 Refresh", callback_data="scan_progress"),
                    InlineKeyboardButton("❌ Cancel", callback_data="scan_cancel")
                ]
            ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
        )
        
        return SCANNING

    async def cancel_scan(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Cancel active scan"""
        user_id = update.effective_user.id
        
        if user_id in self.active_scans:
            del self.active_scans[user_id]
        
        scan_id = context.user_data.get('scan_id')
        if scan_id and scan_id in self.scan_progress:
            del self.scan_progress[scan_id]
        
        # Clear scan data
        for key in ['scan_wallet', 'scan_start_date', 'scan_end_date', 'scan_formats', 'scan_id']:
            context.user_data.pop(key, None)
        
        text = (
            "❌ *Scan Cancelled*\n\n"
            "The scan has been cancelled. Use /shit_track to start a new scan."
        )
        
        keyboard = [[InlineKeyboardButton("🔙 Main Menu", callback_data="menu_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        if update.callback_query:
            await update.callback_query.edit_message_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        else:
            await update.message.reply_text(
                text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN
            )
        
        return ConversationHandler.END

    # Helper methods
    async def _create_scan_entry(self, user_id: int, wallet: str, start_date: datetime, 
                                end_date: datetime, formats: List[str]) -> str:
        """Create database entry for scan"""
        # This would create an entry in the wallet_scans table
        # Return scan ID for tracking
        import uuid
        return str(uuid.uuid4())

    async def _add_recent_wallet(self, user_id: int, wallet: str):
        """Add wallet to recent wallets list"""
        user_settings = await self.db.get_user_settings(user_id)
        recent_wallets = user_settings.get('recent_wallets', [])
        
        # Add to front of list, remove duplicates
        if wallet in recent_wallets:
            recent_wallets.remove(wallet)
        recent_wallets.insert(0, wallet)
        
        # Keep only last 5 wallets
        user_settings['recent_wallets'] = recent_wallets[:5]
        await self.db.update_user_settings(user_id, user_settings)

    # Command handlers for direct access
    async def quick_scan(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Quick scan command"""
        return await self.quick_scan_menu(update, context)

    async def add_wallet(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Add wallet command"""
        return await self.start_tracking(update, context)

    async def show_history(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show scan history"""
        return await self.show_scan_history(update, context)

    async def show_settings(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show tracker settings"""
        return await self.show_tracker_settings(update, context)

    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle general tracker callbacks"""
        return await self.handle_tracker_callback(update, context)

    # Additional methods would be implemented here for:
    # - quick_scan_menu
    # - show_scan_history  
    # - show_tracker_settings
    # - handle_settings_callback