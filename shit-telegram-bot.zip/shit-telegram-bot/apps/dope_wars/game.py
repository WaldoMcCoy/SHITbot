#!/usr/bin/env python3
"""
# File location: /apps/dope_wars/game.py
DopeWars Game - Complete Implementation
Based on the classic 80s DOS game with crypto theme
"""

import json
import random
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

from .models import GameState, PlayerStats, LeaderboardEntry
from .admin_config import GameConfig

logger = logging.getLogger(__name__)


class DopeWarsGame:
    """Complete DopeWars game implementation with all features"""
    
    def __init__(self, config_path: Path = None):
        """Initialize game with configuration"""
        self.config_path = config_path or Path('/app/data/game_config.json')
        self.config = GameConfig(self.config_path)
        self.load_config()
        
    def load_config(self):
        """Load game configuration"""
        cfg = self.config.get_config()
        
        # Game settings
        self.starting_cash = cfg['starting_cash']
        self.starting_debt = cfg['starting_debt']
        self.starting_health = cfg['health']['starting']
        self.max_health = cfg['health']['max']
        self.starting_coat_size = cfg['inventory']['starting_size']
        self.max_coat_size = cfg['inventory']['max_size']
        self.bank_interest = cfg['bank_interest']
        self.debt_interest = cfg['debt_interest']
        self.max_days = cfg['max_days']
        
        # Locations
        self.locations = cfg['locations']
        
        # Drugs/Items with prices
        self.drugs = cfg['drugs']
        
        # Events configuration
        self.events = cfg['events']
        
    def create_new_game(self, user_id: int, username: str) -> GameState:
        """Create a new game state"""
        game = GameState(
            user_id=user_id,
            username=username,
            cash=self.starting_cash,
            debt=self.starting_debt,
            bank_balance=0,
            day=1,
            max_days=self.max_days,
            health=self.starting_health,
            max_health=self.max_health,
            guns=0,
            max_inventory=self.starting_coat_size,
            current_location=self.locations[0],
            inventory={},
            inventory_costs={},
            current_prices={},
            game_started=datetime.now(),
            config=self.config.get_config(),
            drugs=self.drugs,
            locations=self.locations
        )
        
        # Generate initial prices
        self._generate_prices(game)
        
        return game
    
    def _generate_prices(self, game: GameState):
        """Generate random prices for all drugs"""
        game.current_prices = {}
        
        for drug_id, drug_info in self.drugs.items():
            # Check for special price events
            price_event = self._check_price_event(drug_id)
            
            if price_event:
                price = price_event['price']
                if drug_id not in game.market_events:
                    game.market_events.append({
                        'drug': drug_id,
                        'type': price_event['type'],
                        'message': price_event['message']
                    })
            else:
                # Normal price generation
                min_price = drug_info['min_price']
                max_price = drug_info['max_price']
                price = random.randint(min_price, max_price)
            
            game.current_prices[drug_id] = price
            
            # Track price history
            if drug_id not in game.price_history:
                game.price_history[drug_id] = []
            game.price_history[drug_id].append(price)
    
    def _check_price_event(self, drug_id: str) -> Optional[Dict]:
        """Check for special price events (crashes/surges)"""
        # Market crash
        if random.random() < self.events['market_crash']['probability']:
            drug_info = self.drugs[drug_id]
            crash_price = int(drug_info['min_price'] * 0.5)
            return {
                'type': 'crash',
                'price': crash_price,
                'message': f"📉 {drug_info['name']} market crashed! Prices at rock bottom!"
            }
        
        # Price surge
        if random.random() < self.events['price_surge']['probability']:
            drug_info = self.drugs[drug_id]
            surge_price = int(drug_info['max_price'] * random.uniform(1.5, 2.5))
            return {
                'type': 'surge',
                'price': surge_price,
                'message': f"🚀 {drug_info['name']} is mooning! Prices skyrocketing!"
            }
        
        return None
    
    def travel(self, game: GameState, location: str) -> Dict[str, Any]:
        """Travel to a new location"""
        if location == game.current_location:
            return {'success': False, 'message': "You're already there!"}
        
        if location not in self.locations:
            return {'success': False, 'message': "Invalid location!"}
        
        # Advance day
        game.day += 1
        game.days_survived += 1
        
        # Update location
        game.current_location = location
        if location not in game.locations_visited:
            game.locations_visited.append(location)
        
        # Generate new prices
        game.market_events = []  # Clear previous market events
        self._generate_prices(game)
        
        # Apply interest
        game.debt = int(game.debt * (1 + self.debt_interest))
        game.bank_balance = int(game.bank_balance * (1 + self.bank_interest))
        
        # Random events
        events = self._process_random_events(game)
        
        # Check game over
        if game.day > game.max_days:
            game.is_game_over_flag = True
            game.game_over_reason = "Time's up!"
        elif game.health <= 0:
            game.is_game_over_flag = True
            game.game_over_reason = "You died!"
        
        return {
            'success': True,
            'events': events,
            'market_events': game.market_events
        }
    
    def _process_random_events(self, game: GameState) -> List[str]:
        """Process random events that can occur while traveling"""
        events = []
        
        # Police encounter
        if random.random() < self.events['police']['probability']:
            event_result = self._handle_police_event(game)
            events.append(event_result)
            game.events_encountered.append('police')
        
        # Mugging
        elif random.random() < self.events['mugging']['probability']:
            event_result = self._handle_mugging_event(game)
            events.append(event_result)
            game.events_encountered.append('mugging')
        
        # Find drugs
        elif random.random() < self.events['find_drugs']['probability']:
            event_result = self._handle_find_drugs_event(game)
            if event_result:
                events.append(event_result)
                game.events_encountered.append('find_drugs')
        
        # Coat upgrade offer
        elif random.random() < self.events['coat_upgrade']['probability'] and game.cash > 500:
            event_result = self._handle_coat_upgrade_event(game)
            if event_result:
                events.append(event_result)
                game.events_encountered.append('coat_upgrade')
        
        # Gun offer
        elif random.random() < self.events['gun_offer']['probability'] and game.cash > 300:
            event_result = self._handle_gun_offer_event(game)
            if event_result:
                events.append(event_result)
                game.events_encountered.append('gun_offer')
        
        # Whale buyer
        elif random.random() < self.events['whale_buyer']['probability'] and game.inventory:
            event_result = self._handle_whale_buyer_event(game)
            if event_result:
                events.append(event_result)
                game.events_encountered.append('whale_buyer')
        
        return events
    
    def _handle_police_event(self, game: GameState) -> str:
        """Handle police encounter"""
        if game.guns > 0:
            # Has guns - can fight back
            if random.random() < 0.6:  # 60% chance to escape
                if random.random() < 0.3:  # 30% chance to lose a gun
                    game.guns -= 1
                    return "🚔 Cops tried to bust you! You shot back and escaped but lost a gun!"
                return "🚔 Cops tried to bust you! You shot back and escaped!"
            else:
                # Got hit
                damage = random.randint(5, 15)
                game.health -= damage
                
                # Might lose some drugs
                if game.inventory and random.random() < 0.4:
                    drug = random.choice(list(game.inventory.keys()))
                    lost = min(game.inventory[drug], random.randint(1, 5))
                    game.inventory[drug] -= lost
                    if game.inventory[drug] <= 0:
                        del game.inventory[drug]
                        if drug in game.inventory_costs:
                            del game.inventory_costs[drug]
                    return f"🚔 Cops shot you! Lost {damage} health and {lost} {self.drugs[drug]['name']}!"
                
                return f"🚔 Cops shot you! Lost {damage} health!"
        else:
            # No guns - just run
            if random.random() < 0.5:  # 50% chance to escape clean
                return "🚔 Cops chased you but you got away!"
            else:
                # Got caught - lose drugs or health
                damage = random.randint(5, 10)
                game.health -= damage
                
                if game.inventory and random.random() < 0.6:
                    drug = random.choice(list(game.inventory.keys()))
                    lost = min(game.inventory[drug], random.randint(2, 8))
                    game.inventory[drug] -= lost
                    if game.inventory[drug] <= 0:
                        del game.inventory[drug]
                        if drug in game.inventory_costs:
                            del game.inventory_costs[drug]
                    return f"🚔 Cops caught you! Lost {damage} health and {lost} {self.drugs[drug]['name']}!"
                
                return f"🚔 Cops beat you up! Lost {damage} health!"
    
    def _handle_mugging_event(self, game: GameState) -> str:
        """Handle mugging event"""
        if game.cash > 0:
            # Lose percentage of cash
            lost_cash = int(game.cash * random.uniform(0.1, 0.3))
            game.cash -= lost_cash
            
            # Also lose some health
            damage = random.randint(5, 15)
            game.health -= damage
            
            return f"😱 You got mugged! Lost ${lost_cash:,} and {damage} health!"
        else:
            # No cash, just lose health
            damage = random.randint(10, 20)
            game.health -= damage
            return f"😱 Muggers beat you up when they found no cash! Lost {damage} health!"
    
    def _handle_find_drugs_event(self, game: GameState) -> Optional[str]:
        """Handle finding drugs event"""
        # Check if inventory has space
        current_inventory = sum(game.inventory.values())
        if current_inventory >= game.max_inventory:
            return None  # No space
        
        # Random drug and amount
        drug = random.choice(list(self.drugs.keys()))
        max_amount = min(10, game.max_inventory - current_inventory)
        amount = random.randint(1, max_amount)
        
        # Add to inventory
        game.inventory[drug] = game.inventory.get(drug, 0) + amount
        
        return f"🎁 You found {amount} {self.drugs[drug]['name']} on the ground!"
    
    def _handle_coat_upgrade_event(self, game: GameState) -> Optional[str]:
        """Handle coat upgrade offer - returns event for user to respond to"""
        if game.max_inventory >= self.max_coat_size:
            return None
        
        price = random.randint(200, 500)
        if game.cash >= price:
            return f"coat_upgrade|{price}|🧥 Want to buy a bigger coat for ${price}? (+20 space)"
        
        return None
    
    def _handle_gun_offer_event(self, game: GameState) -> Optional[str]:
        """Handle gun offer - returns event for user to respond to"""
        price = random.randint(300, 800)
        if game.cash >= price:
            return f"gun_offer|{price}|🔫 Want to buy a gun for ${price}? (Protection from cops)"
        
        return None
    
    def _handle_whale_buyer_event(self, game: GameState) -> Optional[str]:
        """Handle whale buyer offer"""
        if not game.inventory:
            return None
        
        # Pick a random drug from inventory
        drug = random.choice(list(game.inventory.keys()))
        amount = game.inventory[drug]
        
        # Offer premium price (2-3x current price)
        multiplier = random.uniform(2.0, 3.0)
        offer_price = int(game.current_prices[drug] * multiplier)
        
        return f"whale_offer|{drug}|{amount}|{offer_price}|🐋 A whale wants to buy ALL your {self.drugs[drug]['name']} for ${offer_price:,} each!"
    
    def buy_drug(self, game: GameState, drug: str, amount: int) -> Dict[str, Any]:
        """Buy drugs"""
        if drug not in self.drugs:
            return {'success': False, 'message': "Invalid drug!"}
        
        price = game.current_prices[drug]
        total_cost = price * amount
        
        # Check if enough cash
        if game.cash < total_cost:
            return {'success': False, 'message': "Not enough cash!"}
        
        # Check inventory space
        current_inventory = sum(game.inventory.values())
        if current_inventory + amount > game.max_inventory:
            return {'success': False, 'message': "Not enough space!"}
        
        # Make purchase
        game.cash -= total_cost
        game.inventory[drug] = game.inventory.get(drug, 0) + amount
        
        # Track average cost
        if drug not in game.inventory_costs:
            game.inventory_costs[drug] = price
        else:
            # Calculate weighted average
            old_amount = game.inventory.get(drug, 0) - amount
            old_cost = game.inventory_costs[drug]
            game.inventory_costs[drug] = ((old_cost * old_amount) + (price * amount)) / (old_amount + amount)
        
        game.total_purchases += 1
        
        return {
            'success': True,
            'message': f"Bought {amount} {self.drugs[drug]['name']} for ${total_cost:,}"
        }
    
    def sell_drug(self, game: GameState, drug: str, amount: int) -> Dict[str, Any]:
        """Sell drugs"""
        if drug not in game.inventory:
            return {'success': False, 'message': "You don't have that!"}
        
        if game.inventory[drug] < amount:
            return {'success': False, 'message': "Not enough inventory!"}
        
        price = game.current_prices[drug]
        total_revenue = price * amount
        
        # Calculate profit if we have cost data
        if drug in game.inventory_costs:
            cost = game.inventory_costs[drug] * amount
            profit = total_revenue - cost
            game.total_profit += profit
        
        # Make sale
        game.cash += total_revenue
        game.inventory[drug] -= amount
        
        if game.inventory[drug] <= 0:
            del game.inventory[drug]
            if drug in game.inventory_costs:
                del game.inventory_costs[drug]
        
        game.total_sales += 1
        
        return {
            'success': True,
            'message': f"Sold {amount} {self.drugs[drug]['name']} for ${total_revenue:,}"
        }
    
    def bank_transaction(self, game: GameState, amount: int, transaction_type: str) -> Dict[str, Any]:
        """Handle bank deposits and withdrawals"""
        if game.current_location != self.locations[0]:  # Usually first location is "home"
            return {'success': False, 'message': "Bank only available in the Bronx!"}
        
        if transaction_type == 'deposit':
            if amount > game.cash:
                return {'success': False, 'message': "Not enough cash!"}
            
            game.cash -= amount
            game.bank_balance += amount
            
            return {'success': True, 'message': f"Deposited ${amount:,} in the bank"}
        
        elif transaction_type == 'withdraw':
            if amount > game.bank_balance:
                return {'success': False, 'message': "Not enough in bank!"}
            
            game.bank_balance -= amount
            game.cash += amount
            
            return {'success': True, 'message': f"Withdrew ${amount:,} from the bank"}
        
        return {'success': False, 'message': "Invalid transaction type!"}
    
    def pay_debt(self, game: GameState, amount: int) -> Dict[str, Any]:
        """Pay back loan shark"""
        if game.current_location != self.locations[0]:
            return {'success': False, 'message': "Loan shark only in the Bronx!"}
        
        if amount > game.cash:
            return {'success': False, 'message': "Not enough cash!"}
        
        if amount > game.debt:
            amount = game.debt  # Don't overpay
        
        game.cash -= amount
        game.debt -= amount
        
        return {'success': True, 'message': f"Paid ${amount:,} to the loan shark"}
    
    def handle_event_response(self, game: GameState, event_type: str, accept: bool, event_data: Dict) -> Dict[str, Any]:
        """Handle player response to random events"""
        if event_type == 'coat_upgrade' and accept:
            price = event_data['price']
            if game.cash >= price:
                game.cash -= price
                game.max_inventory += 20
                return {'success': True, 'message': "🧥 You bought a bigger coat! +20 inventory space"}
            return {'success': False, 'message': "Not enough cash!"}
        
        elif event_type == 'gun_offer' and accept:
            price = event_data['price']
            if game.cash >= price:
                game.cash -= price
                game.guns += 1
                return {'success': True, 'message': "🔫 You bought a gun! Better protection from cops"}
            return {'success': False, 'message': "Not enough cash!"}
        
        elif event_type == 'whale_offer' and accept:
            drug = event_data['drug']
            amount = event_data['amount']
            price = event_data['price']
            
            if drug in game.inventory and game.inventory[drug] >= amount:
                total = amount * price
                game.cash += total
                game.inventory[drug] = 0
                del game.inventory[drug]
                if drug in game.inventory_costs:
                    del game.inventory_costs[drug]
                
                return {'success': True, 'message': f"🐋 Sold to the whale for ${total:,}!"}
            
            return {'success': False, 'message': "Deal expired!"}
        
        return {'success': True, 'message': "Declined the offer"}
    
    def calculate_score(self, game: GameState) -> int:
        """Calculate final score"""
        # Net worth calculation
        inventory_value = sum(
            game.current_prices.get(drug, 0) * amount 
            for drug, amount in game.inventory.items()
        )
        
        net_worth = game.cash + game.bank_balance + inventory_value - game.debt
        
        # Bonus for paying off debt
        if game.debt == 0:
            net_worth = int(net_worth * 1.5)
        
        # Bonus for surviving all days
        if game.day >= game.max_days:
            net_worth = int(net_worth * 1.2)
        
        # Penalty for low health
        health_multiplier = game.health / game.max_health
        net_worth = int(net_worth * (0.5 + health_multiplier * 0.5))
        
        return max(0, net_worth)
    
    def get_inventory_value(self, game: GameState) -> int:
        """Get total value of inventory"""
        return sum(
            game.current_prices.get(drug, 0) * amount 
            for drug, amount in game.inventory.items()
        )
    
    def get_inventory_space(self, game: GameState) -> Tuple[int, int]:
        """Get used and max inventory space"""
        used = sum(game.inventory.values())
        return used, game.max_inventory
    
    def format_game_status(self, game: GameState) -> str:
        """Format game status for display"""
        inventory_value = self.get_inventory_value(game)
        net_worth = game.cash + game.bank_balance + inventory_value - game.debt
        
        status = f"""
📅 Day {game.day}/{game.max_days}
📍 {game.current_location}
💰 Cash: ${game.cash:,}
🏦 Bank: ${game.bank_balance:,}
💸 Debt: ${game.debt:,}
❤️ Health: {game.health}/{game.max_health}
🔫 Guns: {game.guns}
🎒 Inventory: {sum(game.inventory.values())}/{game.max_inventory}
💎 Net Worth: ${net_worth:,}
"""
        return status
    
    def format_prices(self, game: GameState) -> str:
        """Format current prices for display"""
        lines = ["💱 **Current Prices:**\n"]
        
        for drug_id, price in game.current_prices.items():
            drug_info = self.drugs[drug_id]
            inventory = game.inventory.get(drug_id, 0)
            
            # Check for price events
            event_indicator = ""
            for event in game.market_events:
                if event['drug'] == drug_id:
                    if event['type'] == 'crash':
                        event_indicator = " 📉"
                    elif event['type'] == 'surge':
                        event_indicator = " 🚀"
            
            lines.append(f"{drug_info['emoji']} {drug_info['name']}: ${price:,}{event_indicator} (You have: {inventory})")
        
        return '\n'.join(lines)
    
    def format_inventory(self, game: GameState) -> str:
        """Format inventory for display"""
        if not game.inventory:
            return "🎒 **Inventory:** Empty"
        
        lines = ["🎒 **Inventory:**\n"]
        total_value = 0
        
        for drug_id, amount in game.inventory.items():
            drug_info = self.drugs[drug_id]
            current_price = game.current_prices[drug_id]
            value = current_price * amount
            total_value += value
            
            # Calculate profit/loss if we have cost data
            if drug_id in game.inventory_costs:
                avg_cost = game.inventory_costs[drug_id]
                profit_per_unit = current_price - avg_cost
                total_profit = profit_per_unit * amount
                
                if profit_per_unit > 0:
                    profit_indicator = f" 📈 +${abs(total_profit):,}"
                else:
                    profit_indicator = f" 📉 -${abs(total_profit):,}"
            else:
                profit_indicator = ""
            
            lines.append(f"{drug_info['emoji']} {amount} {drug_info['name']} (${value:,}){profit_indicator}")
        
        lines.append(f"\n💰 Total Value: ${total_value:,}")
        
        return '\n'.join(lines)