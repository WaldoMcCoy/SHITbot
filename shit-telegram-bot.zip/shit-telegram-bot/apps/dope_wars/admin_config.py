#!/usr/bin/env python3
"""
# File location: /apps/dope_wars/admin_config.py
Admin configuration system for DopeWars game
Allows dynamic configuration of game elements
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)


class GameConfig:
    """Manages game configuration with admin controls"""
    
    DEFAULT_CONFIG = {
        "drugs": {
            "btc": {
                "name": "Bitcoin",
                "emoji": "₿",
                "min_price": 15000,
                "max_price": 65000
            },
            "eth": {
                "name": "Ethereum", 
                "emoji": "Ξ",
                "min_price": 800,
                "max_price": 4500
            },
            "shib": {
                "name": "SHIB",
                "emoji": "🐕",
                "min_price": 1,
                "max_price": 100
            },
            "doge": {
                "name": "DOGE",
                "emoji": "Ð",
                "min_price": 50,
                "max_price": 500
            },
            "bone": {
                "name": "BONE",
                "emoji": "🦴",
                "min_price": 200,
                "max_price": 2000
            },
            "leash": {
                "name": "LEASH",
                "emoji": "🦴",
                "min_price": 300,
                "max_price": 3000
            }
        },
        "locations": [
            "🏙️ Crypto City",
            "🌃 DeFi District", 
            "🏦 Exchange Square",
            "⛓️ Blockchain Bay",
            "💰 Wallet Way",
            "🚀 Moon Base"
        ],
        "events": {
            "police": {
                "probability": 0.15,
                "enabled": True,
                "min_damage": 5,
                "max_damage": 15,
                "drug_loss_chance": 0.4,
                "gun_effectiveness": 0.6
            },
            "mugging": {
                "probability": 0.10,
                "enabled": True,
                "min_cash_loss": 0.1,
                "max_cash_loss": 0.3,
                "min_damage": 5,
                "max_damage": 20
            },
            "find_drugs": {
                "probability": 0.08,
                "enabled": True,
                "min_amount": 1,
                "max_amount": 10
            },
            "coat_upgrade": {
                "probability": 0.05,
                "enabled": True,
                "min_price": 200,
                "max_price": 500,
                "space_increase": 20
            },
            "gun_offer": {
                "probability": 0.06,
                "enabled": True,
                "min_price": 300,
                "max_price": 800
            },
            "whale_buyer": {
                "probability": 0.04,
                "enabled": True,
                "min_multiplier": 2.0,
                "max_multiplier": 3.0
            },
            "market_crash": {
                "probability": 0.02,
                "enabled": True,
                "crash_multiplier": 0.5
            },
            "price_surge": {
                "probability": 0.03,
                "enabled": True,
                "surge_min_multiplier": 1.5,
                "surge_max_multiplier": 2.5
            }
        },
        "game_settings": {
            "starting_cash": 2000,
            "starting_debt": 5500,
            "max_days": 30,
            "bank_interest": 0.05,
            "debt_interest": 0.10
        },
        "health": {
            "starting": 100,
            "max": 100,
            "min_for_travel": 20
        },
        "inventory": {
            "starting_size": 100,
            "max_size": 200,
            "upgrade_increment": 20
        },
        "competition": {
            "enabled": True,
            "default_games": 10,
            "min_games": 5,
            "max_games": 50
        },
        "characters": {
            "loan_shark": {
                "name": "Vitalik the Validator",
                "emoji": "🦈"
            },
            "banker": {
                "name": "Satoshi the Banker",
                "emoji": "🏦"
            },
            "cop": {
                "name": "SEC Agent",
                "emoji": "🚔"
            },
            "mugger": {
                "name": "Rug Puller",
                "emoji": "😈"
            }
        }
    }
    
    def __init__(self, config_path: Path = None):
        """Initialize configuration"""
        self.config_path = config_path or Path('/app/data/game_config.json')
        self.config = self.load_config()
    
    def load_config(self) -> Dict[str, Any]:
        """Load configuration from file or create default"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                    # Merge with defaults to ensure all keys exist
                    return self._merge_configs(self.DEFAULT_CONFIG, config)
            except Exception as e:
                logger.error(f"Error loading config: {e}")
                return self.DEFAULT_CONFIG.copy()
        else:
            # Create default config
            self.save_config(self.DEFAULT_CONFIG)
            return self.DEFAULT_CONFIG.copy()
    
    def save_config(self, config: Dict[str, Any] = None) -> bool:
        """Save configuration to file"""
        if config is None:
            config = self.config
        
        try:
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_path, 'w') as f:
                json.dump(config, f, indent=2)
            return True
        except Exception as e:
            logger.error(f"Error saving config: {e}")
            return False
    
    def _merge_configs(self, default: Dict, custom: Dict) -> Dict:
        """Merge custom config with defaults"""
        result = default.copy()
        
        for key, value in custom.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_configs(result[key], value)
            else:
                result[key] = value
        
        return result
    
    def get_config(self) -> Dict[str, Any]:
        """Get current configuration"""
        return self.config
    
    def update_drug(self, drug_id: str, updates: Dict[str, Any]) -> bool:
        """Update drug configuration"""
        if drug_id not in self.config['drugs']:
            return False
        
        for key, value in updates.items():
            if key in self.config['drugs'][drug_id]:
                self.config['drugs'][drug_id][key] = value
        
        return self.save_config()
    
    def add_drug(self, drug_id: str, drug_data: Dict[str, Any]) -> bool:
        """Add new drug"""
        if drug_id in self.config['drugs']:
            return False
        
        # Validate required fields
        required = ['name', 'emoji', 'min_price', 'max_price']
        if not all(key in drug_data for key in required):
            return False
        
        self.config['drugs'][drug_id] = drug_data
        return self.save_config()
    
    def remove_drug(self, drug_id: str) -> bool:
        """Remove drug (if more than 3 remain)"""
        if len(self.config['drugs']) <= 3:
            return False  # Need at least 3 drugs
        
        if drug_id in self.config['drugs']:
            del self.config['drugs'][drug_id]
            return self.save_config()
        
        return False
    
    def update_location(self, index: int, new_name: str) -> bool:
        """Update location name"""
        if 0 <= index < len(self.config['locations']):
            self.config['locations'][index] = new_name
            return self.save_config()
        return False
    
    def add_location(self, location: str) -> bool:
        """Add new location"""
        if len(self.config['locations']) >= 10:
            return False  # Max 10 locations
        
        self.config['locations'].append(location)
        return self.save_config()
    
    def remove_location(self, index: int) -> bool:
        """Remove location (if more than 3 remain)"""
        if len(self.config['locations']) <= 3:
            return False  # Need at least 3 locations
        
        if 0 <= index < len(self.config['locations']):
            self.config['locations'].pop(index)
            return self.save_config()
        
        return False
    
    def update_event_probability(self, event: str, probability: float) -> bool:
        """Update event probability"""
        if event in self.config['events'] and 0 <= probability <= 1:
            self.config['events'][event]['probability'] = probability
            return self.save_config()
        return False
    
    def toggle_event(self, event: str) -> bool:
        """Enable/disable event"""
        if event in self.config['events']:
            self.config['events'][event]['enabled'] = not self.config['events'][event]['enabled']
            return self.save_config()
        return False
    
    def update_event_settings(self, event: str, settings: Dict[str, Any]) -> bool:
        """Update event-specific settings"""
        if event not in self.config['events']:
            return False
        
        for key, value in settings.items():
            if key in self.config['events'][event] and key not in ['probability', 'enabled']:
                self.config['events'][event][key] = value
        
        return self.save_config()
    
    def update_game_settings(self, settings: Dict[str, Any]) -> bool:
        """Update general game settings"""
        for key, value in settings.items():
            if key in self.config['game_settings']:
                self.config['game_settings'][key] = value
        
        return self.save_config()
    
    def update_character(self, character: str, name: str, emoji: str = None) -> bool:
        """Update character name and emoji"""
        if character in self.config['characters']:
            self.config['characters'][character]['name'] = name
            if emoji:
                self.config['characters'][character]['emoji'] = emoji
            return self.save_config()
        return False
    
    def reset_to_defaults(self) -> bool:
        """Reset configuration to defaults"""
        self.config = self.DEFAULT_CONFIG.copy()
        return self.save_config()
    
    def export_config(self) -> str:
        """Export configuration as JSON string"""
        return json.dumps(self.config, indent=2)
    
    def import_config(self, config_json: str) -> bool:
        """Import configuration from JSON string"""
        try:
            new_config = json.loads(config_json)
            # Validate structure
            if self._validate_config(new_config):
                self.config = self._merge_configs(self.DEFAULT_CONFIG, new_config)
                return self.save_config()
        except Exception as e:
            logger.error(f"Error importing config: {e}")
        
        return False
    
    def _validate_config(self, config: Dict) -> bool:
        """Validate configuration structure"""
        required_keys = ['drugs', 'locations', 'events', 'game_settings']
        return all(key in config for key in required_keys)
    
    def get_competition_settings(self) -> Dict[str, Any]:
        """Get competition-specific settings"""
        return self.config.get('competition', {
            'enabled': True,
            'default_games': 10,
            'min_games': 5,
            'max_games': 50
        })
    
    def update_competition_settings(self, settings: Dict[str, Any]) -> bool:
        """Update competition settings"""
        if 'competition' not in self.config:
            self.config['competition'] = {}
        
        for key, value in settings.items():
            self.config['competition'][key] = value
        
        return self.save_config()
    
    def format_config_summary(self) -> str:
        """Format configuration summary for display"""
        lines = ["📋 **Current Configuration**\n"]
        
        # Drugs
        lines.append("**💊 Drugs:**")
        for drug_id, drug in self.config['drugs'].items():
            lines.append(f"• {drug['emoji']} {drug['name']}: ${drug['min_price']:,} - ${drug['max_price']:,}")
        
        # Locations
        lines.append("\n**📍 Locations:**")
        for i, location in enumerate(self.config['locations']):
            lines.append(f"{i+1}. {location}")
        
        # Events
        lines.append("\n**🎲 Events:**")
        for event, settings in self.config['events'].items():
            status = "✅" if settings['enabled'] else "❌"
            prob = settings['probability'] * 100
            lines.append(f"• {event}: {status} ({prob:.0f}%)")
        
        # Game Settings
        lines.append("\n**⚙️ Game Settings:**")
        gs = self.config['game_settings']
        lines.append(f"• Starting Cash: ${gs['starting_cash']:,}")
        lines.append(f"• Starting Debt: ${gs['starting_debt']:,}")
        lines.append(f"• Max Days: {gs['max_days']}")
        lines.append(f"• Bank Interest: {gs['bank_interest']*100:.0f}%")
        lines.append(f"• Debt Interest: {gs['debt_interest']*100:.0f}%")
        
        return '\n'.join(lines)