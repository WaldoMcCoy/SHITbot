#!/usr/bin/env python3
"""
# File location: /apps/dope_wars/leaderboard.py
Leaderboard and competition system for DopeWars
"""

import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class LeaderboardEntry:
    """Leaderboard entry model"""
    user_id: int
    username: str
    score: int
    timestamp: datetime
    days_survived: int
    final_cash: int
    final_debt: int
    highest_cash: int
    highest_debt: int
    total_trades: int
    game_version: str = "1.0"
    
    def to_dict(self) -> Dict:
        return {
            'user_id': self.user_id,
            'username': self.username,
            'score': self.score,
            'timestamp': self.timestamp.isoformat(),
            'days_survived': self.days_survived,
            'final_cash': self.final_cash,
            'final_debt': self.final_debt,
            'highest_cash': self.highest_cash,
            'highest_debt': self.highest_debt,
            'total_trades': self.total_trades,
            'game_version': self.game_version
        }


@dataclass 
class Competition:
    """Competition model"""
    id: int
    title: str
    start_date: datetime
    end_date: datetime
    games_required: int
    created_by: int
    is_active: bool
    participants: List[int]
    
    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'title': self.title,
            'start_date': self.start_date.isoformat(),
            'end_date': self.end_date.isoformat(),
            'games_required': self.games_required,
            'created_by': self.created_by,
            'is_active': self.is_active,
            'participants': self.participants
        }


class Leaderboard:
    """Manages leaderboards and competitions"""
    
    def __init__(self, db):
        self.db = db
    
    async def add_score(self, user_id: int, username: str, score: int, game_state: Any) -> None:
        """Add a score to the leaderboard"""
        entry = LeaderboardEntry(
            user_id=user_id,
            username=username,
            score=score,
            timestamp=datetime.now(),
            days_survived=game_state.days_survived,
            final_cash=game_state.cash,
            final_debt=game_state.debt,
            highest_cash=max(game_state.cash, game_state.bank_balance),
            highest_debt=game_state.debt,
            total_trades=game_state.total_purchases + game_state.total_sales
        )
        
        await self.db.add_leaderboard_entry(entry)
        
        # Check for active competitions
        active_competition = await self.get_active_competition()
        if active_competition:
            await self.add_competition_score(active_competition.id, user_id, score)
    
    async def get_all_time_leaderboard(self, limit: int = 10) -> List[Dict]:
        """Get all-time high scores"""
        return await self.db.get_leaderboard(limit=limit)
    
    async def get_monthly_leaderboard(self, limit: int = 10) -> List[Dict]:
        """Get current month's leaderboard"""
        start_date = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        return await self.db.get_leaderboard(start_date=start_date, limit=limit)
    
    async def get_weekly_leaderboard(self, limit: int = 10) -> List[Dict]:
        """Get current week's leaderboard"""
        today = datetime.now()
        start_date = today - timedelta(days=today.weekday())
        start_date = start_date.replace(hour=0, minute=0, second=0, microsecond=0)
        return await self.db.get_leaderboard(start_date=start_date, limit=limit)
    
    async def get_highest_debt_survived(self, limit: int = 10) -> List[Dict]:
        """Get players who survived with highest debt"""
        return await self.db.get_leaderboard_by_criteria('highest_debt', limit=limit)
    
    async def get_player_position(self, user_id: int) -> Optional[int]:
        """Get player's position on all-time leaderboard"""
        return await self.db.get_player_leaderboard_position(user_id)
    
    async def get_player_best_score(self, user_id: int) -> Optional[Dict]:
        """Get player's best score"""
        scores = await self.db.get_player_scores(user_id, limit=1)
        return scores[0] if scores else None
    
    async def get_player_recent_scores(self, user_id: int, limit: int = 10) -> List[Dict]:
        """Get player's recent scores"""
        return await self.db.get_player_scores(user_id, limit=limit)
    
    # Competition Management
    
    async def create_competition(self, title: str, duration_days: int, games_required: int, created_by: int) -> Competition:
        """Create a new competition"""
        competition = Competition(
            id=0,  # Will be assigned by database
            title=title,
            start_date=datetime.now(),
            end_date=datetime.now() + timedelta(days=duration_days),
            games_required=games_required,
            created_by=created_by,
            is_active=True,
            participants=[]
        )
        
        competition_id = await self.db.create_competition(competition)
        competition.id = competition_id
        
        return competition
    
    async def get_active_competition(self) -> Optional[Competition]:
        """Get currently active competition"""
        return await self.db.get_active_competition()
    
    async def get_competition_leaderboard(self, competition_id: int) -> List[Dict]:
        """Get leaderboard for a specific competition"""
        return await self.db.get_competition_leaderboard(competition_id)
    
    async def join_competition(self, competition_id: int, user_id: int) -> bool:
        """Join a competition"""
        competition = await self.db.get_competition(competition_id)
        
        if not competition or not competition.is_active:
            return False
        
        if datetime.now() > competition.end_date:
            return False
        
        return await self.db.add_competition_participant(competition_id, user_id)
    
    async def add_competition_score(self, competition_id: int, user_id: int, score: int) -> bool:
        """Add a score to competition"""
        competition = await self.db.get_competition(competition_id)
        
        if not competition or not competition.is_active:
            return False
        
        if user_id not in competition.participants:
            await self.join_competition(competition_id, user_id)
        
        return await self.db.add_competition_score(competition_id, user_id, score)
    
    async def end_competition(self, competition_id: int) -> Dict:
        """End a competition and return results"""
        competition = await self.db.get_competition(competition_id)
        
        if not competition:
            return {'success': False, 'message': 'Competition not found'}
        
        # Mark as inactive
        await self.db.update_competition_status(competition_id, False)
        
        # Get final results
        results = await self.get_competition_leaderboard(competition_id)
        
        # Award winners (could add prizes/badges here)
        winners = results[:3] if len(results) >= 3 else results
        
        return {
            'success': True,
            'competition': competition,
            'winners': winners,
            'total_participants': len(competition.participants)
        }
    
    async def get_past_competitions(self, limit: int = 10) -> List[Competition]:
        """Get past competitions"""
        return await self.db.get_past_competitions(limit=limit)
    
    async def get_competition_stats(self, competition_id: int, user_id: int) -> Dict:
        """Get user's stats for a competition"""
        return await self.db.get_competition_user_stats(competition_id, user_id)
    
    def format_leaderboard(self, entries: List[Dict], title: str = "Leaderboard") -> str:
        """Format leaderboard for display"""
        if not entries:
            return f"🏆 **{title}**\n\nNo entries yet! Be the first!"
        
        lines = [f"🏆 **{title}**\n"]
        
        for i, entry in enumerate(entries[:10], 1):
            emoji = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
            
            # Format score with commas
            score = f"${entry['score']:,}"
            
            # Add time ago
            timestamp = datetime.fromisoformat(entry['timestamp'])
            days_ago = (datetime.now() - timestamp).days
            time_str = "today" if days_ago == 0 else f"{days_ago}d ago" if days_ago < 30 else timestamp.strftime("%b %d")
            
            lines.append(f"{emoji} **{entry['username']}** - {score} ({time_str})")
        
        return '\n'.join(lines)
    
    def format_competition_info(self, competition: Competition, leaderboard: List[Dict] = None) -> str:
        """Format competition information"""
        lines = [f"🏅 **{competition.title}**\n"]
        
        # Status
        if competition.is_active:
            time_left = competition.end_date - datetime.now()
            days_left = time_left.days
            hours_left = time_left.seconds // 3600
            
            if days_left > 0:
                lines.append(f"⏱️ Time left: {days_left} days")
            else:
                lines.append(f"⏱️ Time left: {hours_left} hours")
        else:
            lines.append("🏁 Competition ended")
        
        lines.extend([
            f"📅 Started: {competition.start_date.strftime('%b %d, %Y')}",
            f"🎮 Games required: {competition.games_required}",
            f"👥 Participants: {len(competition.participants)}"
        ])
        
        if leaderboard:
            lines.append("\n**Current Standings:**")
            for i, entry in enumerate(leaderboard[:5], 1):
                lines.append(f"{i}. {entry['username']} - ${entry['best_score']:,} ({entry['games_played']}/{competition.games_required} games)")
        
        return '\n'.join(lines)
    
    async def get_player_achievements(self, user_id: int) -> List[Dict]:
        """Get player achievements"""
        achievements = []
        
        # Check various achievement criteria
        stats = await self.db.get_player_stats(user_id)
        
        if not stats:
            return achievements
        
        # Games played achievements
        if stats['games_played'] >= 100:
            achievements.append({
                'name': 'Veteran Dealer',
                'description': 'Played 100+ games',
                'emoji': '🎖️'
            })
        elif stats['games_played'] >= 50:
            achievements.append({
                'name': 'Experienced Trader',
                'description': 'Played 50+ games',
                'emoji': '🏅'
            })
        elif stats['games_played'] >= 10:
            achievements.append({
                'name': 'Getting Started',
                'description': 'Played 10+ games',
                'emoji': '🥉'
            })
        
        # Score achievements
        if stats['high_score'] >= 1000000:
            achievements.append({
                'name': 'Crypto Millionaire',
                'description': 'Scored over $1,000,000',
                'emoji': '💎'
            })
        elif stats['high_score'] >= 500000:
            achievements.append({
                'name': 'High Roller',
                'description': 'Scored over $500,000',
                'emoji': '💰'
            })
        
        # Special achievements
        if stats.get('perfect_games', 0) > 0:
            achievements.append({
                'name': 'Perfect Game',
                'description': 'Completed game with no debt',
                'emoji': '⭐'
            })
        
        if stats.get('survivor_games', 0) >= 10:
            achievements.append({
                'name': 'Survivor',
                'description': 'Survived 30 days in 10+ games',
                'emoji': '🛡️'
            })
        
        # Competition achievements
        competition_wins = await self.db.get_player_competition_wins(user_id)
        if competition_wins > 0:
            achievements.append({
                'name': 'Competition Winner',
                'description': f'Won {competition_wins} competition(s)',
                'emoji': '🏆'
            })
        
        return achievements