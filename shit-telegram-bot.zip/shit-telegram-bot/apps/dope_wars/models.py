#!/usr/bin/env python3
"""
Models for DopeWars game
Complete database and game state models with ALL features preserved
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Any
import json


@dataclass
class GameState:
    """Complete game state model for persistence"""
    user_id: int
    username: str
    cash: int
    debt: int
    bank_balance: int
    day: int
    max_days: int
    health: int
    max_health: int
    guns: int
    max_inventory: int
    current_location: str
    inventory: Dict[str, int]
    inventory_costs: Dict[str, float]
    current_prices: Dict[str, int]
    price_history: Dict[str, List[int]] = field(default_factory=dict)
    market_events: List[Dict] = field(default_factory=list)
    is_game_over_flag: bool = False
    game_over_reason: str = ""
    game_started: Optional[datetime] = None
    total_purchases: int = 0
    total_sales: int = 0
    total_profit: int = 0
    locations_visited: List[str] = field(default_factory=list)
    days_survived: int = 0
    events_encountered: List[str] = field(default_factory=list)
    config: Dict[str, Any] = field(default_factory=dict)
    drugs: Dict[str, Dict] = field(default_factory=dict)
    locations: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization"""
        return {
            'user_id': self.user_id,
            'username': self.username,
            'cash': self.cash,
            'debt': self.debt,
            'bank_balance': self.bank_balance,
            'day': self.day,
            'max_days': self.max_days,
            'health': self.health,
            'max_health': self.max_health,
            'guns': self.guns,
            'max_inventory': self.max_inventory,
            'current_location': self.current_location,
            'inventory': self.inventory,
            'inventory_costs': self.inventory_costs,
            'current_prices': self.current_prices,
            'price_history': self.price_history,
            'market_events': self.market_events,
            'is_game_over_flag': self.is_game_over_flag,
            'game_over_reason': self.game_over_reason,
            'game_started': self.game_started.isoformat() if self.game_started else None,
            'total_purchases': self.total_purchases,
            'total_sales': self.total_sales,
            'total_profit': self.total_profit,
            'locations_visited': self.locations_visited,
            'days_survived': self.days_survived,
            'events_encountered': self.events_encountered,
            'config': self.config,
            'drugs': self.drugs,
            'locations': self.locations
        }
        
    @classmethod
    def from_dict(cls, data: Dict) -> 'GameState':
        """Create from dictionary"""
        # Handle datetime parsing
        game_started = None
        if data.get('game_started'):
            try:
                game_started = datetime.fromisoformat(data['game_started'])
            except:
                game_started = datetime.now()
        
        return cls(
            user_id=data['user_id'],
            username=data['username'],
            cash=data.get('cash', 0),
            debt=data.get('debt', 0),
            bank_balance=data.get('bank_balance', 0),
            day=data.get('day', 1),
            max_days=data.get('max_days', 30),
            health=data.get('health', 100),
            max_health=data.get('max_health', 100),
            guns=data.get('guns', 0),
            max_inventory=data.get('max_inventory', 100),
            current_location=data.get('current_location', ''),
            inventory=data.get('inventory', {}),
            inventory_costs=data.get('inventory_costs', {}),
            current_prices=data.get('current_prices', {}),
            price_history=data.get('price_history', {}),
            market_events=data.get('market_events', []),
            is_game_over_flag=data.get('is_game_over_flag', False),
            game_over_reason=data.get('game_over_reason', ''),
            game_started=game_started,
            total_purchases=data.get('total_purchases', 0),
            total_sales=data.get('total_sales', 0),
            total_profit=data.get('total_profit', 0),
            locations_visited=data.get('locations_visited', []),
            days_survived=data.get('days_survived', 0),
            events_encountered=data.get('events_encountered', []),
            config=data.get('config', {}),
            drugs=data.get('drugs', {}),
            locations=data.get('locations', [])
        )


@dataclass
class PlayerStats:
    """Complete player statistics model"""
    user_id: int
    username: str
    games_played: int = 0
    high_score: int = 0
    total_score: int = 0
    avg_score: float = 0.0
    total_profit: int = 0
    total_purchases: int = 0
    total_sales: int = 0
    total_days_survived: int = 0
    total_locations_visited: int = 0
    total_events_encountered: int = 0
    favorite_location: Optional[str] = None
    most_traded_drug: Optional[str] = None
    highest_cash: int = 0
    lowest_debt: int = 0
    best_health: int = 0
    most_guns: int = 0
    completion_rate: float = 0.0  # % of games completed vs died early
    first_game_date: Optional[datetime] = None
    last_game_date: Optional[datetime] = None
    total_playtime_hours: float = 0.0
    achievements: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            'user_id': self.user_id,
            'username': self.username,
            'games_played': self.games_played,
            'high_score': self.high_score,
            'total_score': self.total_score,
            'avg_score': self.avg_score,
            'total_profit': self.total_profit,
            'total_purchases': self.total_purchases,
            'total_sales': self.total_sales,
            'total_days_survived': self.total_days_survived,
            'total_locations_visited': self.total_locations_visited,
            'total_events_encountered': self.total_events_encountered,
            'favorite_location': self.favorite_location,
            'most_traded_drug': self.most_traded_drug,
            'highest_cash': self.highest_cash,
            'lowest_debt': self.lowest_debt,
            'best_health': self.best_health,
            'most_guns': self.most_guns,
            'completion_rate': self.completion_rate,
            'first_game_date': self.first_game_date.isoformat() if self.first_game_date else None,
            'last_game_date': self.last_game_date.isoformat() if self.last_game_date else None,
            'total_playtime_hours': self.total_playtime_hours,
            'achievements': self.achievements
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'PlayerStats':
        """Create from dictionary"""
        first_game_date = None
        last_game_date = None
        
        if data.get('first_game_date'):
            try:
                first_game_date = datetime.fromisoformat(data['first_game_date'])
            except:
                pass
                
        if data.get('last_game_date'):
            try:
                last_game_date = datetime.fromisoformat(data['last_game_date'])
            except:
                pass
        
        return cls(
            user_id=data['user_id'],
            username=data['username'],
            games_played=data.get('games_played', 0),
            high_score=data.get('high_score', 0),
            total_score=data.get('total_score', 0),
            avg_score=data.get('avg_score', 0.0),
            total_profit=data.get('total_profit', 0),
            total_purchases=data.get('total_purchases', 0),
            total_sales=data.get('total_sales', 0),
            total_days_survived=data.get('total_days_survived', 0),
            total_locations_visited=data.get('total_locations_visited', 0),
            total_events_encountered=data.get('total_events_encountered', 0),
            favorite_location=data.get('favorite_location'),
            most_traded_drug=data.get('most_traded_drug'),
            highest_cash=data.get('highest_cash', 0),
            lowest_debt=data.get('lowest_debt', 0),
            best_health=data.get('best_health', 0),
            most_guns=data.get('most_guns', 0),
            completion_rate=data.get('completion_rate', 0.0),
            first_game_date=first_game_date,
            last_game_date=last_game_date,
            total_playtime_hours=data.get('total_playtime_hours', 0.0),
            achievements=data.get('achievements', [])
        )


@dataclass
class LeaderboardEntry:
    """Complete leaderboard entry model"""
    rank: int
    user_id: int
    username: str
    score: int
    date: datetime
    days_survived: int = 0
    final_cash: int = 0
    final_debt: int = 0
    health: int = 0
    completion_status: str = ""  # "completed", "died", "timeout"
    game_data: Optional[Dict] = None
    contest_id: Optional[int] = None
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            'rank': self.rank,
            'user_id': self.user_id,
            'username': self.username,
            'score': self.score,
            'date': self.date.isoformat(),
            'days_survived': self.days_survived,
            'final_cash': self.final_cash,
            'final_debt': self.final_debt,
            'health': self.health,
            'completion_status': self.completion_status,
            'game_data': self.game_data,
            'contest_id': self.contest_id
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'LeaderboardEntry':
        """Create from dictionary"""
        date = datetime.now()
        if data.get('date'):
            try:
                date = datetime.fromisoformat(data['date'])
            except:
                pass
        
        return cls(
            rank=data['rank'],
            user_id=data['user_id'],
            username=data['username'],
            score=data['score'],
            date=date,
            days_survived=data.get('days_survived', 0),
            final_cash=data.get('final_cash', 0),
            final_debt=data.get('final_debt', 0),
            health=data.get('health', 0),
            completion_status=data.get('completion_status', ''),
            game_data=data.get('game_data'),
            contest_id=data.get('contest_id')
        )


@dataclass
class Contest:
    """Contest model for competitive gameplay"""
    id: int
    name: str
    description: str
    start_time: datetime
    end_time: datetime
    active: bool = True
    max_participants: Optional[int] = None
    entry_fee: int = 0
    prize_pool: int = 0
    rules: Dict[str, Any] = field(default_factory=dict)
    created_by: Optional[int] = None
    created_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat(),
            'active': self.active,
            'max_participants': self.max_participants,
            'entry_fee': self.entry_fee,
            'prize_pool': self.prize_pool,
            'rules': self.rules,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Contest':
        """Create from dictionary"""
        start_time = datetime.fromisoformat(data['start_time'])
        end_time = datetime.fromisoformat(data['end_time'])
        created_at = datetime.now()
        
        if data.get('created_at'):
            try:
                created_at = datetime.fromisoformat(data['created_at'])
            except:
                pass
        
        return cls(
            id=data['id'],
            name=data['name'],
            description=data['description'],
            start_time=start_time,
            end_time=end_time,
            active=data.get('active', True),
            max_participants=data.get('max_participants'),
            entry_fee=data.get('entry_fee', 0),
            prize_pool=data.get('prize_pool', 0),
            rules=data.get('rules', {}),
            created_by=data.get('created_by'),
            created_at=created_at
        )
    
    def is_active(self) -> bool:
        """Check if contest is currently active"""
        now = datetime.now()
        return self.active and self.start_time <= now <= self.end_time
    
    def is_upcoming(self) -> bool:
        """Check if contest is upcoming"""
        return self.active and datetime.now() < self.start_time
    
    def is_expired(self) -> bool:
        """Check if contest has expired"""
        return datetime.now() > self.end_time
    
    def time_remaining(self) -> Optional[float]:
        """Get time remaining in hours, None if expired"""
        if self.is_expired():
            return None
        
        remaining = self.end_time - datetime.now()
        return remaining.total_seconds() / 3600


@dataclass
class Achievement:
    """Achievement/badge system model"""
    id: str
    name: str
    description: str
    category: str  # "score", "survival", "trading", "exploration", etc.
    requirements: Dict[str, Any]
    reward_points: int = 0
    emoji: str = "🏆"
    rarity: str = "common"  # "common", "rare", "epic", "legendary"
    hidden: bool = False  # Hidden until unlocked
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'category': self.category,
            'requirements': self.requirements,
            'reward_points': self.reward_points,
            'emoji': self.emoji,
            'rarity': self.rarity,
            'hidden': self.hidden
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Achievement':
        """Create from dictionary"""
        return cls(
            id=data['id'],
            name=data['name'],
            description=data['description'],
            category=data['category'],
            requirements=data['requirements'],
            reward_points=data.get('reward_points', 0),
            emoji=data.get('emoji', '🏆'),
            rarity=data.get('rarity', 'common'),
            hidden=data.get('hidden', False)
        )


@dataclass
class UserAchievement:
    """User's earned achievement"""
    user_id: int
    achievement_id: str
    earned_at: datetime
    game_session_id: Optional[str] = None
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            'user_id': self.user_id,
            'achievement_id': self.achievement_id,
            'earned_at': self.earned_at.isoformat(),
            'game_session_id': self.game_session_id
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'UserAchievement':
        """Create from dictionary"""
        earned_at = datetime.fromisoformat(data['earned_at'])
        
        return cls(
            user_id=data['user_id'],
            achievement_id=data['achievement_id'],
            earned_at=earned_at,
            game_session_id=data.get('game_session_id')
        )


@dataclass
class GameEvent:
    """Random game event model"""
    id: str
    name: str
    description: str
    event_type: str  # "cop_encounter", "whale_offer", "market_crash", etc.
    probability: float  # 0.0 to 1.0
    effects: Dict[str, Any]
    requirements: Dict[str, Any] = field(default_factory=dict)  # Conditions for event to trigger
    message_templates: List[str] = field(default_factory=list)
    choices: List[Dict] = field(default_factory=list)  # Player choices if interactive
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'event_type': self.event_type,
            'probability': self.probability,
            'effects': self.effects,
            'requirements': self.requirements,
            'message_templates': self.message_templates,
            'choices': self.choices
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'GameEvent':
        """Create from dictionary"""
        return cls(
            id=data['id'],
            name=data['name'],
            description=data['description'],
            event_type=data['event_type'],
            probability=data['probability'],
            effects=data['effects'],
            requirements=data.get('requirements', {}),
            message_templates=data.get('message_templates', []),
            choices=data.get('choices', [])
        )


@dataclass
class MarketEvent:
    """Market price manipulation event"""
    id: str
    day: int
    event_type: str
    affected_drug: str
    multiplier: float
    message: str
    duration: int = 1  # How many days the effect lasts
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            'id': self.id,
            'day': self.day,
            'event_type': self.event_type,
            'affected_drug': self.affected_drug,
            'multiplier': self.multiplier,
            'message': self.message,
            'duration': self.duration
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'MarketEvent':
        """Create from dictionary"""
        return cls(
            id=data['id'],
            day=data['day'],
            event_type=data['event_type'],
            affected_drug=data['affected_drug'],
            multiplier=data['multiplier'],
            message=data['message'],
            duration=data.get('duration', 1)
        )


# Utility functions for model management
def serialize_game_state(game) -> str:
    """Serialize a DopeWarsGame instance to JSON string"""
    return json.dumps(game.get_state(), default=str)


def deserialize_game_state(json_data: str) -> Dict:
    """Deserialize JSON string to game state dictionary"""
    return json.loads(json_data)


def create_achievement_system() -> List[Achievement]:
    """Create default achievement system"""
    achievements = [
        # Score-based achievements
        Achievement(
            id="first_million",
            name="Millionaire",
            description="Earn your first million dollars",
            category="score",
            requirements={"min_score": 1000000},
            reward_points=100,
            emoji="💰",
            rarity="common"
        ),
        Achievement(
            id="high_roller",
            name="High Roller",
            description="Score over 10 million dollars",
            category="score",
            requirements={"min_score": 10000000},
            reward_points=500,
            emoji="💎",
            rarity="rare"
        ),
        
        # Survival achievements
        Achievement(
            id="survivor",
            name="Survivor",
            description="Complete a full game without dying",
            category="survival",
            requirements={"completed_game": True, "min_health": 1},
            reward_points=200,
            emoji="❤️",
            rarity="common"
        ),
        Achievement(
            id="iron_man",
            name="Iron Man",
            description="Complete a game with 100% health",
            category="survival",
            requirements={"completed_game": True, "min_health": 100},
            reward_points=1000,
            emoji="🛡️",
            rarity="epic"
        ),
        
        # Trading achievements
        Achievement(
            id="day_trader",
            name="Day Trader",
            description="Make 100 transactions in a single game",
            category="trading",
            requirements={"min_transactions": 100},
            reward_points=150,
            emoji="📈",
            rarity="common"
        ),
        Achievement(
            id="whale",
            name="Crypto Whale",
            description="Make a single transaction worth over $1M",
            category="trading",
            requirements={"max_single_transaction": 1000000},
            reward_points=300,
            emoji="🐋",
            rarity="rare"
        ),
        
        # Exploration achievements
        Achievement(
            id="explorer",
            name="Explorer",
            description="Visit all available locations",
            category="exploration",
            requirements={"visited_all_locations": True},
            reward_points=100,
            emoji="🗺️",
            rarity="common"
        ),
        
        # Special achievements
        Achievement(
            id="debt_free",
            name="Debt Free",
            description="Pay off all debt and complete the game",
            category="special",
            requirements={"completed_game": True, "max_debt": 0},
            reward_points=400,
            emoji="🏦",
            rarity="rare"
        ),
        Achievement(
            id="pacifist",
            name="Pacifist",
            description="Complete a game without buying any guns",
            category="special",
            requirements={"completed_game": True, "max_guns": 0},
            reward_points=250,
            emoji="☮️",
            rarity="rare"
        ),
        Achievement(
            id="arsenal",
            name="Arsenal",
            description="Own 10 or more guns in a single game",
            category="special",
            requirements={"min_guns": 10},
            reward_points=200,
            emoji="🔫",
            rarity="rare"
        )
    ]
    
    return achievements


def check_achievements(game_summary: Dict, user_achievements: List[str]) -> List[str]:
    """Check which new achievements a player has earned"""
    achievements = create_achievement_system()
    new_achievements = []
    
    for achievement in achievements:
        # Skip if already earned
        if achievement.id in user_achievements:
            continue
        
        # Check requirements
        earned = True
        req = achievement.requirements
        
        if 'min_score' in req and game_summary.get('score', 0) < req['min_score']:
            earned = False
        
        if 'completed_game' in req and req['completed_game']:
            if game_summary.get('days_survived', 0) < game_summary.get('max_days', 30):
                earned = False
        
        if 'min_health' in req and game_summary.get('health', 0) < req['min_health']:
            earned = False
        
        if 'max_debt' in req and game_summary.get('final_debt', 0) > req['max_debt']:
            earned = False
        
        if 'min_guns' in req and game_summary.get('guns', 0) < req['min_guns']:
            earned = False
        
        if 'max_guns' in req and game_summary.get('guns', 0) > req['max_guns']:
            earned = False
        
        # Add more requirement checks as needed
        
        if earned:
            new_achievements.append(achievement.id)
    
    return new_achievements


# Export all model classes
__all__ = [
    'GameState',
    'PlayerStats', 
    'LeaderboardEntry',
    'Contest',
    'Achievement',
    'UserAchievement',
    'GameEvent',
    'MarketEvent',
    'serialize_game_state',
    'deserialize_game_state',
    'create_achievement_system',
    'check_achievements'
]