#!/usr/bin/env python3
"""
# File location: /apps/shit_tracker/tracker.py
Enhanced SHIT Tracker - Shibarium Historical Income Tracker
Complete implementation with all requested features
"""

import asyncio
import json
import logging
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import aiohttp
import pandas as pd
from web3 import Web3
from web3.exceptions import BlockNotFound
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment

from apps.shit_tracker.processors.swap_processor import SwapProcessor
from apps.shit_tracker.processors.bridge_processor import BridgeProcessor
from apps.shit_tracker.processors.nft_processor import NFTProcessor
from apps.shit_tracker.utils.token_manager import TokenManager
from apps.shit_tracker.utils.price_resolver import PriceResolver

logger = logging.getLogger(__name__)


class ShibariumTracker:
    """Enhanced Shibarium blockchain tracker with full feature set"""
    
    def __init__(self, api_key: str = None, api_key2: str = None):
        """Initialize tracker with API keys"""
        self.api_key = api_key or os.getenv('SHIBARIUM_API_KEY')
        self.api_key2 = api_key2 or os.getenv('SHIBARIUM_API_KEY2')
        
        if not self.api_key:
            logger.warning("No Shibarium API key provided")
        
        # Initialize Web3
        self.w3 = Web3(Web3.HTTPProvider('https://www.shibrpc.com'))
        
        # Initialize components
        self.token_manager = TokenManager()
        self.price_resolver = PriceResolver()
        self.swap_processor = SwapProcessor(self.w3, self.token_manager)
        self.bridge_processor = BridgeProcessor(self.w3, self.token_manager)
        self.nft_processor = NFTProcessor(self.w3)
        
        # API endpoints
        self.api_base = 'https://www.shibariumscan.io/api'
        self.current_api_key = self.api_key
        
        # Cache directories
        self.cache_dir = Path('/app/data')
        self.token_cache_file = self.cache_dir / 'tokens' / 'token_cache.json'
        self.router_cache_file = self.cache_dir / 'routers' / 'router_cache.json'
        self.bridge_cache_file = self.cache_dir / 'bridges' / 'bridge_cache.json'
        
        # Ensure cache directories exist
        for cache_file in [self.token_cache_file, self.router_cache_file, self.bridge_cache_file]:
            cache_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Load caches
        self.token_cache = self._load_cache(self.token_cache_file)
        self.router_cache = self._load_cache(self.router_cache_file)
        self.bridge_cache = self._load_cache(self.bridge_cache_file)
        
        # Known routers and bridges
        self._init_known_contracts()
    
    def _init_known_contracts(self):
        """Initialize known DEX routers and bridges"""
        self.known_routers = {
            '0x1b2a29b7710e3ba1c7981c00eaa829277c0ee0f5': 'ShibaSwap',
            '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506': 'SushiSwap',
            # Add more routers as discovered
        }
        
        self.known_bridges = {
            '0x2796317b0ff8d341f93e7f2e5c3b3e78b7f9c6a5': 'Shibarium Bridge',
            # Add more bridges as discovered
        }
        
        # Update caches
        self.router_cache.update(self.known_routers)
        self.bridge_cache.update(self.known_bridges)
    
    def _load_cache(self, cache_file: Path) -> Dict:
        """Load cache from file"""
        if cache_file.exists():
            try:
                with open(cache_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading cache {cache_file}: {e}")
        return {}
    
    def _save_cache(self, cache_file: Path, data: Dict):
        """Save cache to file"""
        try:
            with open(cache_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving cache {cache_file}: {e}")
    
    async def scan_wallet(self, 
                         wallet_address: str,
                         start_date: datetime,
                         end_date: datetime,
                         progress_callback=None) -> Dict[str, Any]:
        """
        Scan wallet for all transactions in date range
        
        Args:
            wallet_address: Wallet address to scan
            start_date: Start date for scan
            end_date: End date for scan
            progress_callback: Optional callback for progress updates
            
        Returns:
            Dictionary with scan results
        """
        results = {
            'wallet': wallet_address,
            'start_date': start_date.isoformat(),
            'end_date': end_date.isoformat(),
            'transactions': [],
            'token_transfers': [],
            'nft_transfers': [],
            'summary': {
                'total_transactions': 0,
                'bridges': 0,
                'swaps': 0,
                'sends': 0,
                'receives': 0,
                'staking': 0,
                'total_profit_loss': 0,
                'gas_spent': 0
            },
            'tokens_discovered': {},
            'errors': []
        }
        
        try:
            # Get block range for date range
            start_block = await self._get_block_at_timestamp(int(start_date.timestamp()))
            end_block = await self._get_block_at_timestamp(int(end_date.timestamp()))
            
            logger.info(f"Scanning blocks {start_block} to {end_block}")
            
            # Get normal transactions
            if progress_callback:
                await progress_callback("Fetching transactions...")
            
            txs = await self._get_transactions(wallet_address, start_block, end_block)
            results['transactions'] = txs
            results['summary']['total_transactions'] = len(txs)
            
            # Get token transfers
            if progress_callback:
                await progress_callback("Fetching token transfers...")
            
            transfers = await self._get_token_transfers(wallet_address, start_block, end_block)
            results['token_transfers'] = transfers
            
            # Get NFT transfers
            if progress_callback:
                await progress_callback("Fetching NFT transfers...")
            
            nft_transfers = await self._get_nft_transfers(wallet_address, start_block, end_block)
            results['nft_transfers'] = nft_transfers
            
            # Process transactions
            if progress_callback:
                await progress_callback("Processing transactions...")
            
            await self._process_transactions(results, wallet_address, progress_callback)
            
            # Calculate summary statistics
            self._calculate_summary(results)
            
            # Save discovered tokens
            self._save_cache(self.token_cache_file, self.token_cache)
            self._save_cache(self.router_cache_file, self.router_cache)
            self._save_cache(self.bridge_cache_file, self.bridge_cache)
            
        except Exception as e:
            logger.error(f"Error scanning wallet: {e}")
            results['errors'].append(str(e))
        
        return results
    
    async def _get_block_at_timestamp(self, timestamp: int) -> int:
        """Get block number at specific timestamp"""
        try:
            params = {
                'module': 'block',
                'action': 'getblocknobytime',
                'timestamp': timestamp,
                'closest': 'before',
                'apikey': self.current_api_key
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.get(self.api_base, params=params) as response:
                    data = await response.json()
                    if data['status'] == '1':
                        return int(data['result'])
                    else:
                        # Fallback to estimation
                        current_block = self.w3.eth.block_number
                        blocks_per_day = 28800  # ~3 second blocks
                        days_ago = (datetime.now().timestamp() - timestamp) / 86400
                        estimated_block = current_block - int(days_ago * blocks_per_day)
                        return max(1, estimated_block)
        except Exception as e:
            logger.error(f"Error getting block at timestamp: {e}")
            # Fallback estimation
            return 1
    
    async def _get_transactions(self, address: str, start_block: int, end_block: int) -> List[Dict]:
        """Get normal transactions for address"""
        try:
            params = {
                'module': 'account',
                'action': 'txlist',
                'address': address,
                'startblock': start_block,
                'endblock': end_block,
                'sort': 'asc',
                'apikey': self.current_api_key
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.get(self.api_base, params=params) as response:
                    data = await response.json()
                    if data['status'] == '1':
                        return data['result']
                    elif self.api_key2 and self.current_api_key == self.api_key:
                        # Try backup API key
                        self.current_api_key = self.api_key2
                        return await self._get_transactions(address, start_block, end_block)
                    else:
                        return []
        except Exception as e:
            logger.error(f"Error getting transactions: {e}")
            return []
    
    async def _get_token_transfers(self, address: str, start_block: int, end_block: int) -> List[Dict]:
        """Get ERC20 token transfers"""
        try:
            params = {
                'module': 'account',
                'action': 'tokentx',
                'address': address,
                'startblock': start_block,
                'endblock': end_block,
                'sort': 'asc',
                'apikey': self.current_api_key
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.get(self.api_base, params=params) as response:
                    data = await response.json()
                    if data['status'] == '1':
                        return data['result']
                    else:
                        return []
        except Exception as e:
            logger.error(f"Error getting token transfers: {e}")
            return []
    
    async def _get_nft_transfers(self, address: str, start_block: int, end_block: int) -> List[Dict]:
        """Get NFT transfers (ERC721 and ERC1155)"""
        nft_transfers = []
        
        # Get ERC721 transfers
        try:
            params = {
                'module': 'account',
                'action': 'tokennfttx',
                'address': address,
                'startblock': start_block,
                'endblock': end_block,
                'sort': 'asc',
                'apikey': self.current_api_key
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.get(self.api_base, params=params) as response:
                    data = await response.json()
                    if data['status'] == '1':
                        nft_transfers.extend(data['result'])
        except Exception as e:
            logger.error(f"Error getting NFT transfers: {e}")
        
        # Get ERC1155 transfers
        try:
            params['action'] = 'token1155tx'
            
            async with aiohttp.ClientSession() as session:
                async with session.get(self.api_base, params=params) as response:
                    data = await response.json()
                    if data['status'] == '1':
                        nft_transfers.extend(data['result'])
        except Exception as e:
            logger.error(f"Error getting ERC1155 transfers: {e}")
        
        return nft_transfers
    
    async def _process_transactions(self, results: Dict, wallet_address: str, progress_callback=None):
        """Process and categorize transactions"""
        total_txs = len(results['transactions'])
        
        for i, tx in enumerate(results['transactions']):
            if progress_callback and i % 10 == 0:
                await progress_callback(f"Processing transaction {i+1}/{total_txs}")
            
            try:
                # Skip failed transactions
                if tx.get('isError') == '1':
                    continue
                
                # Check if it's a bridge transaction
                if tx['to'] and tx['to'].lower() in self.bridge_cache:
                    tx['type'] = 'bridge'
                    tx['bridge_name'] = self.bridge_cache[tx['to'].lower()]
                    results['summary']['bridges'] += 1
                
                # Check if it's a DEX transaction
                elif tx['to'] and tx['to'].lower() in self.router_cache:
                    tx['type'] = 'swap'
                    tx['dex_name'] = self.router_cache[tx['to'].lower()]
                    results['summary']['swaps'] += 1
                    
                    # Process swap details
                    swap_data = await self.swap_processor.process_swap(tx['hash'])
                    if swap_data:
                        tx['swap_details'] = swap_data
                
                # Regular transfer
                elif tx['from'].lower() == wallet_address.lower():
                    tx['type'] = 'send'
                    results['summary']['sends'] += 1
                else:
                    tx['type'] = 'receive'
                    results['summary']['receives'] += 1
                
                # Add gas cost
                gas_cost = int(tx['gasUsed']) * int(tx['gasPrice'])
                tx['gas_cost_wei'] = gas_cost
                tx['gas_cost_bone'] = Web3.from_wei(gas_cost, 'ether')
                results['summary']['gas_spent'] += float(tx['gas_cost_bone'])
                
            except Exception as e:
                logger.error(f"Error processing transaction {tx['hash']}: {e}")
                results['errors'].append(f"TX {tx['hash']}: {str(e)}")
        
        # Process token transfers
        for transfer in results['token_transfers']:
            try:
                # Get token info if not cached
                token_address = transfer['contractAddress']
                if token_address not in self.token_cache:
                    token_info = await self.token_manager.get_token_info(token_address)
                    if token_info:
                        self.token_cache[token_address] = token_info
                
                # Add token info to transfer
                if token_address in self.token_cache:
                    transfer['token_info'] = self.token_cache[token_address]
                
                # Categorize transfer
                if transfer['from'].lower() == wallet_address.lower():
                    transfer['direction'] = 'out'
                else:
                    transfer['direction'] = 'in'
                
            except Exception as e:
                logger.error(f"Error processing token transfer: {e}")
    
    def _calculate_summary(self, results: Dict):
        """Calculate summary statistics"""
        # Group transactions by token
        token_summary = {}
        
        for transfer in results['token_transfers']:
            token_address = transfer['contractAddress']
            token_info = transfer.get('token_info', {})
            token_symbol = token_info.get('symbol', 'UNKNOWN')
            
            if token_symbol not in token_summary:
                token_summary[token_symbol] = {
                    'in': 0,
                    'out': 0,
                    'transfers': []
                }
            
            amount = int(transfer['value']) / (10 ** int(token_info.get('decimals', 18)))
            
            if transfer['direction'] == 'in':
                token_summary[token_symbol]['in'] += amount
            else:
                token_summary[token_symbol]['out'] += amount
            
            token_summary[token_symbol]['transfers'].append(transfer)
        
        results['token_summary'] = token_summary
    
    async def generate_reports(self, scan_results: Dict, output_dir: Path) -> Dict[str, Path]:
        """Generate output files from scan results"""
        output_files = {}
        
        try:
            # Generate Excel report
            excel_path = output_dir / f"shibarium_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            await self._generate_excel_report(scan_results, excel_path)
            output_files['excel'] = excel_path
            
            # Generate Koinly CSV
            koinly_path = output_dir / f"koinly_import_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            await self._generate_koinly_csv(scan_results, koinly_path)
            output_files['koinly'] = koinly_path
            
            # Generate summary report
            summary_path = output_dir / f"summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            await self._generate_summary_report(scan_results, summary_path)
            output_files['summary'] = summary_path
            
        except Exception as e:
            logger.error(f"Error generating reports: {e}")
            raise
        
        return output_files
    
    async def _generate_excel_report(self, results: Dict, output_path: Path):
        """Generate detailed Excel report"""
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            # Transactions sheet
            if results['transactions']:
                tx_data = []
                for tx in results['transactions']:
                    tx_data.append({
                        'Timestamp': datetime.fromtimestamp(int(tx['timeStamp'])).strftime('%Y-%m-%d %H:%M:%S'),
                        'Type': tx.get('type', 'unknown'),
                        'Hash': tx['hash'],
                        'From': tx['from'],
                        'To': tx['to'],
                        'Value (BONE)': float(Web3.from_wei(int(tx.get('value', 0)), 'ether')),
                        'Gas Cost (BONE)': float(tx.get('gas_cost_bone', 0)),
                        'Status': 'Success' if tx.get('isError') == '0' else 'Failed',
                        'DEX/Bridge': tx.get('dex_name', tx.get('bridge_name', '')),
                        'URL': f"https://www.shibariumscan.io/tx/{tx['hash']}"
                    })
                
                df_tx = pd.DataFrame(tx_data)
                df_tx.to_excel(writer, sheet_name='Transactions', index=False)
                
                # Format the sheet
                worksheet = writer.sheets['Transactions']
                for idx, col in enumerate(df_tx.columns):
                    worksheet.column_dimensions[chr(65 + idx)].width = 20
            
            # Token Transfers sheet
            if results['token_transfers']:
                transfer_data = []
                for transfer in results['token_transfers']:
                    token_info = transfer.get('token_info', {})
                    decimals = int(token_info.get('decimals', 18))
                    amount = int(transfer['value']) / (10 ** decimals)
                    
                    transfer_data.append({
                        'Timestamp': datetime.fromtimestamp(int(transfer['timeStamp'])).strftime('%Y-%m-%d %H:%M:%S'),
                        'Direction': transfer.get('direction', 'unknown'),
                        'Token': token_info.get('symbol', 'UNKNOWN'),
                        'Amount': amount,
                        'From': transfer['from'],
                        'To': transfer['to'],
                        'Hash': transfer['hash'],
                        'Gas Used': int(transfer.get('gasUsed', 0)),
                        'URL': f"https://www.shibariumscan.io/tx/{transfer['hash']}"
                    })
                
                df_transfers = pd.DataFrame(transfer_data)
                df_transfers.to_excel(writer, sheet_name='Token Transfers', index=False)
            
            # Summary sheet
            summary_data = {
                'Metric': [
                    'Wallet Address',
                    'Date Range',
                    'Total Transactions',
                    'Bridge Transactions',
                    'Swap Transactions',
                    'Send Transactions',
                    'Receive Transactions',
                    'Total Gas Spent (BONE)',
                    'Unique Tokens'
                ],
                'Value': [
                    results['wallet'],
                    f"{results['start_date']} to {results['end_date']}",
                    results['summary']['total_transactions'],
                    results['summary']['bridges'],
                    results['summary']['swaps'],
                    results['summary']['sends'],
                    results['summary']['receives'],
                    f"{results['summary']['gas_spent']:.4f}",
                    len(results.get('token_summary', {}))
                ]
            }
            
            df_summary = pd.DataFrame(summary_data)
            df_summary.to_excel(writer, sheet_name='Summary', index=False)
            
            # Token Summary sheet
            if results.get('token_summary'):
                token_data = []
                for symbol, data in results['token_summary'].items():
                    token_data.append({
                        'Token': symbol,
                        'Total In': data['in'],
                        'Total Out': data['out'],
                        'Net': data['in'] - data['out'],
                        'Transfers': len(data['transfers'])
                    })
                
                df_tokens = pd.DataFrame(token_data)
                df_tokens.to_excel(writer, sheet_name='Token Summary', index=False)
    
    async def _generate_koinly_csv(self, results: Dict, output_path: Path):
        """Generate Koinly-compatible CSV"""
        koinly_data = []
        
        # Process all transactions and transfers
        all_events = []
        
        # Add normal transactions
        for tx in results['transactions']:
            if tx.get('type') in ['send', 'receive'] and int(tx.get('value', 0)) > 0:
                all_events.append({
                    'timestamp': int(tx['timeStamp']),
                    'type': tx['type'],
                    'hash': tx['hash'],
                    'from': tx['from'],
                    'to': tx['to'],
                    'amount': float(Web3.from_wei(int(tx['value']), 'ether')),
                    'currency': 'BONE',
                    'gas': float(tx.get('gas_cost_bone', 0))
                })
        
        # Add token transfers
        for transfer in results['token_transfers']:
            token_info = transfer.get('token_info', {})
            decimals = int(token_info.get('decimals', 18))
            amount = int(transfer['value']) / (10 ** decimals)
            
            all_events.append({
                'timestamp': int(transfer['timeStamp']),
                'type': 'send' if transfer['direction'] == 'out' else 'receive',
                'hash': transfer['hash'],
                'from': transfer['from'],
                'to': transfer['to'],
                'amount': amount,
                'currency': token_info.get('symbol', f"NULL_{transfer['contractAddress'][:8]}"),
                'gas': 0  # Gas is in the main transaction
            })
        
        # Sort by timestamp
        all_events.sort(key=lambda x: x['timestamp'])
        
        # Convert to Koinly format
        for event in all_events:
            date = datetime.fromtimestamp(event['timestamp']).strftime('%Y-%m-%d %H:%M:%S UTC')
            
            if event['type'] == 'send':
                koinly_data.append({
                    'Date': date,
                    'Sent Amount': event['amount'],
                    'Sent Currency': event['currency'],
                    'Received Amount': '',
                    'Received Currency': '',
                    'Fee Amount': event['gas'],
                    'Fee Currency': 'BONE',
                    'Net Worth Amount': '',
                    'Net Worth Currency': '',
                    'Label': 'send',
                    'Description': f"Send to {event['to'][:10]}...",
                    'TxHash': event['hash']
                })
            else:  # receive
                koinly_data.append({
                    'Date': date,
                    'Sent Amount': '',
                    'Sent Currency': '',
                    'Received Amount': event['amount'],
                    'Received Currency': event['currency'],
                    'Fee Amount': event['gas'],
                    'Fee Currency': 'BONE',
                    'Net Worth Amount': '',
                    'Net Worth Currency': '',
                    'Label': 'receive',
                    'Description': f"Receive from {event['from'][:10]}...",
                    'TxHash': event['hash']
                })
        
        # Handle swaps
        for tx in results['transactions']:
            if tx.get('type') == 'swap' and 'swap_details' in tx:
                date = datetime.fromtimestamp(int(tx['timeStamp'])).strftime('%Y-%m-%d %H:%M:%S UTC')
                swap = tx['swap_details']
                
                koinly_data.append({
                    'Date': date,
                    'Sent Amount': swap.get('amount_in', 0),
                    'Sent Currency': swap.get('token_in_symbol', 'UNKNOWN'),
                    'Received Amount': swap.get('amount_out', 0),
                    'Received Currency': swap.get('token_out_symbol', 'UNKNOWN'),
                    'Fee Amount': float(tx.get('gas_cost_bone', 0)),
                    'Fee Currency': 'BONE',
                    'Net Worth Amount': '',
                    'Net Worth Currency': '',
                    'Label': 'trade',
                    'Description': f"Swap on {tx.get('dex_name', 'DEX')}",
                    'TxHash': tx['hash']
                })
        
        # Write CSV
        if koinly_data:
            df = pd.DataFrame(koinly_data)
            df.to_csv(output_path, index=False)
    
    async def _generate_summary_report(self, results: Dict, output_path: Path):
        """Generate text summary report"""
        lines = [
            "SHIBARIUM TRANSACTION SUMMARY REPORT",
            "=" * 50,
            f"Wallet: {results['wallet']}",
            f"Period: {results['start_date']} to {results['end_date']}",
            "",
            "TRANSACTION SUMMARY",
            "-" * 30,
            f"Total Transactions: {results['summary']['total_transactions']}",
            f"Bridge Transactions: {results['summary']['bridges']}",
            f"Swap Transactions: {results['summary']['swaps']}",
            f"Send Transactions: {results['summary']['sends']}",
            f"Receive Transactions: {results['summary']['receives']}",
            f"Total Gas Spent: {results['summary']['gas_spent']:.6f} BONE",
            "",
            "TOKEN SUMMARY",
            "-" * 30
        ]
        
        # Add token summary
        if results.get('token_summary'):
            for symbol, data in results['token_summary'].items():
                net = data['in'] - data['out']
                lines.extend([
                    f"\n{symbol}:",
                    f"  Received: {data['in']:.6f}",
                    f"  Sent: {data['out']:.6f}",
                    f"  Net: {net:+.6f}",
                    f"  Transfers: {len(data['transfers'])}"
                ])
        
        # Add discovered contracts
        lines.extend([
            "",
            "DISCOVERED CONTRACTS",
            "-" * 30,
            f"DEX Routers: {len([k for k in self.router_cache if k not in self.known_routers])}",
            f"Bridges: {len([k for k in self.bridge_cache if k not in self.known_bridges])}",
            f"Tokens: {len(self.token_cache)}"
        ])
        
        # Add errors if any
        if results['errors']:
            lines.extend([
                "",
                "ERRORS",
                "-" * 30
            ])
            lines.extend(results['errors'][:10])  # First 10 errors
            if len(results['errors']) > 10:
                lines.append(f"... and {len(results['errors']) - 10} more errors")
        
        # Write report
        with open(output_path, 'w') as f:
            f.write('\n'.join(lines))