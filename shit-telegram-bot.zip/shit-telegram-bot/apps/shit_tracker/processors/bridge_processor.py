"""
Bridge Processor for S.H.I.T. Tracker
Processes bridge transactions
"""

import logging
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class BridgeProcessor:
    """Processes bridge transactions"""
    
    KNOWN_BRIDGES = {
        '0x5a6a33117d6c5b5e0c9c6f9f9b5c2f2e8c3d4e5f': {
            'name': 'Shibarium Bridge',
            'chain_from': 'Ethereum',
            'chain_to': 'Shibarium'
        }
    }
    
    def __init__(self):
        self.bridges = self.KNOWN_BRIDGES
        
    async def process_bridge_transaction(self, transaction: Dict) -> Optional[Dict]:
        """Process a bridge transaction"""
        to_address = transaction.get('to', '').lower()
        
        if to_address not in self.bridges:
            return None
            
        bridge_info = self.bridges[to_address]
        
        return {
            'type': 'bridge',
            'bridge_name': bridge_info['name'],
            'from_chain': bridge_info['chain_from'],
            'to_chain': bridge_info['chain_to'],
            'amount': transaction.get('value', 0),
            'status': 'completed' if transaction.get('isError') == '0' else 'failed'
        }
        
    def add_bridge(self, address: str, name: str, from_chain: str, to_chain: str):
        """Add a new bridge to the known bridges"""
        self.bridges[address.lower()] = {
            'name': name,
            'chain_from': from_chain,
            'chain_to': to_chain
        }