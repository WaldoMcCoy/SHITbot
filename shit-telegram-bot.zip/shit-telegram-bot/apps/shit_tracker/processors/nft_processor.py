"""
NFT Processor for S.H.I.T. Tracker
Processes NFT transfers (ERC721, ERC1155, ERC404)
"""

import logging
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class NFTProcessor:
    """Processes NFT-related transactions"""
    
    # NFT transfer event signatures
    TRANSFER_SIGNATURES = {
        'erc721': '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef',
        'erc1155_single': '0xc3d58168c5ae7397731d063d5bbf3d657854427343f4c083240f7aacaa2d0f62',
        'erc1155_batch': '0x4a39dc06d4c0dbc64b70af90fd698a233a518aa5d07e595d983b8c0526c8f7fb',
    }
    
    def __init__(self):
        self.nft_cache = {}
        
    async def process_nft_transfer(self, transaction: Dict, logs: List[Dict]) -> Optional[Dict]:
        """Process NFT transfer transaction"""
        nft_data = {
            'type': 'nft_transfer',
            'transfers': []
        }
        
        for log in logs:
            if self._is_nft_transfer(log):
                transfer = await self._parse_nft_transfer(log, transaction)
                if transfer:
                    nft_data['transfers'].append(transfer)
                    
        if nft_data['transfers']:
            return nft_data
            
        return None
        
    def _is_nft_transfer(self, log: Dict) -> bool:
        """Check if log is an NFT transfer"""
        if not log.get('topics'):
            return False
            
        topic0 = log['topics'][0]
        return topic0 in self.TRANSFER_SIGNATURES.values()
        
    async def _parse_nft_transfer(self, log: Dict, transaction: Dict) -> Optional[Dict]:
        """Parse NFT transfer from log"""
        topic0 = log['topics'][0]
        
        if topic0 == self.TRANSFER_SIGNATURES['erc721']:
            return self._parse_erc721_transfer(log)
        elif topic0 == self.TRANSFER_SIGNATURES['erc1155_single']:
            return self._parse_erc1155_single(log)
        elif topic0 == self.TRANSFER_SIGNATURES['erc1155_batch']:
            return self._parse_erc1155_batch(log)
            
        return None
        
    def _parse_erc721_transfer(self, log: Dict) -> Dict:
        """Parse ERC721 transfer"""
        return {
            'standard': 'ERC721',
            'contract': log['address'],
            'from': self._decode_address(log['topics'][1]),
            'to': self._decode_address(log['topics'][2]),
            'token_id': int(log['topics'][3], 16) if len(log['topics']) > 3 else None,
            'amount': 1
        }
        
    def _parse_erc1155_single(self, log: Dict) -> Dict:
        """Parse ERC1155 single transfer"""
        # Decode data field for amount
        return {
            'standard': 'ERC1155',
            'contract': log['address'],
            'operator': self._decode_address(log['topics'][1]),
            'from': self._decode_address(log['topics'][2]),
            'to': self._decode_address(log['topics'][3]),
            'token_id': self._decode_uint(log['data'][:66]),
            'amount': self._decode_uint(log['data'][66:])
        }
        
    def _parse_erc1155_batch(self, log: Dict) -> List[Dict]:
        """Parse ERC1155 batch transfer"""
        # This would need proper ABI decoding
        return []
        
    def _decode_address(self, topic: str) -> str:
        """Decode address from topic"""
        return '0x' + topic[-40:]
        
    def _decode_uint(self, data: str) -> int:
        """Decode uint from data"""
        return int(data, 16) if data else 0