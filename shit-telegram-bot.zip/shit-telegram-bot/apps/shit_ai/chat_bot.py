#!/usr/bin/env python3
"""
# File location: /apps/shit_ai/chat_bot.py
Enhanced ShitAI Chat Bot with Ollama integration
Supports dynamic model selection, response modes, and admin controls
"""

import aiohttp
import asyncio
import json
import logging
import os
from datetime import datetime
from typing import Dict, List, Optional, Any

logger = logging.getLogger(__name__)


class OllamaAPI:
    """Ollama API client for AI model interactions"""
    
    def __init__(self, host: str = None, port: int = None):
        self.host = host or os.getenv('OLLAMA_HOST', 'localhost')
        self.port = port or int(os.getenv('OLLAMA_PORT', 11434))
        self.base_url = f"http://{self.host}:{self.port}"
        self.timeout = aiohttp.ClientTimeout(total=300)  # 5 minute timeout for long responses
    
    async def list_models(self) -> List[Dict[str, Any]]:
        """Get list of available models from Ollama"""
        try:
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.get(f"{self.base_url}/api/tags") as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get('models', [])
                    else:
                        logger.error(f"Failed to list models: {response.status}")
                        return []
        except Exception as e:
            logger.error(f"Error connecting to Ollama: {e}")
            return []
    
    async def generate(self, model: str, prompt: str, context: List[int] = None, 
                      stream: bool = True, options: Dict = None) -> AsyncGenerator:
        """Generate response from model"""
        payload = {
            'model': model,
            'prompt': prompt,
            'stream': stream
        }
        
        if context:
            payload['context'] = context
        
        if options:
            payload['options'] = options
        
        try:
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.post(
                    f"{self.base_url}/api/generate",
                    json=payload
                ) as response:
                    if response.status == 200:
                        if stream:
                            async for line in response.content:
                                if line:
                                    try:
                                        data = json.loads(line)
                                        yield data
                                    except json.JSONDecodeError:
                                        continue
                        else:
                            data = await response.json()
                            yield data
                    else:
                        logger.error(f"Generate failed: {response.status}")
                        yield {'error': f'API error: {response.status}'}
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            yield {'error': str(e)}
    
    async def chat(self, model: str, messages: List[Dict[str, str]], 
                   stream: bool = True, options: Dict = None) -> AsyncGenerator:
        """Chat with model using conversation format"""
        payload = {
            'model': model,
            'messages': messages,
            'stream': stream
        }
        
        if options:
            payload['options'] = options
        
        try:
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.post(
                    f"{self.base_url}/api/chat",
                    json=payload
                ) as response:
                    if response.status == 200:
                        if stream:
                            async for line in response.content:
                                if line:
                                    try:
                                        data = json.loads(line)
                                        yield data
                                    except json.JSONDecodeError:
                                        continue
                        else:
                            data = await response.json()
                            yield data
                    else:
                        logger.error(f"Chat failed: {response.status}")
                        yield {'error': f'API error: {response.status}'}
        except Exception as e:
            logger.error(f"Error in chat: {e}")
            yield {'error': str(e)}


class ShitAIChatBot:
    """Enhanced AI Chat Bot with full feature set"""
    
    def __init__(self, db, admin_users: List[int] = None):
        self.db = db
        self.ollama = OllamaAPI()
        self.admin_users = admin_users or []
        
        # Chat session storage
        self.chat_sessions = {}  # user_id -> ChatSession
        self.model_cache = {}  # Cache available models
        self.hidden_models = set()  # Models hidden by admin
        
        # Default settings
        self.default_model = 'llama2'
        self.character_limit = 2000  # Default character limit for limited mode
        self.enable_formatting = True
        self.bold_mode = False
        
        # Load admin settings
        asyncio.create_task(self._load_settings())
    
    async def _load_settings(self):
        """Load admin settings from database"""
        settings = await self.db.get_ai_settings()
        if settings:
            self.default_model = settings.get('default_model', self.default_model)
            self.character_limit = settings.get('character_limit', self.character_limit)
            self.enable_formatting = settings.get('enable_formatting', True)
            self.bold_mode = settings.get('bold_mode', False)
            self.hidden_models = set(settings.get('hidden_models', []))
    
    async def save_settings(self):
        """Save admin settings to database"""
        settings = {
            'default_model': self.default_model,
            'character_limit': self.character_limit,
            'enable_formatting': self.enable_formatting,
            'bold_mode': self.bold_mode,
            'hidden_models': list(self.hidden_models)
        }
        await self.db.save_ai_settings(settings)
    
    async def get_available_models(self, include_hidden: bool = False) -> List[Dict[str, Any]]:
        """Get list of available AI models"""
        # Check cache first
        if self.model_cache and (datetime.now() - self.model_cache.get('timestamp', datetime.min)).seconds < 300:
            models = self.model_cache.get('models', [])
        else:
            # Refresh from Ollama
            models = await self.ollama.list_models()
            self.model_cache = {
                'models': models,
                'timestamp': datetime.now()
            }
        
        if not include_hidden:
            # Filter out hidden models
            models = [m for m in models if m.get('name') not in self.hidden_models]
        
        return models
    
    def get_or_create_session(self, user_id: int, username: str = None) -> 'ChatSession':
        """Get or create a chat session for user"""
        if user_id not in self.chat_sessions:
            self.chat_sessions[user_id] = ChatSession(
                user_id=user_id,
                username=username,
                model=self.default_model
            )
        return self.chat_sessions[user_id]
    
    async def process_message(self, user_id: int, message: str, username: str = None) -> AsyncGenerator[str, None]:
        """Process a chat message and yield response chunks"""
        session = self.get_or_create_session(user_id, username)
        
        # Add user message to history
        session.add_message('user', message)
        
        # Check if in limited mode
        options = {}
        if session.limited_mode:
            # Add instruction for limited response
            system_prompt = f"You must respond in {self.character_limit} characters or less. Be concise."
            if not any(msg['role'] == 'system' for msg in session.messages):
                session.messages.insert(0, {'role': 'system', 'content': system_prompt})
            else:
                # Update existing system prompt
                for msg in session.messages:
                    if msg['role'] == 'system':
                        msg['content'] = system_prompt + "\n" + msg.get('original_content', msg['content'])
                        break
        
        # Generate response
        response_text = ""
        async for chunk in self.ollama.chat(
            model=session.model,
            messages=session.messages,
            stream=True,
            options=options
        ):
            if 'error' in chunk:
                yield f"❌ Error: {chunk['error']}"
                return
            
            if 'message' in chunk and 'content' in chunk['message']:
                content = chunk['message']['content']
                response_text += content
                
                # Apply formatting if enabled
                if self.enable_formatting:
                    if self.bold_mode:
                        content = f"**{content}**"
                    # Could add other formatting here
                
                yield content
            
            if chunk.get('done', False):
                # Save context for next message
                if 'context' in chunk:
                    session.context = chunk['context']
                break
        
        # Add assistant response to history
        session.add_message('assistant', response_text)
        
        # Trim history if too long
        session.trim_history()
        
        # Save session
        await self.save_session(session)
    
    async def change_model(self, user_id: int, model_name: str) -> bool:
        """Change the model for a user's session"""
        models = await self.get_available_models()
        model_names = [m['name'] for m in models]
        
        if model_name not in model_names:
            return False
        
        session = self.get_or_create_session(user_id)
        session.model = model_name
        session.clear_history()  # Clear history when changing models
        
        await self.save_session(session)
        return True
    
    async def toggle_mode(self, user_id: int) -> str:
        """Toggle between unlimited and limited response mode"""
        session = self.get_or_create_session(user_id)
        session.limited_mode = not session.limited_mode
        
        await self.save_session(session)
        
        if session.limited_mode:
            return f"Limited mode ON ({self.character_limit} chars)"
        else:
            return "Unlimited mode ON"
    
    async def clear_history(self, user_id: int) -> None:
        """Clear chat history for a user"""
        session = self.get_or_create_session(user_id)
        session.clear_history()
        await self.save_session(session)
    
    async def save_session(self, session: 'ChatSession') -> None:
        """Save chat session to database"""
        await self.db.save_chat_session(
            user_id=session.user_id,
            session_data={
                'model': session.model,
                'messages': session.messages,
                'context': session.context,
                'limited_mode': session.limited_mode,
                'created_at': session.created_at.isoformat(),
                'last_activity': session.last_activity.isoformat()
            }
        )
    
    async def load_session(self, user_id: int) -> Optional['ChatSession']:
        """Load chat session from database"""
        data = await self.db.get_chat_session(user_id)
        if data:
            session = ChatSession(user_id=user_id)
            session.model = data.get('model', self.default_model)
            session.messages = data.get('messages', [])
            session.context = data.get('context')
            session.limited_mode = data.get('limited_mode', False)
            if 'created_at' in data:
                session.created_at = datetime.fromisoformat(data['created_at'])
            if 'last_activity' in data:
                session.last_activity = datetime.fromisoformat(data['last_activity'])
            
            self.chat_sessions[user_id] = session
            return session
        return None
    
    # Admin functions
    
    async def set_default_model(self, model_name: str) -> bool:
        """Set default model (admin only)"""
        models = await self.get_available_models(include_hidden=True)
        model_names = [m['name'] for m in models]
        
        if model_name not in model_names:
            return False
        
        self.default_model = model_name
        await self.save_settings()
        return True
    
    async def set_character_limit(self, limit: int) -> None:
        """Set character limit for limited mode (admin only)"""
        self.character_limit = max(50, min(4000, limit))  # Between 50-4000
        await self.save_settings()
    
    async def toggle_formatting(self) -> bool:
        """Toggle formatting on/off (admin only)"""
        self.enable_formatting = not self.enable_formatting
        await self.save_settings()
        return self.enable_formatting
    
    async def toggle_bold_mode(self) -> bool:
        """Toggle bold text mode (admin only)"""
        self.bold_mode = not self.bold_mode
        await self.save_settings()
        return self.bold_mode
    
    async def hide_model(self, model_name: str) -> bool:
        """Hide a model from users (admin only)"""
        models = await self.get_available_models(include_hidden=True)
        model_names = [m['name'] for m in models]
        
        if model_name not in model_names:
            return False
        
        self.hidden_models.add(model_name)
        await self.save_settings()
        return True
    
    async def unhide_model(self, model_name: str) -> bool:
        """Unhide a model (admin only)"""
        if model_name in self.hidden_models:
            self.hidden_models.remove(model_name)
            await self.save_settings()
            return True
        return False
    
    def is_admin(self, user_id: int) -> bool:
        """Check if user is admin"""
        return user_id in self.admin_users


class ChatSession:
    """Individual chat session for a user"""
    
    def __init__(self, user_id: int, username: str = None, model: str = 'llama2'):
        self.user_id = user_id
        self.username = username
        self.model = model
        self.messages = []
        self.context = None  # Ollama context for conversation continuity
        self.limited_mode = False
        self.created_at = datetime.now()
        self.last_activity = datetime.now()
        self.max_history = 20  # Maximum messages to keep
    
    def add_message(self, role: str, content: str):
        """Add a message to the conversation"""
        self.messages.append({
            'role': role,
            'content': content,
            'timestamp': datetime.now().isoformat()
        })
        self.last_activity = datetime.now()
    
    def clear_history(self):
        """Clear conversation history"""
        self.messages = []
        self.context = None
    
    def trim_history(self):
        """Trim history to maximum length"""
        if len(self.messages) > self.max_history:
            # Keep system messages and recent messages
            system_msgs = [m for m in self.messages if m['role'] == 'system']
            other_msgs = [m for m in self.messages if m['role'] != 'system']
            
            # Keep last N messages
            keep_count = self.max_history - len(system_msgs)
            self.messages = system_msgs + other_msgs[-keep_count:]
    
    def get_formatted_history(self) -> str:
        """Get formatted conversation history"""
        formatted = []
        for msg in self.messages:
            role = msg['role'].capitalize()
            content = msg['content']
            formatted.append(f"**{role}:** {content}")
        return "\n\n".join(formatted)